#!/usr/bin/python

import sys
import os
import string
from optparse import OptionParser
import array

rootName = sys.argv[1]
contactsName = rootName+'_Contacts.out'
cfile = file( contactsName, 'r')

contactFields    = list()
contact_id       = list()
hydrophobic      = array.array('f', [0.0]*200)
hydrophilic      = array.array('f', [0.0]*200)
total            = array.array('f', [0.0]*200)
hydrophobic_rate = array.array('f', [0.0]*200)
hydrophilic_rate = array.array('f', [0.0]*200)
TotalRes = array.array('f', [0.0]*200)

count            = 0
cont_count       = 1

for l in cfile.readlines():
        contactFields = l.strip('\n')
	if (count > 1):
		contactFields = contactFields.split()
		contact_id.append( contactFields[1]+'-'+contactFields[2]+'-'+contactFields[3]+'-'+contactFields[4])
		hydrophobic[cont_count] = float(contactFields[10]) + float(contactFields[11]) + float(contactFields[14]) + float(contactFields[15]) + float(contactFields[17])
		hydrophilic[cont_count] = float(contactFields[ 8]) + float(contactFields[ 9]) + float(contactFields[12]) + float(contactFields[13]) + float(contactFields[16])
		total[cont_count]       = float(contactFields[10]) + float(contactFields[11]) + float(contactFields[14]) + float(contactFields[15]) + float(contactFields[17]) + float(contactFields[ 8]) + float(contactFields[ 9]) + float(contactFields[12]) + float(contactFields[13]) + float(contactFields[16])
		hydrophobic_rate[cont_count]  = hydrophobic[cont_count]/ total[cont_count]
		hydrophilic_rate[cont_count]  = hydrophilic[cont_count]/ total[cont_count]
                TotalRes[cont_count] = float(contactFields[18])
		#print "%-2d %15s %8.3f %8.3f" % (cont_count, contact_id[cont_count-1], hydrophobic_rate[cont_count], hydrophilic_rate[cont_count])
		cont_count = cont_count + 1
	count = count + 1

cfile.close()

hbondName = rootName+'_Hbonds.out'
cfile = file( hbondName, 'r')
contactFields = list()
hb_id = list()
count = 0
hb_count = 0

for l in cfile.readlines():
	if (count > 1):
		contactFields = l.strip('\n').split()
		hb_id.append( contactFields[3]+'-'+contactFields[4]+'-'+contactFields[6]+'-'+contactFields[7])
		#print "%-2d %15s" % (hb_count, hb_id[hb_count])
		hb_count = hb_count + 1
	count = count + 1

cfile.close()

ishb = 0
cont_count = 1

for k in contact_id:
	ishb = 0
	for h in hb_id:
		if(k == h):
			ishb = 1
			break

	if (ishb == 1):
		print "%-15s H-BOND %f" % (k, TotalRes[cont_count])
	else:
		if(hydrophobic_rate[cont_count] >= 0.6):
			print "%-15s H-PHOB %f" % (k, TotalRes[cont_count])
		elif(hydrophilic_rate[cont_count] >= 0.6):
			print "%-15s H-PHIL %f" % (k, TotalRes[cont_count])
		else:
			print "%-15s H-BOTH %f" % (k, TotalRes[cont_count])
	cont_count = cont_count + 1
