#
#
#	Implicit Solvation Model (ISM) Plugin for PyMOL
#
#       (C) 2010,2011,2012 Bioinformatics Units. Center for Molecular Biology "Severo Ochoa"
#       Molecular Modeling Lab. Faculty of Medicine. Universidad Alcala.
#
#	Alvaro Cortes Cabrera <acortes@cbm.uam.es>
#	Javier Klett <jklett@cbm.uam.es>
#
# 	Permission to use, copy, modify, distribute, and distribute modified
# 	versions of this software and its documentation for any purpose and
# 	without fee is hereby granted, provided that the above copyright
# 	notice appear in all copies, and that both the copyright notice and
# 	this permission notice appear in supporting documentation, and that
# 	the name of the authors not be used in advertising or publicity
# 	pertaining to distribution of the software without specific, written
# 	prior permission.
#
# 	THE AUTHORS DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
# 	SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
# 	FITNESS.  IN NO EVENT SHALL ALVARO CORTES OR JAVIER KLETT BE LIABLE FOR ANY
# 	SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
# 	RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
# 	CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
# 	CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#
#	rev12 - 14/11/2012
#		MMISMA hbond inclusion
#               Plots can be saved as PNGs
#               Self terms now included per residue
#               Single structure terms analysis included
#              
#
#       rev11 - 05/11/2012
#               Fixes for Windows compatibility
#
#	rev10 - 24/10/2012
#		Fix single residue columns problem
#
#	rev9 - 03/06/2012
#		Minor fixs in labels
#		UAH logo included
#	
#	rev8 - 23/04/2012:
#		Contacts module revamped
#		List in table for contacts
#
#	rev7 - 20/04/2012:
#		Fix columns problem in global reader
#		Range in gnuplot graphs 
#		Contacts module
#

import sys,os,math,re, fnmatch, shutil
from os import stat
from os.path import abspath
from stat import ST_SIZE
from time import sleep, time
import Tkinter
import Tkconstants, tkFileDialog
import Tkinter,Pmw
from Tkinter import *
import tkMessageBox
import Pmw
from commands import getstatusoutput
from pymol import cmd,selector
from pymol.cmd import _feedback,fb_module,fb_mask,is_list,_cmd
from pymol import util
from pymol.cgo import *
from pymol import stored
import tkColorChooser
from pymol.vfont import plain
from glob import glob
import subprocess
from threading import Thread
import array
import Gnuplot

def __init__(self):
    self.menuBar.addmenuitem('Plugin', 'command','Launch ISM plugin', label='ISM', command = lambda s=self: MainPlug(s))


about_text = """

 ISM (Implicit Solvation Model)
 (C) 2010,2011,2012 Bioinformatics Unit. Centro de Biologia Molecular "Severo Ochoa"

 Javier Klett <jklett@cbm.uam.es>
 Ruben Gil-Redondo <rgilredondo@smartligs.com>

 ----------------------------------------------------------------------------------

 ISM PyMol plugin rev-12

 (C) 2010,2011,2012 Bioinformatics Unit. Centro de Biologia Molecular "Severo Ochoa"
     Molecular Modeling Lab. Faculty of Medicine. Universidad Alcala

 (a,b) Alvaro Cortes <acortes@cbm.uam.es>
 (a)   Javier Klett <jklett@cbm.uam.es>
 (b)   Federico Gago <federico.gago@uah.es>
 (a)   Antonio Morreale <amorreale@cbm.uam.es>

 (a) Bioinformatics Unit 
     Center for Molecular Biology. 
     CSIC-UAM. Spain
 (b) Modelling Laboratory.
     Faculty of Medicine.
     University of Alcala de Henares

 Using this plugin you accept the ISM software license and following text:

 Permission to use, copy, modify, distribute, and distribute modified
 versions of this software and its documentation for any purpose and
 without fee is hereby granted, provided that the above copyright
 notice appear in all copies, and that both the copyright notice and
 this permission notice appear in supporting documentation, and that
 the name of the authors not be used in advertising or publicity
 pertaining to distribution of the software without specific, written
 prior permission.

 THE AUTHORS DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS
 SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND
 FITNESS.  IN NO EVENT THE AUTHORS BE LIABLE FOR ANY
 SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER
 RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF
 CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN
 CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.


"""

about_image = """
R0lGODlheQJKAOf9AAABAAMGAQgKBg4QDBIUERcYFhocGRweGx4gHiEiICMkIiUnJCcoJiosKi0v
LDAyLzIzMTM1MzY4NTg5Nzk7ODw+OwBLgz5APUFCQABQgkRGQ0ZIRUlKSAtWiABaiwBcjUtNSxFY
iwBfkE5PTVBST0ZVZVNUUgBjtRRfqwBlsB1gjVVWVFZYVQZnsyJjkQBqtQtotA1qr1pcWVtdWihn
lRNsq11eXABxtVJhZhRssR5smV5gXRlutGBiX2FjYCltrWJkYR1xsRxzrGRlY2VmZDFxmGdoZhN6
uCZ2tjJ0r2lraCZ4smxua25wbTx6oi59tm9xbjh8sDF/uXJ0cXR2cz6AtTSEtzaDvXZ4dUuBpUKD
uHh6d0GGtHt8ek6FqT2IwjyKvUeHvX1/fFSJrX+BfkCNwVKJukmMu0yMwYGDgEOPxFOOuISFg06Q
v1WPuYaIhVeQwluSsIiKh16St1OVxGKSvYqMiVqVv2eUtI2PjGWYvY+RjmCaxFqcy5KUkW2bumOd
x2mcwZSWk5aYlWehy26hxpqcmHujvnKlypyem3elxZ+hnnapz3ypyXKr1qGjoKOlon+szXuu1ISt
x6WnpIKv0IewyqiqpoywxamrqIaz1Kutqqyuq4y0z5G1yq6wrbCyr5S4zpC51LO1spS817W3tJm9
07a4tbe5tp++zpjA25zA1bm7uLu9up/D2KPD072/vKfD2qvD1KLG3L/BvsHDv6XJ36zH38LEwarK
2sPFwrLJ28XHxMfJxrXN37nN2cnLyMrMybTQ6LLS4szOy73R3bvS5M7QzM/RzsHV4dHU0NPV0sXZ
5dXX1NbY1dja1snd6dnb2M7e5dXd5tvd2s3h7dzf297g3dPj6tri6+Di3+Lk4dfn7uHm6eTm497n
7+Xn5Ofp5tvs8uLq8+jq5+Xr7enr6Ovt6uXu9unu8O3v6+7w7enx+uzx9PDy7+/09/L08PT28/H3
+fb49PT5/Pf69vb7/vn7+Pr8+ff9//v9+v/8+vj+///9//z/+/7//CH+EUNyZWF0ZWQgd2l0aCBH
SU1QACwAAAAAeQJKAAAI/gDX/RtIsKDBgwgTKlzIsKHDhxAjSpxIsaLFixgzatzIsaPHjyBDihxJ
cqC1kihTqlzJsqXLl/r0vZxJs6bNlcdu6tzJs6dPnfru3cP3s6jRoy5hIV3KtKnTnve8PZt6rNm6
oQnx1VO3Ldw8fDJ9BsU6UB8+oWSfqr3Jaa3bt3DjTgynje6xY8GANfM276C+dcBa6aqFy1pYnviU
QRqkCx48a896cRI06Fg9uZhLPsrMubPnpdasKWsGOdjUbYYNugPGSxnVXtt8AsNiwwSHNHLEiCGy
QoaSKcfufR6O0RDx48gz66sHL149ogzNQr9ITVkvYsogX2+m7DJBfdta/o2e2kyX5X9a5907nPJe
PHXr6rnLM0LGihFGxMjJY8cIECM9sKFOcgQ6NEiBCCYollDzbLMIFl1AQg17fplzjDICXfSMLtSg
1ssxvYwCCy99EVTPM7Rgx90xutDyzGPEHPOMOyLpE4831Hh1jzutTLECC2/s0YMMO5iwghFTYCHG
G1j8p4QMtQin4JT/CELllVi218womdjRxBBYvGFHHsQspMwbUzSxx0kUBXVdaJFlMkopnKBSED7w
EIMKL8EQ00uLrWyyCSu9cPfiPfMkOtRQZq1HUWJikMCBDG8YQoWR9m2gwQozsEACCUDol0YaTOzw
3w520JhlgX6s6uqr/hrpwwsbbOj3RhpUELGFHIbAkxA1b/SghBJA2MFmRPVso8simdASTDC9oLLI
JZkYhk+DvbQyyiOjsNIKLKygAgsqjywyii68sOIaLqycUuiFoh1jDTzTPUSNEiz4YIQSQ9RGwgq2
acCBCSaMMCkZfhhiCBk+2GAqEF2cAytyrU5s8cUN1SOIH3l0zB8bpRJhxzMIbeMHFWy8wcYWQOQR
G0T3KKMLtLSggosuuuDSCzC1jAKOO7AMkgkquqBiyCKUZHIKLbUMNgolkJSLNCytZMIJK7B8kkgm
uDBtDoULwbOIDUQw0QQUUChhg8EbYEDBBRxwsIEJVMixxyAbb6HE/g5G1C0xxp5VDPjgg4vN8R57
fIyFEiMwoUtQBekDS90ey6E3KwzNA8868MzjWjjhPCNzuKjQwksvvdAyCiiCcEKLvM+c4gckm4xS
+s68TLbIJ6uDcgkqwSijTDCnJOKuLq2U6JA5aRCB5BTQN0HEDCZoUIEED0gggQZDLJmHH4nLMUXf
Ygyi6kP7/JONK7FAIw9E3MRCCjRgE66R4Pbn/+o9WoPP3xtimMIQRrCCN3RrXkRZByWwIAc72EEO
bOhCEzLhK4TgQx3BYAUoONEKXljDG9oQXS1Y8QhKcGJOqGBFJjoGiaU9qxWLyMMgHvEJVqCLFqBI
xCVa0YpPGGIT/rqI0TF4Qa5FEO0T4HDIVo4BBSKUbQpUoML4WGAC6l2AAQlQAAeYIAY2NLBjDYQe
GTIRD4mMgw5SCIMZGJGNhuiDGW3QghbCAA3A3eMd5ehGvdxIj3d8oxxgwx9HQkeNZ4RDShS5xzOo
QQ1rnO8i69BGaKyxjvoNZx4hLGQF9deQeWQiEYYAnx3Y0CRJaeCUmxKEMvABjj1QgQy0IkMXogiJ
bZglHp0jSDhwQQw/6eITtRAeXnQBC9+JJzS5e4Qs9wCJTHxig4nwoiAgwYlToAIUlPADJdgFiT00
63Ts2sQj/LAIVrDCMJqLxx4HEg9WMG4EO1ACE6BABSzkimA2/qCeBApAgA1MYQtiSEPKVJaILmAh
D7RQnkP0MYwluAIbiAgCILjBEGjA4Q7QSEYSNEGPi2VjEnzQgiLeERFoNOIOWuhERw0iyO/AQx0w
jalM3REPS3IgADjVgDYsYg2c4tRKGFGGDwjgUzEoFDmtSIBPF1GgfKTjG1BNx0dqwQIxiDINUwCC
pD5FQBnY4D+leMYWmrAFLEwBCkwo2xbskKJsgiIc/1BHjIRXtEwIZoSoQMUoTkiMbZjjHNbAxSO6
YIejlSsRizBEHuRgNx1uAhKCSIMg6BRZQ5SCh1wyhCDekAdmNZJ1iQDGI/8xD1SMgAWT2oGpjNAE
KjABtSZQ/q0NSMCAAVTACFsgA2cdSAZDpGwRcI0IP4yxhGHoIxuN4AEf2qGQb7SBB8b4BzaeIAp7
TCx95fCFKHhwB5LCzxeVyIEkVlqQlrJzbEBIr3p94AMiTMEOp5jXQUzgUxK8jCLa8OkAjHMRazTA
pzglwiY5E4/QDIggtHCATyHhknzIox3vaAd5DyKPd0T4fRVJxxgy0IEMzMEj90hDE4CgWzJAoQdb
ZYGnSKDiHcigB2/wDRW2MAUl9IAFMjBBBUbg3insQBDWqEpkopUJSIxiFJ+gBbpgwYlL9MIa5CCH
NSQDCl4QQxelWIQdjEeLUzwicYIwxB6wKofEygEKbHgE/ihAAQk/sIEMXezCG0AxBBkMYQcsEMSA
w4FnT6n4zy+2AQc0YAKHKaEJFBgABZrQhTTIkGN28APXDtyQ9A1EHtgwAyHaIY9kXCEIzCAIPwrC
j2HcoA3fuIcmpFAMDEMkH/iIdaz1Yel8wBof+bBkQiw9k/TFBBpB6O5EhMGD8R7EvHHdAYCXDWAC
dOFYA9mCAyTgACoElyLhYIAEIKABUGAECwLw6QEUkIajYuYSBzAAGwpCDBlkbwF2ask3MPGHP8Qh
GQqZRL3/IAvrUiQdeAiBCDqAB4PY46np8LdE1uGHMxuBCaUiwQZOS0WDGWzQ2SMCbvjTBSPIYAYr
2MAO/qbQBRqzgAqjYE0pUEEJQeThaK0IxoWsA4pSKKMr1kCeeZQBolNQghXYIUYtOJEHMRiUCDsI
kx260AMjpCFxb9gCgGqsBDY4iQlKMIIJKFGQYHDAUyOoDxCIAATqFYwDK3CY2S5QgA1ASA6DSEQi
XO4HckykHblABCDOwANGlKMexuBDLggij8LLxB6hCAQz2iEKJFihEIRQhTge8g1RVOLyldAENtJn
j1xgvhLGWKdfxmEM5qak09igkKWBLWyJ+KLYEx4IstcBBGbbHqcbIFlZinJTnBagF//wTmf4jFMl
9AQaTuiABzJgCoUUQfkdOETsIdKOSTghC06YhEGg/hGHIvzhGxRRxyMGIYa04pkEBKy4ptpGAQcg
oAKU+9gUqDipLbzhDV1gQg828IZMXGJakcVF3/QheAELlPA6w4MLpyM8yiB0piMjz0AMrJAIUyAD
JKABJKAEW9AF+BJbh7Y3BEMkWAAF+aRaqsUCO7AO5oAamcABF4gBKzAEw0IsMnBxLGBoRiABBrAB
M5YHifAIJXQ03mBGhcADKZACMJACOVAJ76AP2CAN86APJnUHjcAM15IMgOQKQZACL3CEMXAH0uAQ
6WAKjRAEMRAIpEBR6GEMlmAFVmAJzKBrJlIJQaBSKKEPvoAEcCBVCMF63hURr2dsLJUQtOdTArBt
/hCQiA/AAERVVEtRAT4lAwPWGbygVAHABMeXBR6gAh2QCgrhBB+gAh4gfSARCpzoBdhAERojUFll
A6ilWgUTWz4wAxrwAAhQABfQBV70BrI0BWvDBJnQS7jACW8ABBewAU0gBpGGJviRCazANKeTLosA
CrrwJzsDDMLEGqdTFdxBC5TABBCwAA/AATvgRDswAiSwAz6wA2ZnAiRgBGwwA6flMCwQdhywCGSQ
XliAdRfIAkOwL0qAdCOwASQgA7NogQ7wACOgBFjABoOwCJAQkZlgDhHxDo0QA0jYAi2QhFrQav8w
DrsADW0QAzAQA2eQDL/AXO/ABxm5kRpJB5PX/hD2wA1SAGr2cBj6IA+AgAjyIIcEQQ+VgASiMH0g
oQ/G8AR0wIcH4YcTEYjTN3u1h1MXcBDmkAcG4FMjcCzq4A3g4A3qIHrwsA3P0AzPYA2UdidcCQ7h
UEYD0SBdqQ4yERVTYQ0KNQ9eIQE+ZQLNEA4ZQhD3EA6QsUhecRAXxJXh4CvzIBresBzmYJh9IZfP
sA31Yg6FRA1neRCANRU5gkjooQ7k4Ac+5QPz4A2+Ug/mAA7gsA3mRlpSQZaquRA3MhVlSQ6iVxDQ
oImc6IkJAYqiSIoeIQ9/oHxj0EYUEQxsUGMywAGnRQRUxAIO6WZEoIMEkIsvtwfld45vcHPb/iBJ
yjAKZIAB7+cDS5IGSkACWIAKqEML5kQLpRBpV1ONwAAMd6GNugAMcyUzl2AEDsAAD4ABJGACnlIB
LPBPaeIfQzCLKkYk6ygDKChoaGcEQTJmn6IvRmCOA0kwnoIBDrAATEI3YqBbCbM7felGrmCEMHCi
J5oCV+CR32AJpnAHd8AHMNoJniBV70AHKbCRKNoCMaAJnKkQ4lCToWYQ9bCTRJkQ5bB4KjEPzJB6
CcGUEkFsglhehBiVAUABCYEFPlUBOTEQe8BiJpAHl3kOukAGHOAACtAAGNAEo7BTBXEOFDcESjEQ
wXBaJiAg4mcCDcAAGpAHxwIMTDADjRgA/ghAMIlQIvjQDImwAxKwAAsgATKgSsL3D+uwBwC6A5mA
D4uAAQfABI/RBUYyBMcwD5egpw0wApRAI/MACzn4qE0ADAgBDqPABBr6qDaQCMdSlSPAAD61AOeY
Cf+gDFgAoCOgCwbhOXlgAg8gjiSQB8FxEPPQC3JgAhDAAAxQAURACdC2lLjZiZ8YiqO4UvKQDuRq
evaADtnADeMQe/rwDuSaDt71YL/gBB7gAVmQDBCWDxKBD7QgB7nCAkrwCT7AAUPwdIjDjA2wAEMA
Cr0QDLUACVSAAURQCxHYS9hxDImgAQUgAUbgB5dgCAzUC2VpDc3QC+Y0ClI3CESDOrzA/gvEdDoN
2wu8cBetIAgscIzXQwGnRAEPQAJQoBsjKE870HQB2QNAwI7/CCAEIwbfswdvQATwNARA4ANAIAMa
MAIBcwEPcAAEUDYkMARQ9Ep2sAeGcG0NwQ1lgIQ7CgNI0Ant0A6xAAhVIAV3EAiFEAhzMLd8QArp
4ApHAAM6mqJPgG8NEaSgdhBFiggTJhPLIXpmARGxhhAyARaRYw+xxpmUaxCxBqUEUZsDARZS+pRV
6lNYihBp4FMcoHv/QAKoe1//YA1NcHsBMAKwShD5hVMCwF//AAqkWwtKwGypOxCZMKjLBgSISQkL
cHsHkAibFA70hVNMwLu4J1cPsGB2/sBseVAPixBuAPZ7BmENMnB7FFC71rABt7cF/wALvIpTm0EQ
85AIV8lsBXCoBREPezAAt3cBvKAQt7mJ3rqb4Oqbv4AHBGwJ/5AOqTAHTuAEYxAK6FAQ7xAKBIwH
oTAQxYAHWeACKiACOjAGeFCjFAEOsFAKuKAOvWAwuqUyb7YFPUABMtAKzbAN4KAMrGAIJJAGftIM
kjREvXAJHDAAGDBGo7AIYtAKIxsaypAup2AIlJJyDVgLVgMLDUsMwZAu7fIIU+CCVIQBPWs9GIAf
ZWV+6vhwWHdnqgWQPmAka/VATbICP5KgI1ABGrAB1LafC3AAB1AB5bgvTQBFXSAI/ma7EPSgCTmg
oy2QAjEACMbQhMygBV74BEgQyU9ghClQBczQaYzAAxqJojAACKa3EIY7pAWRuPSAacxwC9IwDrbQ
CavgpPfQDtwADcYgDfUwDcZwy5eMDb5wy+/TaaZACr4gVfLADcwQktjgCrbQDmBxzKLgCq4gDfcw
DrLsC3+oD9xgC6JACp1wA62HD8dMCrmADROGD9UwC6JgCpUAe8c2ujhVAYRJDL0XAFggfCtQX/dF
DhpgiOLYAPiLUwegDASxDT5FAIlAEKPgU5AqAAnwAMS7BX3BChRwANwbAAJwAAVgVFUCYAbgAA5w
AAAmB7oUvhQddlipDscwATg1/gAk0AAH0AATbQCGwE8PYIk4NQFs+Q/wMAID/QAOMKgSIDHeYAQE
MNEDkAAEkAf/kGA+xXUE4QcTrQCLCGBMVRaZYIgN8AAz7VMOoLrb1626iRC8Ga4DgQkfUK9O0A54
wGEeUNYeMAafnA5xkAHLV3D/4AkWsIkqoAIfEAIZ4AXgdxHEsAMX8EpwVnKztAMksAfycg7g0Awk
JAaGQBrq4BihQwyQoAEDMAJvsAjjZwgyMkml4S2ssAhpAAkz2wubYAeZcB3CRETjlAY9AE9kZwIS
0AQ6hn4mkF54BqD/YTb8wo5AMCxGgNgsAAR9bH4hCARcRAUyUAENgAAtDQHL/koADmAD9JQGDlQr
g/A3DfENYBC4LcADT+AKYdEOlvAEN3CEJ5ACJ7DeObAEjfDA/5AMVbCFO3oEhAvKQoq4RioNk3AH
T9AJphAFNSAEk0BS75AMnQAIXNAJ74AJXHAGXHAI5UAKXMAFc9AN/8AMdyAEQmAFu3BcnaAHVTAJ
ZRgFpdcOjRAFS7AEUeAJ8LAKiNAGblAOZVEOlVAFNVDgX+hd39AIS1ADVtAIqUgQ2aAIQV4DR/AC
U9rU7BwADVALeYUKpwAKfoABPjUBwEcQ9YxT9kUQRqBfjhNkbFAAWwodAo1TBG3QhkgAJqAL1uAH
NP0AwfAP4fAt/4VTGHAJ/qAA0MAw0RiQCY20CViOu7QwEOEg0gKAAAQgAcOSB/FADChN0QJAArqg
DM+b0gpgCNbACgrmUwA9EJxgiGvyDGygX3ZAWscgCNWLUyPAZCSj1DjF1P9ADB6NUyYAC9vQCzag
X0P4D/fw6QIgBseAGqblU1TwpF79rb25Up6gwSrgBIfgAdenA6EoAi5wCAQBcJsYAnT9CjqgAyKQ
1y5QBN43DhahD+7wBg9nCMpoByY2LD+SCcDwDDjSC5TwQPFlDs3xUpBBCSawAFtgNaiQCZSQHdag
DZL0DMDwjLVAC4txHajgB2LACsFDlkn8CXkAIU3AAsKiNhewBTfrjgID/qAy4HFEcGhoxZwyUDZM
YASC5lVGCwQ3RgI24ANK0AWIkwYjQABFPW3VWgAPALZiQLaKVWaXmRDcEAiFDLgw8AKE4AqVwA0d
pQ/tAA2F0AafpwltUAjQ0A5mkQ7nrAk3EAMaqZFtwAw/ahChzN+KywyRMJJPcAeMEPdI4Ar5MA6u
EAl3EAORIA/MEAgxAAa/IA/QEAhaEAvtwAxnwAe7sAtuoAXSAPd9/wRuEAYtUAjJUAlm4ArGQApV
EAvd0AmIgARSgO768A2AAAaasAqi0AYpIGzZQAdtQAqkgAYxUAjeJQ1w0Aad4AqdAAYp0OQDgdQI
UYiy61MFsAJbzuX2/jwQyjCo6FsQgwBgmPMPaR4Aaz4QB+1TGOCm/9AFhjgKBXEBPtUDyhPPCWB3
uoQAqIvoIp1T4P8PwDDpAZAA+/sPuJC8S0UQkDDRACEI379/aR5AgECC4D94EAI8VEhQG4eHAaAs
/EfLQUVKC4FUXBBuIT4GFfMQnFeRAMZ/1jBwkOGH5UJoWTyo6JBq5kInH1R4OESPoCcXKlTQcHEI
2zhTNIx+KCL0Xzo8N0PgITiu2J+bH5ykKiZN3k6yM/VZw9KFyaA8hth2GbJDAwdIvIgp67VpzxY7
vLapgxf4nLVnoEzsYFVLF69RlHhZ27YN3DZqtFrR6oUrU55SuAxR/tlS65iyZs3wbhIzRQyTGUao
YFFCYgeHDSM4cBixg0kXNjOAQJkyBYoREixsKGGihIUGEzJ2APGxw4RsIky27PGzhwmDAg0gSHig
oIAEIlPYDFq06NEgSufKLiw3qU2bGyliANIUqZCVO6TGtUtmkkCM+aedV9LRxxc9KmHmHV8C0SKQ
RippBAn7wGhDEWn0KUscKYJgZqZ6AEGEHnzscSUGNKC5B59kggBEHn3ooccXHiIRSponwuDmH3oa
6USfdABBYpd20tGEB1XksWeXGK5IJhk3ZpHmijbS+UeeTpLBhx5xypCinCwRiYEUDv+x8Y530Kyi
k3roqSSFJbKZ/ooPHm7hUB9VcpBEKozSIGudjyoitNAKHtnmTIJWqIiEbQgiQ4CHBCBnpgIqMoKg
bVRKZKFRCAV0oUsufegSjCqoaAd1CFJngIrsYAmfNyoywJ1/wpGhogMyYQmYCSoawhyC4EH1IQOs
WcgcAiraYqB/tHnGGm3WWaieISqiYKFnNqiICYw04gilBypiIx6MFmEiuU7/qUfSAAQw5JlV38Oo
pptyKqunn4IaqiijvMDokJtE0CHEqapS4SqMPOngpzG+oTfif/BRhg0qmMhjELfyeGOKGSB44A1U
cEElEz/YKE+XcMAJhxxywCHsEg22AAWzXlr5BJRjrOHZml5G/qEFl2BooYQMJqZYYQQlYFFGmWea
5uURMbrogogZpiAjtY8rwO234LAQQw4mTPDBCCKAMGGuDZqTQQPmeiDCbB9kcI4IJZpIY489sNBg
AhZYuECBBhqgwAfzDIHkkkwo+YRaeu/5xhU0YnhCk3TkEaUNX1w5Aww+9OiEGXq6KeYOX7qZh5lO
PgejkmQQ4aOdd1S5IgcpRMFmnvc8BFFEEqVyJYdK6iGImyfOWJMgY24USp5CeJjlH2zaCNGYG4K4
Q487rLhBFKGcJESeecq5Bx0wbkCkQXTG2gcdNMKU/oknsKEpiDrWlOebNemxRM5p/nlRGNCxEBv1
aSbe2omg/ioigAUowIEONIC7AnABVNxjIYyCyKP+MYKKXAAeMyFBRSSgKU55SlemWggrGlARSJwq
VfM6hQSJwRJ94EIltLhVrh4yAZFgxFfkwogGKsIBcGCEVAGYggUXEo5eoGITmcjEI4T4kBESZFvd
+tZGHtKRf/RCARUZhbPKco8QVgQDUzAEK44xr7LYCyc6IYu+gCIVohhFBbtYCD+SEQIVEAyPB7MK
VhaCiYZ5wAv0k9h78IGLNDBBDm0xhCDywAYxKOEBDNjCJVAxCkjsZQUkuIQ3CKMMamjDGsqQgwN6
kIhW8AIYx+AFJ0Chi2MQAxegKAUtgBEMWDyCCQUYwAAe/sCCTBCjNMo4Biry0IXUOIcMeWjkDC7w
EoxBEwuvEYMYTMABEtimAhKgwHcqUAEKYMAGQDCC2YDQAx9AZwjI2cJqtmkEKMxAAUPAwgVYgDU/
LIISlFiELnQXsXJ4IhCigIZQ6CGKQFjiDksoEzoG8g5LnOEHZ+jEmvAxDlEg4Q6IaAQfsHQPbKii
EJPghqJ24qEbGAwj8wBEIYCXA03YgyAeAkM7FrI8HBHEFzcAxDtMEQidugIGdPCFMZRqjHEQxEmO
oMc+CGIPU1gICYXg0j/a9z4xLS+nWv0HNOyXPILgox2N8J+eYnCHsfiUBwZkCQ4CNagAMKAVo8Dr
KEAB/oktOOQhDKjFBRulwXE9ZAcfZAkTaEXChxBgXf/41EMWUIosstCFhp3XICQoLJZYoyID6Aiu
KqKBmfzwISdZCEUeIoMeEuSIUFDiPUAhAwQUilBV/McVH4JAgoBriwQBxQEq0guJ9WIBthWABJjw
idbOxI34iqNP5tgvo7gASwv5RsMIJguCUCWQGCHkTw6ZyPfItglUSEQe8rCHPMghDUYb5yBocYyf
DaILgLMDMXrBi8UAAxi0UEICRiCIXN5FGby4xCMgsbhMnIIX9C2FH1iQAGBSYAZvGEUv9IuKQYgh
DWkgAgd6QAY5bIEIJgCPCdIgCD+kgQpNSJcSZICB/gt88yAPWIABDqAACVRgB+lMJzqncLG4HW0L
WGABCZqwmgqIgQwaIIES0pCx9DBXpWWZET0sKI9qrAIMYIiEKe5wBkT+oxy/CMUZPPGLcpwJG3cQ
RSceuiWd3oNGV57JOKTAA1/M5B10iIQSg1fTm0rhq8pjXnfhUKRAuGIgqoBBIWQ0k6dGdSHyMAYg
jkC5Pm8VfjYqg06lKlY1/eMe3NhFJQqhhbSSAgZsJeBb/bSQEsy1IhUgSy/8isSBYjAAjiLICh8C
BHOxZAoqYWwAHGvCv6Kisg9p4UKKFQBVEWQPErQVSzb1kAEsIodDLO2vHrIHjKg2ADNo7muV+AgJ
/g5AAQxQgKuoqC1u7fbZAeDiJgxQkRlKjBYmYIAECcUEDTrXJm/Ml3T59Y86qsAFYpyKdnXwiu4i
TGGDLOR4yUuWe7QCayZTL8eyaYQLEAEW1gjHM1jxiDeQoAJyYEUvnvGMXrCiFKAIMAbYQIlWHCNa
z6jFI9jQBTns4RJBO4UhmlCBBySAABygQt4eEcVlsiEPW3C5DKAAhR6kjQEH0AAV2GAxJvRABknG
AJRJsAEaT8ABCjgAAygwgRkghwlnw8Ij5YAFelJBDFQ4O9amMAIMcI0FQMCC1QWRiWdAPJHtqMRH
23CHkE4CGsT7xzxSMYc71MANd1hFW/HhikAU/iIQYCgEHwqxocfTIQWSUOJCmCGFWCxk0Db9B051
iuieEoQUOZh8j/5xixiAQUws2UelF3IPZsjjHcwgEx/e4WkxMSMIUsCGVMM6Vn3sIgxt0IQvCuE/
NPEADNctP1wxUusE0jVbZBHDEJ+xqMESRAIVYQFiMXKthyAg2csmiMiqK2dbCN8KgGgjiGmrtn9Y
BAkquIVQhs/iFdF6CA4It4ogt9SqCHQzooqArVtZFiryA1BABU4wN9zSrQDgrYzQInwjiFMQrofA
BfLSB1ZgAxvAgAaQt4dQArKQhoPrAFNIuH2hI39xAe3rLomjOEBKGEEiiPAypDLbOBpCiymA/oRE
iCQ/mKQpYAEMGIRgMIeUO4VBSAMS4IA9IIZwWAd12IZjaIVLCLAGMAI/GAViQDlvUIZLEIOXYAEy
8AM/eAMl4IALmIAGMIANmAI5MBolAALfeI0dcAAJqA3Cq4DvGEQSIAIiiA4TYDsKkIAVOJohIAEN
+CYJkAAIIMUNsIF0eac3wA5AhAImoIIuUILDOK8m+BgH2AESswM7WC9YOAc8ixjSy4VKsAKMSoZ3
UKl3SAdouANmQAey8hFsWAU+QAJEeAX9kMb30AdXuAEkmIV2wIcZgQY+CIMyuz2CwIYjaIO2+gfr
6T3pkYIcaATM44Yw4IHQ+wchQZB/UD6C/kAHPjCYcdCCNmgH6puKNngBTZCHfJidHKiDdpAHQsgB
R0uH8VuC/+GGK+ABV5AHs9KEGGAEd6Q1W3uI99sJMri1Y6C/DCIIHQoAB9A/aRut/3ssAWQAAuyt
FkTAf1DAedEFCWqFWAEFlZghCgwAC+wVcQuADCQIc+PAhVC3f6CEBeKFhZgHFhAhesOiAmxBLlKG
49qi2PsHb+AvXei3nfAGWNgDDvorZdgJbPCCe8GEfNiJdigC6cKEIqwulUoHJay478I48ZLCKcSI
esgEJhAEtxCEPZCDLgCCCriAYgqHbSAGSniDrMmDUZCXNQwHvEAFCXMADhCDRWAFO7QG/l5IBCbA
AAwYgSQbgdg0wwuAAAJIAA0oGyCwgU/iAA2Agi0wAAggJwmYAAloABNgBSaAgJeQgSHoARKgAAb4
ROSYDSjbpgsAD/DQAOcAgimwA42JJLWAAiKIze7sAizwAQnggDw4BVzoBV24q14IxinEh0gghUpA
BDhzPIKgB2wwBTAgBWzAPIzQB2M4g0bQg124g6aSmH1oh04IgiDgA1JwBUbQAi3YhYFoh2Igkzsw
hnaAhk7ggTDYBW4oB2OIhBygg104PnlAhCAgEIKoB1dAgmucBVLgg1RIB2NohBhog1tgBt0Rhy8A
BGbABleoHHpgBlc4AiQwBWiYh11A/oIgQARSAIQzaIHbgb4UQARfiIQzSIEgqARjkIffQwJGEAU+
wFI0MIWUWj+TDABc24kU5ID5+wdfA7Z/EIQdhEuMAAcJegObZLYBvLee/EmU2DcenIkeqAgG4BCk
VEofYkqn/AeoTDcPtCA2WCCMsIZEDQAUrDcVvDcuwgcKqAgimEkyeAAHkENWoTlWyLaF2Aa/QgBQ
2AnvakL0wwhZ0AERwIldsEuGM0K/BEwmvLgnzLjCNMxksYM3MAT2eoNK2oAEuABOMCZlYIVBsINF
QAVa0IVnMAd1UAc87IX3BIXB28VE2IRNWgQ74I0uMIIhwAAJYI5twgAIAKYGwIAZ/vhNLGACG9AA
NhiFVQWnl+AACZABa8iDB5AAEqACO/ADOTCCb8IAEkgbDdhFi5kBDgiPA0AASWQBJhADQUiERdAO
TizOEfiN89wBCTCCUQCGZoCMbZi5WN04UggE0AuEPpuJb6gEKYiBFogBKagE4cOIbNADV/gcokqk
fsg8XwCEK1iCHUkfZ5GGnKWDOygEZhCFO6ADOgCEVfiFQvDa7PkF3DOGQtBVesiFO6gCK2iDTigH
aSDbO7gDPogELGmH/LTbO6iEdGgHh/paPsgoeriFNngCMECEYigEOiiEYmCG7bkDTeAcK6ADU3A+
UiiD46mEYgCEO9AQlWK/mVCg/od4gGc4htRN3ViSAQmigl6rv38Ahy9ardZaByVQCWT5h21Ttpts
VJ1kQcuiScxaCNxtLFjAiFHYwS0gCEi9wHErtw281If4QDtYIDt1Byy4La58iBkY1YWgAnchgKG0
ogQwiX3MBA6AAAVArYWwBlMNgAQg35kQmD7SAe5iiXTwAiOEGOpyOGK13yXE1WP9Byj0AjpZVrNQ
hkSAhAY2BDZgAUOUgEXQMF0ABUOghKDhhQe7Q2qoJWUghlbIBLWYginLAzsouktghVPQDhKgV9zo
TQlQAAJoABIwDzmQg2YyBGqYgQVQTxbYgR0ojlawpA2gApL1g9QwAQp4gAZY/gAHcNg3sAM2MILl
YAACGIAD2AASOKcm2IIumIIdqM0FuAAZUIJZBDwKwAJaUAZtCAdxDdd4EEZ64YZC8LxO2D2MeLMY
SIE+7uO1Yr2RyAU9QII2MIY5xjJ5QIdqwIbLwQh6YId3kOR2cEjZeQd2kAd6aAdLbgc/oQddLat3
GIdv6GRTYwdObgcOyYdoHAduSAepeAdOTh6zEof1KZB3YBJ9aAduQAcTaYdykMh/6Ad7aAdxuBxd
xuVgLcn2+ywaG6cag4AdDIAFwKGW/LWCswMJ6oFF+IRFIAJC6QJZLaEA/N1CvSxqYyNrEMsAaIA8
4IRMeAPaDQAIKKJvq8Dn/m3K6O3e6bUIC4IFQjEBTqAE3I2gh9gVa8AHazCBilAAOQAF4sKFr9SW
wgoACvCDbg5VBqiUf0CFiiiAN8gEUOjmb36IC3AcSisCq3ACU5iGTf6GYsADF/DVDvgDP2k4FwBg
ghFgi3PCAm4Yr3CpBMYIfCAGNsaLT8CCBiiAB/ADzOAFUFiEUgiG1A2GXnAa0xgNEK4FVnDM90qD
sdsDSkCFct2EJhiBB7gA3JhNQ3yAGZiyxnwDLNiBRSCH7ahYGbCBs+MALMjBGWADQDSC6Vg7pnOA
CiABH8CCNNgCI5iBEaCACFIA4/ABs7OBHSCClh0PlaUCMmCDNFACDNgC/l1AuXWAh3iIB3eAB0TG
sjfLhVkrHtdLASRwXDo4gj6+A6MtK2zgA1fQByQU6t8G7uAWbnoZXZYoXdtCbga4BDHC04KbhymQ
IAE4omHTP94FQMgqZ68U3gR8IYzghJJQiRB8CAhghSWCyUhdCNPKZw3c5w6kXguKB4oOgAGQlANI
hBY0ACIIh3pQyQUaAFTVBYleCEqIwYeYbgUYhZEwXm4zgAKQIARAoZ2Qh0NQAemiAS/4gz+Yg7z0
1RBwAim86ZyeuMBswoXhI4f7g134hTwW6nloY2+gDGVAhR0wAA1IhFp4z02gBFxQhlE6hldS3aZZ
XUFIjbjBAldEHFny/gMm2IAKWJuzIzwG0EUSYIPF3APPJgJWgAcxaIANAOId0GsNaAAHsIEuSIPn
ZIEeEOLiCOKzM2OzsYG0UQABOAAWmMUvPrLFhoAD0CeRfaQ8oAINMAJUsIZzgId5mAd4UIeBMsxy
0APcJgh5qISgbQNX0I9IcIU2gIEYiASS9BFCsIV/4IfhJvVSN/VlLW6MUAeYRO7GkgAlqGb2DoAN
0AaMgIc8qACBe5cJYIOTbglCEYSF+ARaSfAUMt+H8LaFoGgTYKMXlAFPrYgE8IFYv5UymqCZ6IUW
hJXh/bXmkiAjUCJYYMqT7Ig8IBQEQBZigF/8mwdakOdkX4hMGAFp/lY2Eij2hVgHLGhBQiEAEuCV
9/iGP3ABDxABEfCAEED4DzD4EMiCYmCJEMeIvwxgEr84DtkFHRgYgnGCoF5WfFgHazAHcyAHmiWG
PRhNQ+CFo84EYJhZalCGqt6vY2iGZzANXhgEMtiCKRgCxCODNxCE9EgDSKxYFtDrCXg3WTQCX2QD
pBmBTfiHU7gNdDIbIZaABKjhKTixw7MaLjYCJojFEyMb6LABDnCAAUgAJvgwOfhDOWCDLcAAAzCn
h/UDt5iCCjCBQegFb1gHd1iHMBzQKXR0SH9HCykDaEiG+giCZIAGNIjtGF0IegB1UT/1yaf8yl/m
mZgHpM6mzef8/md6hF5gdFEBGyygBJsliGMQhDCWgR6YAj8ABtL1uy54g7R8BtW4DjslCGvwg3ia
ApZcCEOIpy3YhNAniHPIBDKwmuNgA1CYSYbIhNF/hJnYBuBPjatciEeIJyzIhJl8zKk5BUUJhjcY
ghkggjcgrn9YhzwwOyIQBMQ6BjEA8+78ft3nfd/HCGpYBCroAd/Ygkeo55kACFh5oPiYscMIGUrW
/jFs6JAfw3SevNAI0SGExQ4unByS5pAhpowd9Dkcl6GDxlQR55zMEMdhu0kuLnbIoIPZx5w6P+KD
R04d0HDWjiWasYUMLWW9KCXqtY1cuG3PjgFjNYqXsqzEWBky/pRpFCU5cuwkKgWLVSYxDCBsGDGC
A4UGCQ6QoMXBBxMiJiQk2BHs0w4ZSpQwySvjwgIEF5iwWLGDCBAWMoxAmUJlChMfIx4r6TGiAoEH
XdjIGZQo0aA9cnYYqCADix1BhvLIkGDDzqZez6zxBret3s7gDMs14vbxXaEUN2bJM8ajxY1i9Vzd
aAHoncN6lYwJ7+79O/jw4seT/1iifHeS4OGdg4d+vPrv84Dee29/5/x5OeOpA/4RnjrxkAeggN8B
uE5942EjCyaH/PHHIZOkwkx8DjGDCYaYfCTPJBh6Mg1D8uzS4SS7NERSOqk4CGEq7dx3TzhABWUN
L4lAQswW/pw8E8wibGRijTnkbGONUqN8ggsxxwSDyymUjKILMLygkgkntBCjzDG8lDIEAQs8AIED
ChxgQAEaKCNBAxSgKaYDPejlA2FQMGHEDiNQYIAEnplgRGeOKTEFoJgpYcIMhD3GQQESiDHWIpBA
8sgigxBxwAQjGNHFG28wgYEESvjxyCi1EPOMN+bQ8kyC4t0jjX8MzcOMFCncUUwunbTRxh2e7FIM
HSkgAY1D+GDj4n3FfrSPsckme56yzTr7LLTRSqtsPvK8Q8+0/+hD0rYM4fOOPMnOQ6pv2lBzzCh7
ZAIOE2nwUssgQFABy25EBgPLKKz0ckxWvdACSi38EsML/iuwAKNMM8oQQ8siBRBgQAIKLMCAAggM
UUoBBhywsQIRV7ABCUQwAYWcnXFQAQQmEMEBCXP2sIIPU2AxMxaXrWADn0ZgUUEBD0yRRx6GOArp
ICQcQAEHLABBGAsQXLDFIqC00osy1GhjDSqohIPPeOV0go1D2BSSQw62xlDGOPJkA0YMdIjCwwuk
xCdPKMmgZ4888qCDXbP35J0OseTh83c6FWarE7OHK7444407zrjhJ0ILDzXUNEOVv5/kIcYgm8mR
hxISPEBFqLjA0gor+ipjzZDK6HKKLlkdQ0wtulyZ8DG6ZALBAQh4SQEGFDwABSgCJLCAA6Iz4MAF
GJBg/kSgUzSxQwWVAsGYBjPI4MMOPWAhBvhikIHFCDYMMcQMiCLQ6Rt7+DGIIYks8gYGCFDQlmNA
1DaCH1dVzds2lNEKVASjQODRxy2CQIoT5QIJLTiCKZCQgi+4KB1a8JUpjpCC6zQEGktgRKvCg49d
NAIQZthF5OxTjBKGwRX2KA82IlEINDSCb49jSOJuqMMd8rCHO0xhCosFj6koiRetOIXmdnAXzFBP
YiToHypSxwpU9MIa4YAKNQYIjGYkzHVYeQYYlRGMS1SgAQ1wQAU48BYJaMAPBFiLBkaAgQdIAANJ
ux6goEAEElBAAyywgQ9YMIEJaGAHSjDkFsRHBjIo/uEtHLhAAw4wAAVoAAppsEMe3CeIQbyBAwpg
I8z4RL0dUCJ21vBGOMyxDmXgohe9WId45iGKI1QCW/+gRyVSkAIteGIJSGgDM7CRjDMEYQmrQEMK
woAOhujDF08IRODCkw9fkIIOMYhFEL+jD645JBme4EPcXjgefmTDE4WIAQdzIg9uZiuHPnwnPOMp
T/QAMZvogce+drMjVlAiDRrgAKa2MIMNsEBnkKBFL4LRi1pwohTUOIc6yNGM1BGjGc+4HC+oBsZn
KCUPF4DAAx5QARKsYAQSoNQBJHABEphAA04zwR93AAQjGAF9JOCACWS6AxNcQAEKGAERiAAnKmwB
/gtMGIEGJCABCIiJAAnQAGzy4Ac/bNIQeyBBAiiwJyqADwoY2AEnjmFFdbgDHvNQBi+uBEsRlqMa
3+CmPABxghTQIRvQYIYporAEK5gCGtDgRq9+9Y996CMd2OAGtpAlHnzQgxQ8wCY9mQGNCuGjHrPg
ASnEKZ5+6OMeyQhCOhuSj2RUAliHc+c8U6va1cYzm/aEjzqIYUVygMMawEjLBUZAhS5QAQpdGIQf
DAGLYPDrGL0YRSJokUpr1IIVUxNYL3gBjGPwS2GX8MEG1ASBCWxgAxdgAAEKsADgjYAEF5gACXqg
XiAMAQg+6IENZCADQAJhByzggAMSsIEZEKEH/t0DAhBGYEYKuIUCCzgAAy7ws03CT35yKCMH5EUG
sbBBMpBQhjfUAY94zAMewcAKNdwTHmPEoh2x2MUL26GGE5wAEPIgrHNaEAS7/eMdfFCOMUiCDVKk
wxemeDF57EGKHEC2POm4AyP04xB92AKzmiUPM0BrQ4aMow1VwMlpWavlLXO5cfZ8bXj0IRRzqGMd
5/DGM1jBBg1UYAew8QMkOCE/rHQxd4agQh7yVYpWnOV0rdCFK6OErz0ogQTBW6oDQMqA3knsYxzQ
ACF3MISgGoEJgzECEHqQaffagAUkSCoJZtADH3R6BSaYQAIYsAEgrIx3DZDADtiwh6omwhBK/liA
BFZgSakOQhBGkIEfdDHWdUQlo9YAh5K/Qw9EVKEYaKBDO/ZhQRbzoR30kIcv4BYEX9CDHu24MQ98
sS1SJGEXgJCCcYI85CKTJ9taGMdH+NHkzL4nyqFlyC2SQApbtrPL/v43wI3lWnpuq+AwitE61qEO
ofQiDxhogBGi9glQgOURsFDGRtE6iB3YYAqCoPgjqMCGRIACobzABSoM0QMNbIADnHJAAyo2pgOI
KaUYYDOB2UtTIiihCXMKKhF24IP67mAHK9CACS4NGSDYAAIJeMAG5GvSRFXABEzIg/wekQg7TEoC
PuhCbBLxiI3LQBAE3A01iDS1Z2wj2d4p/ocbkmCJKGjBOOOQwlzBkAtA9AERmiBFJwrRB0D4Ag4p
4EEu9FEPRtSgEmdIAo3HI2Qig1kn9GCEclD4kHk/eTz2nvK3CxHNaaE24KY/Peolp/qCw6fg28IH
Pu5xjzInXOFCAcYimGADSLzriJy4BCdgdyUxskIQZBADFdRLggo4AAqLQEUteKELWpRCDku9wEfN
CHMFGAABcxkAAV5dPQlYqjCWHgz6BwNgOGGhC00wwQj+lMcpGOEBBkCjBjAwgQUYAANRV0IaiN0i
+IEdGEEBOMAOiEEeCIL8iIEfDQIsXMluHMMlxFlSGJB3yIM0JIMwMYOL3F0LtMATeAIP/kwQOtjD
OFzQDZjCFaTAC9iC4klDMWADMyRDOZTH5LGbeIgDGBwBDBRCuDSEvDlZvUnZifgCMDFO6aUeEzah
lnHLiahHt6SH68meFVphPawDPGyhO5jZNvCCHUyBH1BNL+gCWkBCvvAZLdACK4DCI8hGHniSwxgA
E1wCLUwXMfQCK2xB8ihPH1IABCxAAiSAASxABXxSBQAiBogMoDSBEgBYz5EMERjEFnwOGyhB0jAB
FWziFDTNAuBaIubXARQSC1zGaLAB0JgAJQHBFJAB0EzBo7GAHLQCxlEDLrCBEVDBHqDCM2CgcIiI
B+ZCOXTDK8hDOVQBDEDHKjzBBLkI/jp8wQlIgSsEQQvkgC3QQzEYg4hIQzu8QjqoG+WVhzFoQSTw
wBWIw+YRIXp8XkPQQyqEQuUtixPOIz2ulhS6nuvlRMHBHj/iwzZdIRbOwzbEiDoESW3pgh00wSL0
QjOU4SlAgh1m1PThQnNlwiV8giGMACFmzAgYAvSVYStcggYc4AMgjwRQAEpKgANszAGagAHQEZo4
gNWZn2aMAF40QRMAAQnEmvvkARnslAzwHBCswAbonwMAD849AAZQARMMQReQARvYwR5AAQVUABCI
QabIQRpwAAMAVRqMwjNogy68wRSkwRvYAStsg8IhSHe0QyCQAjTcQTL4gh6gQzlY/kEKtAAPdMIZ
xAAapE02hEELwMHbwEC4yUMkNII4AEIsSMMdeAR44M07tIMohGNDWIs85INi6YQ+kIIZNBASYBlD
DCG9NYQ9vAO4xEe1XAtDKBY7MsQ9SFYQKs4SplY8mIPbjcc8mIM7BJE+kFk8OkQ8KEM4PEs9hIOI
2cduwkNwnl49kIM76CMzvZ4/wl4+vt7rXWHsXWE9dGc9zEM8sE44jGdtPQMw+EEFGAEtUAUvgAIl
oMLwGRcu4AItZAIopNwGUAyCNYAPDEK+oAIk9MABhN8DnJEDhNSXrCTEMMADHEDE6KeqCZ0McIBS
cYAhDcp+sQGDvYESyJcJfCgJ/oRodmkAS8HUW2yBIbBBF7yPIaQBUvWAGAgCJWwCKGQCEzAArJVl
raVBjFICJHgFKOhCdXUHNCABHHRCDMhQEBjDOzRCEOgSH+wCKVgCH/QBH1hCKPgCILRACoABNqCD
FkjBKvAAIHQCD4hCfWzmTnADKRQCHwACGFgmPSRDJARCIbjC6MHEHVRCOqhBC4gCO5GmOOFDNYhC
IQBCIyTDtqSDKxxqJXBjQ7CjPrSDLSCCHkTCZNFmd6gDWumGL65HbpLHPTzDKSyEcOADjfCCqh4D
OZBEONBiCDnEPRRMrHpHPABDL4SqQ8ADWj2DkmmDQp1DEJnDKBxDsWgDKihD/q0Khz5ow8AEwzbo
EKdmlK8KhzmcQjDoI7e4nnXio3XCHkDKnnfOA7nOQz3cwzyEAyqRgzlERUMOAgNUgCHQwoeVwifE
Dhhdji6gAliAwifsTMxpwCP4QZ6lQRdAgYAZwEvG3AI0AEyW5AF4iaIhwFqgyZgw6JcgqAQkIoNa
XfvIARUMAUytwHwNgREEUlvMAJxMARQoQdBAgmqEYcsRARn4ASWcQvQthQYcAAYoDaBwDid8wihs
wo9yAtUoQ3cwwx0ggie0QSdEAh0YAz6kwytcEBLkQj0YQw4cXo7twpNqQTLgQzkcqivQQSSIQhuY
QpoGhz4YQxvQwd8hAhJc/hNJNFYVNMIsREISVMJsfsQ4GsM9aEIKtEHgCOo/3EMunMGdigISnEE5
xGUbiEInXMETaIItsSM3mJDkakEYgE2W7QSqlsIo0GfJmcN4wAMsmOp76AMFPkN33MNSTI0ujMIo
eMM/pOs6BFE90OiyCodAJudOqAMrQAIonAND6MIlKEQQgQPvFYs1ZEKuhtkxSA0vjEJYPU4z0O70
SY06BEc42GF68GN8bNM2bSdAjmu5lms4bMUVkdk6mMM2UEMv+IECNB8n1E4rlIJubNTllEL8JMIW
cMAEMBUU6NM29EAFqCQDIEBKfWKa/NMjhclRYt8DMI8GsNlKFsABiF8i/oKJAiTKThqBz+nFCvRA
pU0B+FBBnfQAEyTSG6TBIxAJMAgCTJ2MDNTsI5zCvmQFL+yAfvkAFIiBhn4F7RItJBzJ6gjHPXBD
OowDN7TDN4xDO2SDfuCDLTwpGmCDc6RADXCgGijHLdSD2KZDOmRDO4xDN6TDN0yZTmQDGkgBNNjD
pCIC3bZtErTBN8gDNnzBFcBbTtBDJGgBM3ADdYSmEHLeP0DDFVwBNuhDkzZCOuTVvskDIaCAGhDL
5+nDLlSBJeQNHZvI5+qEO1CcN8TDEHECMTDEKhGnKisDOJiDRenHOvTCJbTCMdyDOSgDOVDDNrhq
VkRrTqCqMmiDMlyC/uuKGcKsVUPgAy/8yHcWczDcgzs0wzbUxzycizKIWD1wAigABz4Qsy4vM5Go
JXHeA5G4xzwMxTMA7z+ow5T8yD/EA1oobztjiTUkSDhQQi+0sis3hDkfwzofLjHD0irZ7vMCA3Bw
6jFUczw3gzVcTYLEAyeMwoaFg75wjT6os36AgzJ0bz3bbjqLFXCYM9tZAyyFdEB/RDhwgtZsoTXU
coKscnH+QzhkAi6sUrWq8uWEWGfpgztMxTqX7/l+Z/qWqymfgwBdwjHQnpl5Ayt1Qf2OgB2MLi08
CTVsFEedwiMcFc6BCSWk3SmJwVKpZMUwQMMizYfCHyQpZYhWQAW4/sUIbEAFFCiOttxbGGUCXID5
nM8QKBHONAEV2IEfqEbRMQEWsAEbGKw1qMM5WIMcjIAMfNoO2AEkqE5YbkMwDIEDGIUcvI+TiG4F
gkLqtIJsCQc08AE0xEIjjEMldAI3FAJ3/IM8MAIMyMouFMIdKIK5hSAjYEs6IIIxJEMhcIMpKEI5
KMIqsFMwk8ILIIIt5aDiIUIKVAEgAMIdBAG6xZs+jAMaIAEaoEEY5AAMdII4Cao+CC4jhMukvoM+
lAM2YAclo0AZYLIRtsOw3FIjxIAraKpO4MMzUIKxwiY5uMc2nEIUjQI1/MM2jMIpMEkmEEM9uPN7
6kI9PMMnpM4z/ugDMYh2G0ZzsBADS9fCKWQCNeiDMvwnK8y0tzTzTD/DJRADPngDKPTC7MECKNh4
KYDDP2xzN9eDLnzCAI0C0uKDMkx0c3FCM/h4KYTDPPDChY8CLJhuQ6jDKZQCKNzyNlT1JSyENZTC
ngGMe+TzPoNDKaBCK4xCM9xuL4j2KLTCOdTDcUWrNmxCKh+0OY9C1oCCMtzDOuA5K0A4Q8AD8M00
eP4DPuhCyYVKPHhDJhhrPRzDJ1hDPNRCvoxCMJirk7MCL7wvvpy51nwEL0CC6v4DLVwCOfyDNtBu
GyLt94YKKmxCMHCNNohuG9KC8ZJDK9wnKGx6Z2EhURe1KW8h/jx4w8LQ7jNoWBduQy9kAiZecA+8
wSfAgpkjTBcRw1TZgUmJDgW8wcFkhTKwwgZAAJgwgBlBwP3AFAuwgAlswFJZKAtcAImawAp8WgdX
XQ/0tQmcTLziDPoNwR8xolT5wRYchMws0hRcgjewzjN0AQsYXfnYQSa0AlY89Da0gg1owBbkwSJk
AiRsQtZcQtQcrXEh7U7cg2ORAiAggStIQRiMaW8zBDNoEAxIQSBUwrlxqSE3UxA0QiX8gCnQgcov
wR3k6WUmRyeY5rpNahvkQCXkgtPfgi+w8T+UgyhoASkYgzH4Am23wTf+g6DKw42ZAteoqbbcQztU
8nzDvBEy/pM9tIMi6Dd/58Q9EAM8/wctoAJ0siE8bMNEW9EpcEL3EsMlKEN0NkMmsII5HGcm0MI6
uEN9AjNDqENDEduUHPso0MI8eMMo9AI7MTMlwEJ0AQwsbcMm8MI8LEWIkX4rdCc3V/glBAN7oMIn
ND4ogMIVscLg10MtfAKTO/RZDb5DUDkr1AItxEMehqQ1uMMp2D48UCCr6/M95LoWUno8bEMm6AI8
WIOQ3wMvcII2/MNL7/PzBkM9ODVEeXkXfsImbEM8SKEuxBkVWQNJbINSp3MmZDMnsMI/wMMUrcMz
IDlA1FMGyto8XZSUxZvXK9MzeNY41Yr3j+K/UZnWVfyn/ozSs3msMoVTR4sVvHCXRoELB2rUOnit
CMJTlonYPXPKtMGrlcnaPZ/15gUVGi8ePKPu1iV9xqsXTFbEwrkjd+zSni5dlKzYYYRJnkyQRhE7
dqzXpi1KMm16Q4XMolrAesWNa2hEAwUOJlC4sIGEjBk7dswYQQHCCCM9MIyYMUPGihEbMFSowAKL
GCxGZHCY4GCDDyWfiQwhQgSIki1ioGzxIUMJFixMBilr9uyZMjYkALOYkSbRKWXbzIVTtki3n0uZ
Rm3adNHQJV3KrEWvrZE6vVVwQjWis4pPoeud5FF8xydFixTlz8NIQafdP3y+2nTq1MYUIjqm7iBK
R12j/rxAKUSpyB5ScohFn3TA4CEZffijzpcnAgnvH32gQSIIYyjixxYeSLHnnTtSMAUf6vBJJ5lO
CnkihTLa+4eZIAB5Z8J2khFFEStycKXBHXnssaISdqwHGJ74WwmlUS7ZBBxvIopHH1xC2uiSZxhs
hqYRj6HEGoqsoYSYivTpkpd/7gmmIW0oyeQUUCApqSJ8eKEElrhGIeifbTjpZZ064aEIFU7WqYcT
UOppJUopnyHnklom5EiZemoBJZx7lEGlFE4oOYZBitQ5pRVlSgmHlWd0uUQbazLpZcR1MmnlnnAo
6QWeTI685BJrjsmEGvfcCYoXTrb5x5pLgBE2E2Du/iFHl1OQBEUddUBhZR7q4nkmUkg20eWeYyD5
pBRQHmkFn144OSecPBfq9pRNHjnGIE7A+WcdVFDJCB9WPjlHo+Tc0eiZS5RRJxNWKIrHnVcvgUWf
eWj5hJxwNsFl2nBGaQWpXkophdZn6rkHKKHmIcooeJBa59lzlOklGF1qYYUVVFph5ZJEBtljkDym
MAIKJioT441BjlskDzKYeKQWVEY5BRZYYo7ZZVQgeQMKDDTQAAMOWACCCCOI8GEECSQwAQggOCAB
iCGA2MEEEjjYYC8l2EgDCrUvUGCHIXYAwgciPlMisB26GoUTP9KgYotB3uoFGGKIgQS3HWTogQyv
/pQB5xxrdHkkZ0FKGUVwShYZxBBUjnkmum222XXHd8ZpZ5x02vmmnXbKob3FezRpQfcWYOi9907o
+Yee1sup/XXb09lvR3oqSYGREf8ZkAcD5aEjhg57lAeRGHSs6MMUKgleQw7toYeRFCIJHsxdzmij
klnoQIFFil6M8b023H/lDu597N//f4DUIEplohlgmhgnRiEb080DT7yYhz50kQlyIGpEVlLGiHpx
iWD9AxyxAlOXirWthnSpFc+YzTbq8SZe8AQo6mAFKNbBpF6cw1vT+gdIziEoQp0iE+qY0L+UAasx
6eMZCIEUKMChjUygglSZ2tQ/OsUKUfVCUrww/tUzrvQPeGwCFfWAlawuAQplKMN06mDIlioyj18F
a1jFQhUx1sGLTfRCGXV61idgYUPqzMMd2/jEJcARjFg1YzbauFMmyAiseqywF7R5hjnmgQtJ/cMc
o2BFv24oQY20ghI+rIggtWGOS9CCOuHIBC7+MY9aOMwbmeDFPf5xDlSw4iaZgEUzUNGRenwsKEU5
SsnUcQ5yPOwZxOBFLXhBjF7gghWe+yMkLvEIO1TmDXIgwxvskAdDLCIRhvCDGAzROc+B4hOc4EQm
0EmrS1BCEBvgwGM0YIIejAZvHJAABkzAAhNogAM78MFqVmACDmigAhPQwA6UAAQWjGACKzBE/hdG
gDUiTOE0WxiCDRKBHMHRCjn0clkraHGKKbAAMEz42SNOEYxj8AIWo9BmJhIBTUj44Q15gAQulEEN
a2gjHMHhkSoikY5CmAIbgUiGLwpRDlGAhyK2yEEKfNe7FsTAFiNCKjciEYlxIMIW0giENGbRiBY1
yBc8uAI0KJIOQhRIH/gQRQzUgA2KHAh6FeGGFs4gV42QAgZo2I8+bkG+fwT2C8z4xz72ATs6FOge
7eiD/FrEjBrE6B2AgIEq7lFZ/lFkH//zrEYC2CBzUMJVnEIFMMxRinpBcVLa4IQDIahJqjyDIhYc
URGVQRFlQKKAc/XGKMlEi4aAw5VkCsc5/uoKp02EoyK0gIQ5ZAgPVGSiT/ioUzx0uEgNUiSD2zjH
JVrhHmAA7Ijb4AhtuZXbinQKFe5gyCjgkUFtEBcWIwKHc/DxxXmAAhTTUkc44qEMgGmRF4864z+a
sYhgGIsY4ChFSfYEw3XgUY93ogUa/1ELSmgDt6n0hg/hYcmYzeMexNCVFr0Bj0hOEh740lc8OpeR
ihSRF5uKRzn5uByKPAMX7jAlKlX5CXPQsBXT8ka21hFBa9SDFpSgxi57OTKSJeVk4QgHOLZxDGWQ
hY60IQtJOPGyUQxicongpiD8kIhLcOITmVjEGwxBK0pQ4hHc7KYhBpFn0bWTAyYwgTu1/rIDG5Dg
AvwkAQlGcAEJjIAFMoAcoiNKUApgYAMbWAEW8rAIKDCaBUZgQx7yYIcm9MDMi1jEIyAxZ1Xb6jiZ
MAQT8kmFPYClFbpQKTFaMQpg1LFmeRADGQRBCV5QYxs8Vcc69EWdzraDDk/IBRLuIIocVAIRQZhF
GMBQjPC8qDy6Q08QkiE8RvDAFWG4giuCUAhS3IAUgFiCYXfUDkTkoA2kIEUhqhCDQvgidtZrQyx2
0QlFcANM2KjEEgphDBlNiBuiuAG7uQENTfAAEdBoRzr4EIMzrCLgjZDGHWBQCWZ0QgopeIIrmFEN
U/CgDcngRiHQxwxR5BsRxRjrZz8b/lr+bIsSrBhjcqixLeccYxS9uIdrdfFAKDFXwKi4YDMABst5
XGQsy+lTReJxkWCQS1fzMNTWE6iRe8QJGNR4RgaLvI1N8KIe/2JFM5p8wXpsglDkQE7KWnWPj1yi
F8QABSKZ/AlwPAMSrSDGdFHBXE6pFh5Y1FYvtHSPWvC9jpmIFzggMSZuPWcUtNCHOgaljJ3QVhmP
KAUvTgEJN9LkHCAJBi9AAbBzFVkj6lBOMJ5hplHMY1ZilGSwhAQJmlBkG2pSRszIAalPKH4mn4JF
1MWOi4Q1A1S3cg/kCxzmeZyEUarkBDnK5JxKcWLJvYCELniBJFqYAyi+nLLJgvmw/nB4YxvWIGMz
jgGMYzyMw7xAWi1aShDeYBHY7BK8iQDrxNX2IKbqDM/8ANTsQA7koJoi0A52QANGwAQe453Yhmoi
igPapqAqAJ/0KZ9YQJ82YDKYgArSQALzgAlWYAiYgAm6oJrIIGdAbQ900A94sAd7UBBEh3CYYAr8
IMxggRe0TBloARYWBxh4Af1AYRBiCheeodiO69h2pBwC4QxMwQ0CoROqYBIUgQtMYQ7uIBdkJBvu
oArYMAaegA3vgODeoRG0gBTu4A5CgQsUoRPMwBIKgQuK4Yn4gxsY4QmkwAw6YRXA4A4s4Rv6IRsi
4QqkQAv0IBfU5x/koRPOAAzO/uAOjIFB5EEU3AAMwMANFEEPRrEN9MAX8kEcNEELJhEQfEEffAEN
rsANLKETnuAJ7mASCmEUO3EV4KMK3IfktKAR9Arncq5H5sEaaGGWeMEbRkQm6KUXfMgbUIEY5gEf
gGEU9MUddKHz6sEaRuEZoMeMqtGTwERUsrGOtsSMHiwhNAIfiIETVIteguEas7FjrKEVZskj/qEe
ToEV7kEfwOFoSOfqzgEXToEYBEwZ7qEXpCgeeqHowIEYRgHD1gEWaAEe1AEVtgQjtUEf4OEYXqYW
pPEfyAEUvmQeKgUVrNE9DrIUSgiW4qvoQCW3tGEUjqEetOFlooMVdGEbWMGB/krJ/2aJGHzIIJ9x
VGBJH/BEiijiHqwBFk7hwhZGIs2BIsYRFh4MIPfoGfwRFXgBHKAnHo6hGjOCHIoulXoBFbYywFjh
FGphyfQhHGqBJ7eBIbchZEYGmM4hOK6s2KKD+saoFy4sHMzrT1ghZi5BAimhnB5hD+TADxbBVhLB
ZrjJEAwBzfJADtiADMSgC7agNF1jCh5jBEbAaqqmAvhpoC7gAkaQoCSAL0zgLwSNBUjgoK7iKk5D
CUYACKhgCpRgBqkACqYgDdhgOZmTOdPgOZezmvJgD3yNDS4BJqGDGqgIFGYJFtAvGP5EcHjydLwh
HCZoR9KhHOShdtbzHWhn/h6SR0LuoXjKQRoagRmKJx2gh3bkIT7ZUz1pJ4WyBxug4RvsQR7G4R1g
iSLoIeKwoR30obMqIj3TcxwkRB/Q4Xhep3hox0IZ1EHfgUHwYRyggRvoQR6wARvSQR7QoXbSsx3w
oRxKVB5QlBvkQRCV0X90rkHwgfcU4onuoSgENEhtKGSgh/emJUgFlCvhAbsaZGGwK0gXtB6adEE1
gvdGxknJRCEookebtK64dEJ8dEGpUhlc4sCCYkSo9IGo1EoX5oEWRurigUyL4oG6VMWmkij0aGFU
rK7qQSGUdEunpUfntEdJLCgaxC+1lCKQNLn69E0alVG3EVIflUd9tMK2/lRL8SFMjTRPVawg8eEe
SGYeqHQdhOIoqEyYrAzLTkU6yCj/npEWhCsRHoG/2OkNTsqbQM0PBAHN/IAzHfAB8+AN0mA0sWAK
mEAJjGAIekBtIEM2r2Y1LwADZPMCJqAvTAADIKA2ZcAIlJU0ZoADZCBZP2MGOYACTEAJukAM2JUK
EAoLSnMLXAMLqIAK6LVe7XUL1pUM2MAy8oATjsEazCsTBmERUi0TBoWHbEkXlrAXtGwbyOHqcpRH
0CEfJvZiMTZjNXZje2RHOfZjQVZjB2ggM4EWljRkUTZlVXZlNUIf2gofYNYnZLb9jAL+AvNhWDU6
zG42cq8VOGER/EAO/gzhEeqMm04NzwzBzBKhm/KsV3kQAkGTDLrgWJOVCHpgBvQp0iJDMqYVA7yW
arzWBozAayCAAS5gBfiGa4DABkaABGzABgCjB7J1A25zC3A1DbKiB5BzCvgWCvzWb5tgBgVXcP+2
C/yAdIhhE3KQB6XwEebsEkoBmZiCjsLBJVj2cjE3cy/XYzW3c0GWgbSsIDx3dElXc10WH043VGV2
Zv0SKYLJHHCWMK2BNsZoZZopEx7BDyAhWloh9SChaJeWaX2VOkNtAuNGNKlWCbpmB/QJ0QaKWmVT
MqS3AmKzAjjABmRgAxwgARYAA+4GbXZgBUBQNQ/tz0xABnxANKCA/gr8JmuK828DV3CbIHA/g2tC
42yIgAnkAFukSTqn0w9Eh1bThBWCYeuIwRrIwXJLd4EZeIE5t4EhuH/0wSdwNIIt+IJ7hEHaqq1W
t4OBYspeV/6wLDpmtzaOoWVKYROw5e/46xLsjDP1zGn9gHgj0HjTQDRJczir1gcgJ6AgrW02oGqs
hlorgAIkgAI2gwEUQAEa4AJYAHtJIIiFWIgxoNPStji9NaHel2+Hk2+5mG/pd1n1BjCGYArIIA1q
CoC3aTMD2GC58zmsQSQkFoPpuI6V8YHtOI/1eI8tWINhVnXvIWZZt2ZPRoTpTzpqIxiOZhTaLBMo
ARJMzdTuDIab/hbNaFgCcfUNlvOG2VVedVh5R4M0mlXQZEAGmldajRgCVFkCJmA2v5ZqqDgxdqAH
tKY4pwALmoArkBNe15Vdf40MRJNdc9iLDWdyhpYSkuQTymkTaOURuikRKGEUCiyOFZiPrZmP8fia
tXmbuXljXfab/zicA9ljWtdmzUEw6292lUGRUaHNLuF3TQ3VIGGe6Xme64xpB8GSiRfU+Blqjfd4
fZldg7mTdZgIeviHQfCdVLNtf1iKr+Z8S0NZ13ddlZMCs4mfdTCjdxCAFyETuPOjOLIWcGGkZVVW
ccFhqzCB8bSbWRqCs7mlYTqmW3qDqWODNxhmJ5ic/RJVnyU4/ka4NnrBKht5nZAZnTbBnPjLnJh5
nYj2hYH1qaFazypZdJLWqQdhhofVMpBVbcfmn3wAf4dANIxgWW1AoIKYBHzAbrNpD3iVqkuNaOk5
TdKCJTwFmRZnLJJwjMaIZ6MDHMhBHdzhU2V6sDX3pQn7sBE7gl12QnD0myeEsU/3J0Bmp6nMHJKI
GtaZF2ghZuilsz37ZSxlnDiBmdOJ1VQNmVnNVtIpnZCaJcYJFEY7neiMZrD6n6FTk9mAAv+XqpO2
nlctLY76E/jLc05hlliBFmpBF1QmCR2JhElYG7ahPHvq2IyCxFA3sbEbZA07u7m7u1V2Uxa7phc7
vFMXkHU6/igImRy8QZ23jBiCAS56gRfkWxd0ARdKmmmeBhVO4RQypr/9uxSK+7M/qhVagSPvm2kI
3GUUnF46p5zQyVYel9WMehOE27U9B8AFvDENHP2YIhjEgrmfQad2KrpVwjyH7FlcorpJrCDD27td
fBlfPMZlPGQ1+EnnqoLB+WV/4mN8aR2C45Ctwez0eozGwr0LGL7j+wnpW8npu8nlW77lIi6AwcMZ
B68Zh3GOPMrlgsnpuxZKerMJvMBltRZEeqSbHP2kfMrxOq8JiTZEXGC3ocTJ4RyObR0C2ygUIih8
AqdnvM99ZLv9PNAF/cYr+LPAGZB5qShcF2fpr1V11pFo/sMwh3zSKX3SeZZnIT3TI52QOF3Sh3zN
QR3UK52MMv3NowO6SdzKyMEcUPzOm1QoOiaQcdqxH3vQAx3QbT3XdR3nvpmDJXun3+91YdfKroz+
UMfRnTvZld25taHZnf3Zm/25l33aSZgarP3ar53aSRh1vAEcvJ3YV/0c6Dwp7DxLYV1mZ32uWnbX
+xzX2f3d4b1lwftlVZeXhkLKSMZ1g0ncAxN25Y/YAT7gVX2YzvmcV93gh+lh/l3gGf7KvP3hS7zh
wf3g6RzFk8IdXL1J8zwoYj2Qe328Cb3Q4x273X3kTZ7dP768zdtj7B3YpQzjYf7iMZ7cYb7mMR7f
Z57cW3V+53neZKjsWYDe4nW+znv+5kVm4zm+4/f8ulMesk++3Z8+6qWePxq71ycEpwF55Wd2l7h+
lzp467s+7LmeVFme6897stE+7dFe7L0e3dGd3ple5Gt96mM8IAAAOw==
"""


r = 0

if sys.platform.startswith('win'):
    home_folder = os.environ.get('PYMOL_PATH')
else:
    home_folder = os.environ.get('HOME')

ism_working_dir = os.path.join(home_folder,'.ISMplugin')

if not os.path.isdir(ism_working_dir):
    os.mkdir(ism_working_dir)
    print "No working directory. Creating new directory %s" % ism_working_dir



class Running_ISM(Thread):
    def __init__ (self, work_dir, command, page):
	Thread.__init__(self)
	self.page = page
	self.command = command
	self.work_dir = work_dir
	self.pid = 0
    def run(self):

	print 'Working in %s' %(self.work_dir)

	where_am_i = os.getcwd()
	os.chdir(self.work_dir)
        self.page.insert('end',"Moving to directory %s\n" % self.work_dir)
        self.page.insert('end',"Batch: %s\n" % self.command)
        self.page.yview('moveto',1.0)
	p1 = subprocess.Popen(self.command, stdout=subprocess.PIPE,  shell=True)
	self.pid = p1.pid
	result = p1.communicate()[0]
	self.page.insert('end',"%s" % result)
        self.page.yview('moveto',1.0)            
        os.chdir(where_am_i)
        self.page.insert('end',"--------- ISM END -------------")
        self.page.yview('moveto',1.0)

    def stop(self):
        os.system('kill -9 %d' % self.pid)
        self.page.insert('end',"--------- ISM KILLED!-------------")
        self.page.yview('moveto',1.0)


class MainPlug:

    def __init__(self,app):
        parent = app.root
        self.parent = parent

        # paths and the rest of the stuff
        self.settings = {}
        self.ism_exe = StringVar()
	self.working_dir = StringVar()
	self.input_type = 'pdb'    # pdb/amber/molDynamic
	self.byresidue = 'no'      # Single residue energy
	self.molecular_box = 'yes' # yes/no
	self.single_residue = 'no' # yes/no
	self.working_inpwd = '1'   # 1->no, no->yes
	self.max = 0
	self.min = 9999
	self.max2 = 0
	self.min2 = 9999
	self.max3 = 0
	self.min3 = 9999
	self.nbyres = 0

        self.main_dialog = Pmw.Dialog(parent,title = 'ISM Plugin',command = self.close_main_dialog)
        self.main_dialog.withdraw()

        self.main_dialog.geometry('1000x690')

	self.main_notebook = Pmw.NoteBook(self.main_dialog.interior())
        self.main_notebook.pack(fill = 'both', expand = 1, padx = 10, pady = 10)

        self.config_ism_page = self.main_notebook.add('Configure')
        self.run_ism_page = self.main_notebook.add('Run')
        self.analyze_ism_page = self.main_notebook.add('Global Analysis')
        self.analyze2_ism_page = self.main_notebook.add('Residue Analysis')


	# Configure tab stuff
        self.main_notebook.tab('Configure').focus_set()

        self.config_main_group = Pmw.Group(self.config_ism_page, tag_text = 'Global')
        self.config_main_group.pack(fill='x', expand = 0, padx = 2, pady = 1)

	self.config_main_group1 = Pmw.Group(self.config_main_group.interior(), tag_text = 'ISM')
	self.config_main_group1.pack(fill='x',expand = 1, padx = 0, pady = 0)

	self.select_exe_entry = Pmw.EntryField(self.config_main_group1.interior(), labelpos = 'w',label_text = 'ISM executable:')
	self.select_exe_entry.pack(side=LEFT, fill='x',expand = 1, padx = 0, pady = 0)
        self.select_exe_button_box = Pmw.ButtonBox(self.config_main_group1.interior(),orient='horizontal', padx=0,pady=0)
        self.select_exe_button_box.add('...',command = self.set_ism_exe_file)
        self.select_exe_button_box.pack(side=LEFT,expand = 0, padx = 0, pady = 5)

        self.config_main_group2 = Pmw.Group(self.config_main_group.interior(), tag_text='Working')
        self.config_main_group2.pack(fill='x',expand = 1, padx = 0, pady = 0)

        self.select_workdir_entry = Pmw.EntryField(self.config_main_group2.interior(), labelpos = 'w',label_text = 'Work directory:')
        self.select_workdir_entry.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.select_workdir_button_box = Pmw.ButtonBox(self.config_main_group2.interior(),orient='horizontal', padx=0,pady=0)
        self.select_workdir_button_box.add('...',command = self.set_workdir)
        self.select_workdir_button_box.pack(side=LEFT,expand = 0, padx = 0, pady = 5)
	
        self.logo_group = Pmw.Group(self.config_ism_page, tag_text = '')
        self.logo_group.pack(fill = 'both', expand = 1, padx = 10, pady = 10)
        photo = PhotoImage(data=about_image)
        self.about_image_label = Tkinter.Label(self.logo_group.interior(), image=photo)
        self.about_image_label.image = photo
        self.about_image_label.pack(fill='both', expand=1)


        self.about_text_field = Pmw.ScrolledText(self.logo_group.interior(),
                                                        borderframe=5,
                                                        vscrollmode='dynamic',
                                                        hscrollmode='dynamic',
                                                        labelpos='n',
                                                        text_width=150, text_height=15,
                                                        text_wrap='none',
                                                        text_background='#000000',
                                                        text_foreground='yellow')
        self.about_text_field.insert('end',"%s" % about_text)
	self.about_text_field.pack(fill='both', expand=1)


        self.save_options_button_box = Pmw.ButtonBox(self.config_main_group.interior(),orient='horizontal', padx=0,pady=0)
        self.save_options_button_box.add('Save',command = self.write_config)
        self.save_options_button_box.pack(expand = 0, padx = 0, pady = 5)

	# Run tab stuff


	self.run_left = Pmw.Group(self.run_ism_page)
        self.run_left.pack(side=LEFT,fill='both',expand = 1, padx = 0, pady = 0)
        self.run_rig = Pmw.Group(self.run_ism_page)
        self.run_rig.pack(side=RIGHT,fill='both',expand = 1, padx = 0, pady = 0)

        self.run_input_group = Pmw.Group(self.run_left.interior(), tag_text = 'Input type')
        self.run_input_group.pack(fill='x', expand = 1, padx = 2, pady = 1)


        self.run_input_group2 = Pmw.Group(self.run_left.interior(), tag_text='PDB/TOP input file')
        self.run_input_group2.pack(fill='x',expand = 1, padx = 0, pady = 0)

        self.run_input_groupx= Pmw.Group(self.run_left.interior(), tag_text='CRD/MDCRD input file')
        self.run_input_groupx.pack(fill='x',expand = 1, padx = 0, pady = 0)

        self.run_input_group3 = Pmw.Group(self.run_left.interior(), tag_text='Protein')
        self.run_input_group3.pack(fill='x',expand = 1, padx = 0, pady = 0)
        self.run_input_group4 = Pmw.Group(self.run_left.interior(), tag_text='Ligand')
        self.run_input_group4.pack(fill='x',expand = 1, padx = 0, pady = 0)


        self.run_input_group5 = Pmw.Group(self.run_left.interior(), tag_text = 'Residue Analysis')
        self.run_input_group5.pack(fill='x', expand = 1, padx = 2, pady = 1)

        self.select_inputfile_entry = Pmw.EntryField(self.run_input_group2.interior(), labelpos = 'w',label_text = 'Input file:')
        self.select_inputfile_entry.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.select_inputfile_button_box = Pmw.ButtonBox(self.run_input_group2.interior(),orient='horizontal', padx=0,pady=0)
        self.select_inputfile_button_box.add('...',command = self.set_inputfile)
        self.select_inputfile_button_box.pack(side=LEFT,expand = 0, padx = 0, pady = 5)


        self.select_inputfilex_entry = Pmw.EntryField(self.run_input_groupx.interior(), labelpos = 'w',label_text = 'Input file:')
        self.select_inputfilex_entry.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.select_inputfilex_button_box = Pmw.ButtonBox(self.run_input_groupx.interior(),orient='horizontal', padx=0,pady=0)
        self.select_inputfilex_button_box.add('...',command = self.set_inputfilex)
        self.select_inputfilex_button_box.pack(side=LEFT,expand = 0, padx = 0, pady = 5)




        my_input_options = ('pdb','amber','molDynamic')

        self.input_type_dropdown = Pmw.ComboBox(self.run_input_group.interior(),
                label_text = 'Input file type',
                labelpos = 'w',
                selectioncommand = self.changeInputType,
                scrolledlist_items = my_input_options)

        self.input_type_dropdown.pack( anchor = 'n',
                fill = 'x', expand = 1, padx = 8, pady = 8)

        self.input_type_dropdown.selectitem(my_input_options[0])


        my_residue_options = ('yes','no')

        self.residue_type_dropdown = Pmw.ComboBox(self.run_input_group5.interior(),
                label_text = 'Single Residue Energy',
                labelpos = 'w',
                selectioncommand = self.changeResidueType,
                scrolledlist_items = my_residue_options)

        self.residue_type_dropdown.pack( anchor = 'n',
                fill = 'x', expand = 1, padx = 8, pady = 8)

        self.residue_type_dropdown.selectitem(my_residue_options[1])

        self.select_prot_residues_entry = Pmw.EntryField(self.run_input_group3.interior(), labelpos = 'w',label_text = 'Protein residues:')
        self.select_prot_residues_entry.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.select_prot_residues_button_box = Pmw.ButtonBox(self.run_input_group3.interior(),orient='horizontal', padx=0,pady=0)
        self.select_prot_residues_button_box.add('Use current sele',command = self.set_sele_protein)
        self.select_prot_residues_button_box.pack(side=LEFT,expand = 0, padx = 0, pady = 5)


        self.select_lig_residues_entry = Pmw.EntryField(self.run_input_group4.interior(), labelpos = 'w',label_text = 'Ligand residues:')
        self.select_lig_residues_entry.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.select_lig_residues_button_box = Pmw.ButtonBox(self.run_input_group4.interior(),orient='horizontal', padx=0,pady=0)
        self.select_lig_residues_button_box.add('Use current sele',command = self.set_sele_lig)
        self.select_lig_residues_button_box.pack(side=LEFT,expand = 0, padx = 0, pady = 5)



        self.run_input_group15 = Pmw.Group(self.run_rig.interior(), tag_text='Output')
        self.run_input_group15.pack(fill='x',expand = 1, padx = 0, pady = 0)


        self.select_outputroot_entry = Pmw.EntryField(self.run_input_group15.interior(), labelpos = 'w',label_text = 'Root for output files', value='')
        self.select_outputroot_entry.pack(fill='both',expand = 1, padx = 0, pady = 0)


        self.run_input_group5 = Pmw.Group(self.run_rig.interior(), tag_text='MD traj')
        self.run_input_group5.pack(fill='x',expand = 1, padx = 0, pady = 0)


        self.select_init_snap_entry = Pmw.EntryField(self.run_input_group5.interior(), labelpos = 'w',label_text = 'Initial snapshot:', value='0')
        self.select_init_snap_entry.pack(fill='both',expand = 1, padx = 0, pady = 0)

        self.select_final_snap_entry = Pmw.EntryField(self.run_input_group5.interior(), labelpos = 'w',label_text = 'Final snapshot:', value='0')
        self.select_final_snap_entry.pack(fill='both',expand = 1, padx = 0, pady = 0)

        self.select_step_snap_entry = Pmw.EntryField(self.run_input_group5.interior(), labelpos = 'w',label_text = 'Snapshot step:', value='0')
        self.select_step_snap_entry.pack(fill='both',expand = 1, padx = 0, pady = 0)


        my_interbox = ('yes','no')

        self.select_interbox_dropdown = Pmw.ComboBox(self.run_input_group5.interior(),
                label_text = 'BOX?',
                labelpos = 'w',
                selectioncommand = self.changeBoxType,
                scrolledlist_items = my_interbox)

        self.select_interbox_dropdown.pack( anchor = 'n',
                fill='both', expand = 1, padx = 8, pady = 8)

        self.select_interbox_dropdown.selectitem(my_interbox[0])

        Pmw.alignlabels(  [self.select_init_snap_entry, self.select_final_snap_entry, self.select_step_snap_entry, self.select_interbox_dropdown]) #, self.select_single_residues_entry] )


        self.run_output_group = Pmw.Group(self.run_rig.interior(), tag_text = 'Output')
        self.run_output_group.pack(fill='x', expand = 1, padx = 2, pady = 1)

        self.output_button_box = Pmw.ButtonBox(self.run_output_group.interior(),orient='vertical', padx=0,pady=0)
        self.output_button_box.add('Run!',command = self.run_ism)
        self.output_button_box.add('Stop',command = self.stop_ism)
        self.output_button_box.pack(side=RIGHT,expand = 1, padx = 10, pady = 5)
        self.output_page_log_text = Pmw.ScrolledText(self.run_output_group.interior(),
                                                        borderframe=5,
                                                        vscrollmode='dynamic',
                                                        hscrollmode='dynamic',
                                                        labelpos='n',
                                                        text_width=150, text_height=15,
                                                        text_wrap='none',
                                                        text_background='#000000',
                                                        text_foreground='yellow')

        self.output_page_log_text.pack(side=BOTTOM, anchor='n',pady=0)


	Pmw.alignlabels(  [self.select_inputfile_entry, self.input_type_dropdown, self.select_inputfilex_entry] )

	# Analysis stuff


        self.analysis_group2 = Pmw.Group(self.analyze_ism_page, tag_text='Load Results')
        self.analysis_group2.pack(fill='x',expand = 1, padx = 0, pady = 0)

        self.analysis_group2b = Pmw.Group(self.analyze2_ism_page, tag_text='Load Results')
        self.analysis_group2b.pack(fill='x',expand = 1, padx = 0, pady = 0)


        self.select_outputfile_entry = Pmw.EntryField(self.analysis_group2.interior(), labelpos = 'w',label_text = 'Output Root:')
        self.select_outputfile_entry.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.select_outputfile_button_box = Pmw.ButtonBox(self.analysis_group2.interior(),orient='horizontal', padx=0,pady=0)
        self.select_outputfile_button_box.add('or pick a file',command = self.set_outputfile)
        self.select_outputfile_button_box.pack(side=LEFT,expand = 0, padx = 0, pady = 5)

        self.select_outputfile_entry2 = Pmw.EntryField(self.analysis_group2b.interior(), labelpos = 'w',label_text = 'Output Root:')
        self.select_outputfile_entry2.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.select_outputfile_button_box2 = Pmw.ButtonBox(self.analysis_group2b.interior(),orient='horizontal', padx=0,pady=0)
        self.select_outputfile_button_box2.add('or pick a file',command = self.set_outputfile2)
        self.select_outputfile_button_box2.pack(side=LEFT,expand = 0, padx = 0, pady = 5)


        self.analysis_group4 = Pmw.Group(self.analyze_ism_page, tag_text='Data sets')
        self.analysis_group4.pack(fill='x',expand = 1, padx = 0, pady = 0)

        self.analysis_group_contact = Pmw.Group(self.analyze_ism_page, tag_text='Contacts visualization')
        self.analysis_group_contact.pack(fill='x',expand = 1, padx = 0, pady = 0)


#        self.analysis_group4b = Pmw.Group(self.analyze2_ism_page, tag_text='Data sets')
#        self.analysis_group4b.pack(fill='x',expand = 1, padx = 0, pady = 0)


        self.analysis_group3 = Pmw.Group(self.analyze_ism_page, tag_text='Plotting Global Energies')
        self.analysis_group3.pack(fill='x',expand = 1, padx = 0, pady = 0)
	
        self.plot_types_checkbutton = Pmw.RadioSelect(self.analysis_group3.interior(),
                buttontype = 'checkbutton',orient = 'vertical',
                labelpos = 'w',
                label_text = 'Select elements to plot',
                hull_borderwidth = 2,hull_relief = 'ridge')
        self.plot_types_checkbutton.pack(side = 'top', expand = 1, padx = 10, pady = 10)

        # Add some buttons to the checkbutton RadioSelect.
        self.plot_types_checkbutton.add('Coulombic energy')
        self.plot_types_checkbutton.add('Van der Waals energy')
        self.plot_types_checkbutton.add('Receptor desolvation energy')
        self.plot_types_checkbutton.add('Ligand desolvation energy')
        self.plot_types_checkbutton.add('Apolar energy')
        self.plot_types_checkbutton.add('Hydrogen bond energy')
        self.plot_types_checkbutton.add('Total energy')


        self.plot_image = Pmw.RadioSelect(self.analysis_group3.interior(),
                buttontype = 'checkbutton',orient = 'vertical',
                labelpos = 'w',
                label_text = '',
                hull_borderwidth = 0,hull_relief = 'ridge')
        self.plot_image.pack( expand = 1, padx = 3, pady = 3)
        self.plot_image.add('Write also the plot as a PNG image')




        self.plot_outputfile_button_box = Pmw.ButtonBox(self.analysis_group3.interior(),orient='horizontal', padx=0,pady=0)
        self.plot_outputfile_button_box.add('Plot',command = self.plot_things)
        self.plot_outputfile_button_box.pack(expand = 0, padx = 0, pady = 5)


        self.analysis_group5 = Pmw.Group(self.analyze2_ism_page, tag_text='Plotting Single Residue Energies')
        self.analysis_group5.pack(fill='x',expand = 1, padx = 0, pady = 0)
        self.analysis_group6 = Pmw.Group(self.analysis_group5.interior(), tag_text='Residue')
        self.analysis_group6.pack(fill='x',expand = 1, padx = 0, pady = 0)


        self.analysis_sr_residues_entry = Pmw.EntryField(self.analysis_group6.interior(), labelpos = 'w',label_text = 'Plot for residue:')
        self.analysis_sr_residues_entry.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.analysis_sr_residues_button_box = Pmw.ButtonBox(self.analysis_group6.interior(),orient='horizontal', padx=0,pady=0)
        self.analysis_sr_residues_button_box.add('Pick from current sele',command = self.set_sele_lig2)
        self.analysis_sr_residues_button_box.pack(side=LEFT,expand = 0, padx = 0, pady = 5)


        self.analysis_sr_residues_entry2 = Pmw.EntryField(self.analysis_group6.interior(), labelpos = 'w',label_text = 'and residue (optional):')
        self.analysis_sr_residues_entry2.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.analysis_sr_residues_button_box2 = Pmw.ButtonBox(self.analysis_group6.interior(),orient='horizontal', padx=0,pady=0)
        self.analysis_sr_residues_button_box2.add('Pick from current sele',command = self.set_sele_lig3)
        self.analysis_sr_residues_button_box2.pack(side=LEFT,expand = 0, padx = 0, pady = 5)



        self.plot_sr_types_checkbutton = Pmw.RadioSelect(self.analysis_group5.interior(),
                buttontype = 'checkbutton',orient = 'vertical',
                labelpos = 'w',
                label_text = 'Select elements to plot',
                hull_borderwidth = 2,hull_relief = 'ridge')

        self.loadb_outputfile_button_box2 = Pmw.ButtonBox(self.analysis_group5.interior(),orient='horizontal', padx=0,pady=0)

        self.loadb_outputfile_button_box2.add('Single Residue Energy',command = self.show_table_sr)
        self.loadb_outputfile_button_box2.add('Single Residue Statistics',command = self.show_table_sr_vs)
        self.loadb_outputfile_button_box2.add('Residues vs Residues interactions',command = self.show_table_sr_vs_real)
        self.loadb_outputfile_button_box2.add('Residues Self terms',command = self.show_table_sr_selfterms_dynamic)


        self.loadb_outputfile_button_box2.pack(expand = 0, padx = 0, pady = 5)


        self.plot_sr_types_checkbutton.pack( expand = 1, padx = 10, pady = 10)

        self.plot_sr_types_checkbutton.add('Desolvation (Single term)')
        self.plot_sr_types_checkbutton.add('Apolar (Single term)')
        self.plot_sr_types_checkbutton.add('Coulombic (Cross term)')
        self.plot_sr_types_checkbutton.add('Van der Waals (Cross term)')
        self.plot_sr_types_checkbutton.add('Desolvation (Cross term)')
        self.plot_sr_types_checkbutton.add('Hydrogen bond (Cross term)')
        self.plot_sr_types_checkbutton.add('Total (Cross term)')


        self.plot_sr_image = Pmw.RadioSelect(self.analysis_group5.interior(),
                buttontype = 'checkbutton',orient = 'vertical',
                labelpos = 'w',
                label_text = '',
                hull_borderwidth = 0,hull_relief = 'ridge')
        self.plot_sr_image.pack( expand = 1, padx = 3, pady = 3)
        self.plot_sr_image.add('Write also the plot as a PNG image')



        self.plot_outputfile2_button_box = Pmw.ButtonBox(self.analysis_group5.interior(),orient='horizontal', padx=0,pady=0)
        self.plot_outputfile2_button_box.add('Plot',command = self.plot_things_sr)
        self.plot_outputfile2_button_box.pack(expand = 0, padx = 0, pady = 5)



        self.loadb_outputfile_button_box = Pmw.ButtonBox(self.analysis_group4.interior(),orient='horizontal', padx=0,pady=0)
        self.loadb_outputfile_button_box.add('Global Energy',command = self.plot_things2)
        self.loadb_outputfile_button_box.add('Global Statistics',command = self.show_global_st_grid)
        self.loadb_outputfile_button_box.add('Export PDB with energy',command = self.pre_save_rep)


        self.loadb_outputfile_button_box.pack(expand = 0, padx = 0, pady = 5)

        self.box_for_contacts = Pmw.ButtonBox(self.analysis_group_contact.interior(),orient='horizontal', padx=0,pady=0)
	self.box_for_contacts.add('Show Contacts',command = self.do_contacts)
        self.box_for_contacts.add('Hide protein',command = self.do_hide_protein)
        self.box_for_contacts.add('Hydrophobic',command = self.do_show_hydrophobic)
        self.box_for_contacts.add('Hydrophylic',command = self.do_show_hydrophylic)
        self.box_for_contacts.add('Mixed contacts',command = self.do_show_mixed)
        self.box_for_contacts.add('Hydrogen bonds',command = self.do_show_hbonds)

	self.box_for_contacts.pack(expand = 0, padx = 0, pady = 5)


        self.main_notebook.setnaturalsize()

        self.settings = self.read_config() # Read config stuff
        if len(self.settings['working_dir']) != 0:
           self.settings['working_dir'] = os.getcwd()

	self.main_dialog.show()


    def show_global_st_grid(self):

	my_filename = os.path.join(self.settings['working_dir'], self.select_outputfile_entry.get())
        my_filename += "_GlobalStatist.out"

        self.dataset_st_dialog = Pmw.Dialog(self.parent,title = 'Data Set',command = self.close_ds_st_dialog)
        self.dataset_st_dialog.withdraw()

        self.dataset_st_dialog.geometry('550x280')
        self.dataset_st_dialog.bind('<Return>',self.close_ds_st_dialog)

        self.sf = Pmw.ScrolledFrame(self.dataset_st_dialog.interior(),
                labelpos = 'n', label_text = 'Global Statistics Data Set',
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

        if self.sf.cget('horizflex') == 'expand' or \
                self.sf.cget('vertflex') == 'expand':
            self.sf.reposition()

        self.addLabel('Type',2)

        self.addLabel('Mean',2)
        self.addLabel('Std',2)

        count = 0;
        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                    if line[0]!='!' and line[0]!='#':
                        entr = line.split()

                        if entr[1] == '********':
                           entr[1] = '9999'
                        if entr[2] == '********':
                           entr[2] = '9999'

                        if entr[0] != 'DESOL':
	                        self.addButton(entr[0],2);
	                        self.addButton(entr[1],2);
	                        self.addButton(entr[2],2);
			else:
                                self.addButton("%s %s" %(entr[0],entr[1]),2);
                                self.addButton(entr[2],2);
                                self.addButton(entr[3],2);

                        #self.addButton(entr[3]);
                        #self.addButton(entr[4]);
                        #self.addButton(entr[5]);
                        #self.addButton(entr[6]);
                        #self.addButton(entr[7]);

                        count = count + 1

              finally:
                  filecillo.close()
            except IOError:
               pass


        self.dataset_st_dialog.show()




    def plot_things2(self):

	my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry.get())
	my_filename += "_GlobalEnergies.out"

        self.dataset_dialog = Pmw.Dialog(self.parent,title = 'Data Set',command = self.close_ds_dialog)
        self.dataset_dialog.withdraw()

        self.dataset_dialog.geometry('650x780')
        self.dataset_dialog.bind('<Return>',self.close_ds_dialog)

        self.sf = Pmw.ScrolledFrame(self.dataset_dialog.interior(),
                labelpos = 'n', label_text = 'Global Energy Data Set',
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

	"""
        button = Tkinter.Button(self.frame,text = '%s' % (my_filename))
        button.grid(row = self.row, column = self.col, sticky = 'nsew')

        self.frame.grid_rowconfigure(self.row, weight = 1)
        self.frame.grid_columnconfigure(self.col, weight = 1)
	self.row = self.row + 1
	self.col = 0
	"""
        if self.sf.cget('horizflex') == 'expand' or \
                self.sf.cget('vertflex') == 'expand':
            self.sf.reposition()

        self.addLabel('Snap',7)

        self.addLabel('Coulombic',7)
        self.addLabel('Van der Waals',7)
        self.addLabel('Desolvation Receptor',7)
        self.addLabel('Desolvation Ligand',7)
        self.addLabel('Apolar term',7)
        self.addLabel('Hydrogen Bond energy',7)
        self.addLabel('Total energy',7)

	count = 0;
        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                    if line[0]!='!' and line[0]!='#':
                        entr = line.split()
                        #step.append( int(entr[0]))
                        if entr[1] == '********':
                           entr[1] = '9999'
                        if entr[2] == '********':
                           entr[2] = '9999'
                        if entr[3] == '********':
                           entr[3] = '9999'
                        if entr[4] == '********':
                           entr[4] = '9999'
                        if entr[5] == '********':
                           entr[5] = '9999'
                        if entr[6] == '********':
                           entr[6] = '9999'
                        if entr[7] == '********':
                           entr[7] = '9999'

# Bugfix. ISM now prints Coulombic for vacuum, so we have to move along one column
#                        self.addButton(entr[0],7);
#                        self.addButton(entr[1],7);
#                        self.addButton(entr[2],7);
#                        self.addButton(entr[3],7);
#                        self.addButton(entr[4],7);
#                        self.addButton(entr[5],7);
#                        self.addButton(entr[6],7);
#                        self.addButton(entr[7],7);

			self.addButton(entr[0],7);
			self.addButton(entr[1],7);
			self.addButton(entr[3],7);
			self.addButton(entr[4],7);
                        self.addButton(entr[5],7);
                        self.addButton(entr[6],7);
                        self.addButton(entr[7],7);
                        self.addButton(entr[8],7);

			count = count + 1

              finally:
                  filecillo.close()
            except IOError:
               pass


	self.dataset_dialog.show()

    def sethscrollmode(self, tag):
        self.sf.configure(hscrollmode = tag)

    def setvscrollmode(self, tag):
        self.sf.configure(vscrollmode = tag)

    def sethflex(self, tag):
        self.sf.configure(horizflex = tag)

    def setvflex(self, tag):
        self.sf.configure(vertflex = tag)

    def addLabel(self, cont, max):

        button = Tkinter.Button(self.frame,
            text = '%s' % (cont))


        button.grid(row = self.row, column = self.col, sticky = 'nsew')

        self.frame.grid_rowconfigure(self.row, weight = 1)
        self.frame.grid_columnconfigure(self.col, weight = 1)

        if self.sf.cget('horizflex') == 'expand' or \
                self.sf.cget('vertflex') == 'expand':
            self.sf.reposition()

        if self.col == max:
            self.col = 0
            self.row = self.row + 1
        else:
            self.col = self.col + 1


    def addButton_red(self, cont, max):

        button = Pmw.EntryField(self.frame,
                labelpos = 'w',
                value = '%s' %(cont),
                validate = {'validator' : 'real',
                        'min' : -0.099, 'max' : 99.0, 'minstrict' : -0.1})

        button.grid(row = self.row, column = self.col, sticky = 'nsew')

        self.frame.grid_rowconfigure(self.row, weight = 1)
        self.frame.grid_columnconfigure(self.col, weight = 1)

        if self.sf.cget('horizflex') == 'expand' or \
                self.sf.cget('vertflex') == 'expand':
            self.sf.reposition()

        if self.col == max:
            self.col = 0
            self.row = self.row + 1
        else:
            self.col = self.col + 1



    def addButton(self, cont, max):

        button = Pmw.EntryField(self.frame,
                labelpos = 'w',
                value = '%s' %(cont),
                validate = None)

        button.grid(row = self.row, column = self.col, sticky = 'nsew')

        self.frame.grid_rowconfigure(self.row, weight = 1)
        self.frame.grid_columnconfigure(self.col, weight = 1)

        if self.sf.cget('horizflex') == 'expand' or \
                self.sf.cget('vertflex') == 'expand':
            self.sf.reposition()

	"""
        if 'center' in self.radio.getcurselection():
            self.sf.update_idletasks()
            self.centerPage()
	"""
        if self.col == max:
            self.col = 0
            self.row = self.row + 1
        else:
            self.col = self.col + 1

    """
    def showYView(self):
        print self.sf.yview()

    def pageDown(self):
        self.sf.yview('scroll', 1, 'page')

    def radioSelected(self, name, state):
        if state:
            self.centerPage()

    def centerPage(self):
        # Example of how to use the yview() method of Pmw.ScrolledFrame.
        top, bottom = self.sf.yview()
        size = bottom - top
        middle = 0.5 - size / 2
        self.sf.yview('moveto', middle)

    """


    def plot_things_sr(self):

        if len(self.select_outputfile_entry2.get()) == 0:
         self.screwup("Error","You must provide an output root name")
         return

        myres = self.analysis_sr_residues_entry.get()

	if len(myres) == 0:
         self.screwup("Error","You must provide at least a residue number ")
         return


	my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueEnergies.out"

        try:
          testi = int(myres)
        except:
         self.screwup("Error","You must provide at least a residue number ")
         return


        step = []
        Coulombic = []
        vdw = []
        desolvSingle = []
        desolvCross = []
        apolarSingle = []
	apolarCross = []
	hbond = []
        TotalCross = []
	myres2 = self.analysis_sr_residues_entry2.get()
        try:
         if len(myres2) != 0:
          testj = int(myres2)
        except:
         self.screwup("Error","Second residue is not a number")
         return

	
        current_step = -1
        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
			if line[1:12] == '// SnapShot':
				step.append( int(line[14:19]))
				Coulombic.append(0.0)
                                desolvCross.append(0.0)
                                apolarCross.append(0.0)
                                vdw.append(0.0)
				hbond.append(0.0)
                                TotalCross.append(0.0)
				current_step = current_step + 1

                        if line.strip()[0:12] == 'Self Terms  ':
	                        entr = line.split()
	                        if entr[1] == '********':
	                           entr[1] = '9999'
	                        if entr[2] == '********':
	                           entr[2] = '9999'

				if int(entr[2]) == int(myres):
				     desolvSingle.append( float(entr[4]))
				     apolarSingle.append( float(entr[5]))

	                if line[1:13] == 'Cross Terms ':

				if current_step == -1: # amber, not moldynamics
                                    current_step = 0
                                    step.append(1);
                                    Coulombic.append(0.0)
                                    desolvCross.append(0.0)
				    apolarCross.append(0.0)
                                    vdw.append(0.0)
				    hbond.append(0.0)
                                    TotalCross.append(0.0)

	                        entr = line.split()

	                        if entr[1] == '********':
	                           entr[1] = '9999'
	                        if entr[2] == '********':
	                           entr[2] = '9999'

				try:
				    current_res = int(entr[4])
				    other_res = int(entr[2])
				except:
                                    current_res = -1
				    other_res = -1

				if  len(myres2) == 0:
				 if current_res == int(myres) or other_res == int(myres):
				    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
				    vdw[current_step] = vdw[current_step] + float( entr[6])
				    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
			            hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10]) 
				else:
				 if  ( current_res == int(myres) and other_res == int(myres2)) or (current_res == int(myres2) and other_res == int(myres)):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])

              finally:
                  filecillo.close()
            except IOError:
               pass
        print "Read done"
        img_add = myres
	if len(myres2) != 0:
          img_add = "%s_vs_%s" %(myres,myres2)
          myres = "%s vs %s" %(myres,myres2)
        oroot = self.select_outputfile_entry2.get()
        img_check = 0
        img_check_sel = self.plot_sr_image.getcurselection()
        for th1 in img_check_sel:
           if th1 == 'Write also the plot as a PNG image':
            img_check = 1
 
	if len(desolvSingle) != 0:
          plot_selection2 = self.plot_sr_types_checkbutton.getcurselection()
          for thing in plot_selection2:
                    if thing == 'Desolvation (Single term)':
                       ds = Gnuplot.Gnuplot(persist=1)
                       ds('set style data linespoints')
                       ds('set yrange [%f:%f]' %(min(desolvSingle)-10.0,max(desolvSingle)+10.0))
                       ds_data = Gnuplot.Data(step, desolvSingle, title='Desolvation Energy (Single term) for residue %s' %(myres))
                       ds.xlabel("Time step")
                       ds.ylabel("Energy (kcal/mol)")
                       ds.plot(ds_data)
                       if( img_check == 1):
    		        ds.hardcopy("%s_desolvation_residue_%s.png" %(oroot,img_add), terminal='png')
                    elif thing == 'Apolar (Single term)':
                       apos = Gnuplot.Gnuplot(persist=1)
                       apos('set style data linespoints')
                       apos('set yrange [%f:%f]' %(min(apolarSingle)-10.0,max(apolarSingle)+10.0))
                       apos_data = Gnuplot.Data(step, apolarSingle, title='Apolar Energy (Single term) for residue %s' %(myres))
                       apos.xlabel("Time step")
                       apos.ylabel("Energy (kcal/mol)")
                       apos.plot(apos_data)
                       if( img_check == 1):
                        apos.hardcopy("%s_apolar_residue_%s.png" %(oroot,img_add), terminal='png')

                    elif thing == 'Coulombic (Cross term)':
                        qq = Gnuplot.Gnuplot(persist=1)
                        qq('set style data linespoints')
                        qq('set yrange [%f:%f]' %(min(Coulombic)-10.0,max(Coulombic)+10.0))
                        qq_data = Gnuplot.Data(step, Coulombic, title='Coulombic energy for residue %s' %(myres))
                        qq.xlabel("Time step")
                        qq.ylabel("Energy (kcal/mol)")
                        qq.plot(qq_data)
                        if( img_check == 1):
                         qq.hardcopy("%s_coulombic_residue_%s.png" %(oroot,img_add), terminal='png')

                    elif thing == 'Van der Waals (Cross term)':
                        vdwg = Gnuplot.Gnuplot(persist=1)
                        vdwg('set style data linespoints')
                        vdwg('set yrange [%f:%f]' %(min(vdw)-10.0,max(vdw)+10.0))
                        vdwg_data = Gnuplot.Data(step, vdw, title='Van der Waals energy for residue %s' %(myres))
                        vdwg.xlabel("Time step")
                        vdwg.ylabel("Energy (kcal/mol)")
                        vdwg.plot(vdwg_data)
                        if( img_check == 1):
                         vdwg.hardcopy("%s_vdw_residue_%s.png" %(oroot,img_add), terminal='png')

                    elif thing == 'Desolvation (Cross term)':
                       dsc = Gnuplot.Gnuplot(persist=1)
                       dsc('set style data linespoints')
                       dsc('set yrange [%f:%f]' %(min(desolvCross)-10.0,max(desolvCross)+10.0))
                       dsc_data = Gnuplot.Data(step, desolvCross, title='Desolvation Energy (Cross term) for residue %s' %(myres))
                       dsc.xlabel("Time step")
                       dsc.ylabel("Energy (kcal/mol)")
                       dsc.plot(dsc_data)
                       if( img_check == 1):
                        dsc.hardcopy("%s_desolvation_cross_residue_%s.png" %(oroot,img_add), terminal='png')

                    elif thing == 'Apolar (Cross term)':
                        apoc = Gnuplot.Gnuplot(persist=1)
                        apoc('set style data linespoints')
                        apoc('set yrange [%f:%f]' %(min(apolarCross)-10.0,max(apolarCross)+10.0))
                        apoc_data = Gnuplot.Data(step, apolarCross, title='Apolar Energy (Cross term) for residue %s' %(myres))
                        apoc.xlabel("Time step")
                        apoc.ylabel("Energy (kcal/mol)")
                        apoc.plot(apoc_data)
                        if( img_check == 1):
                         apoc.hardcopy("%s_apolar_cross_residue_%s.png" %(oroot,img_add), terminal='png')

                    elif thing == 'Total (Cross term)':
                        tot = Gnuplot.Gnuplot(persist=1)
                        tot('set style data linespoints')
                        tot('set yrange [%f:%f]' %(min(TotalCross)-10.0,max(TotalCross)+10.0))
                        tot_data = Gnuplot.Data(step, TotalCross, title='Total Energy for residue %s' %(myres))
                        tot.xlabel("Time step")
                        tot.ylabel("Energy (kcal/mol)")
                        tot.plot(tot_data)
                        if( img_check == 1):
                         tot.hardcopy("%s_total_residue_%s.png" %(oroot,img_add), terminal='png')

                    elif thing == 'Hydrogen bond (Cross term)':
                        hb = Gnuplot.Gnuplot(persist=1)
                        hb('set style data linespoints')
                        hb('set yrange [%f:%f]' %(min(hbond)-10.0,max(hbond)+10.0))
                        hb_data = Gnuplot.Data(step, hbond, title='Hydrogen Bond Energy for residue %s' %(myres))
                        hb.xlabel("Time step")
                        hb.ylabel("Energy (kcal/mol)")
                        hb.plot(hb_data)
                        if( img_check == 1):
                         hb.hardcopy("%s_hydrogenbond_residue_%s.png" %(oroot,img_add), terminal='png')


    def show_table_sr_selfterms_dynamic(self):
        if len(self.select_outputfile_entry2.get()) == 0:
         self.screwup("Error","You must provide an output root name")
         return

        my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueStatistics.out"

        if not os.path.isfile(my_filename):
         my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
         my_filename += "_ResidueEnergies.out"
         if not os.path.isfile(my_filename):
          self.screwup("Error","No ISM output found with this root name")
         else:
          self.show_table_sr_selfterms_singlestruct()
          return



        total_prot = {}

        j = 0
        total_val = []


        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                        if line[1:13] == ' Self Terms ':
                                entr = line.split()
                                if total_prot.get(int(entr[2].strip()),-1) == -1:
                                   total_prot[int(entr[2].strip())] = j
                                   j = j + 1

                prot_list = [x for x in total_prot.iteritems()]
                prot_list.sort(key=lambda x: x[0])

                for k in range(0,4):
                     row_tmp = []
                     for l in range(0,len(prot_list)):
                        row_tmp.append(0.0)
                     total_val.append(row_tmp)

                for line in list:

                        if line[1:13] == ' Self Terms ':
                                entr = line.split()
                                j = total_prot[int(entr[2].strip())]
                                total_val[0][j] = total_val[0][j] + float(entr[4])
                                total_val[1][j] = total_val[1][j] + float(entr[5])
                                total_val[2][j] = total_val[1][j] + float(entr[6])
                                total_val[3][j] = total_val[1][j] + float(entr[7])

              finally:
                  filecillo.close()
            except IOError:
               pass

        self.dataset_sr_dialog_selfmd = Pmw.Dialog(self.parent,title = 'Data Set',command = self.close_ds_sr_dialog_vs_selfmd)
        self.dataset_sr_dialog_selfmd.withdraw()

        self.dataset_sr_dialog_selfmd.geometry('550x280')
        self.dataset_sr_dialog_selfmd.bind('<Return>',self.close_ds_sr_dialog_vs_selfmd)

        self.sf = Pmw.ScrolledFrame(self.dataset_sr_dialog_selfmd.interior(),
                labelpos = 'n', label_text = 'Self terms',
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

        have_single = 0
        have_cross = 0

        self.addLabel('',4)
        self.addLabel("Desolvation Average",4)
        self.addLabel("Desolvation Std.",4)
        self.addLabel("Apolar Avgerage",4)
        self.addLabel("Apolar Std.",4)
        for i in prot_list:
         current_label = 'Residue %i' %(i[0])
         self.addLabel(current_label,4)
         self.addButton_red(str(total_val[0][i[1]]),4)
         self.addButton_red(str(total_val[1][i[1]]),4)
         self.addButton_red(str(total_val[2][i[1]]),4)
         self.addButton_red(str(total_val[3][i[1]]),4)


        self.dataset_sr_dialog_selfmd.show()


    def show_table_sr_selfterms_singlestruct(self):
        my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueEnergies.out"
        total_prot = {}

        j = 0
        total_val = []


        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                        if line[1:13] == ' Self Terms ':
                                entr = line.split()
                                if total_prot.get(int(entr[2].strip()),-1) == -1:
                                   total_prot[int(entr[2].strip())] = j
                                   j = j + 1

                prot_list = [x for x in total_prot.iteritems()]
                prot_list.sort(key=lambda x: x[0])

                for k in range(0,2):
                     row_tmp = []
                     for l in range(0,len(prot_list)):
                        row_tmp.append(0.0)
                     total_val.append(row_tmp)

                for line in list:

                        if line[1:13] == ' Self Terms ':
                                entr = line.split()
                                j = total_prot[int(entr[2].strip())]
                                total_val[0][j] = total_val[0][j] + float(entr[4])
                                total_val[1][j] = total_val[1][j] + float(entr[5])

              finally:
                  filecillo.close()
            except IOError:
               pass

        self.dataset_sr_dialog_selfsingle = Pmw.Dialog(self.parent,title = 'Data Set',command = self.close_ds_sr_dialog_vs_selfsingle)
        self.dataset_sr_dialog_selfsingle.withdraw()

        self.dataset_sr_dialog_selfsingle.geometry('550x280')
        self.dataset_sr_dialog_selfsingle.bind('<Return>',self.close_ds_sr_dialog_vs_selfsingle)

        self.sf = Pmw.ScrolledFrame(self.dataset_sr_dialog_selfsingle.interior(),
                labelpos = 'n', label_text = 'Self terms',
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

        have_single = 0
        have_cross = 0

        self.addLabel('',2)
	self.addLabel("Desolvation",2)
        self.addLabel("Apolar",2)
        for i in prot_list:
         current_label = 'Residue %i' %(i[0])
         self.addLabel(current_label,2)
         self.addButton_red(str(total_val[0][i[1]]),2)
         self.addButton_red(str(total_val[1][i[1]]),2)

        self.dataset_sr_dialog_selfsingle.show()



    def show_table_sr_vs_real_singlestruct(self):

        my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueEnergies.out"
        total_lig = {}
        total_prot = {}

        i = 0
        j = 0
        total_val = []

        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                        if line[1:13] == 'Cross Terms ':
                                entr = line.split()
                                if total_lig.get(int(entr[4].strip()),-1) == -1:
                                   total_lig[int(entr[4].strip())] = i
                                   i = i + 1

                                if total_prot.get(int(entr[2].strip()),-1) == -1:
                                   total_prot[int(entr[2].strip())] = j
                                   j = j + 1

                lig_list = [x for x in total_lig.iteritems()]
                lig_list.sort(key=lambda x: x[0]) # sort by key

                prot_list = [x for x in total_prot.iteritems()]
                prot_list.sort(key=lambda x: x[0])

                for k in range(0,len(lig_list)):
                     row_tmp = []
                     for l in range(0,len(prot_list)):
                        row_tmp.append(0.0)
                     total_val.append(row_tmp)

                for line in list:
                        if line[1:13] == 'Cross Terms ':
                                entr = line.split()
                                i = total_lig[int(entr[4].strip())]
                                j = total_prot[int(entr[2].strip())]
                                total_val[i][j] = total_val[i][j] + float(entr[10])

              finally:
                  filecillo.close()
            except IOError:
               pass

        self.dataset_sr_dialog_vs = Pmw.Dialog(self.parent,title = 'Data Set',command = self.close_ds_sr_dialog_vs)
        self.dataset_sr_dialog_vs.withdraw()

        self.dataset_sr_dialog_vs.geometry('550x280')
        self.dataset_sr_dialog_vs.bind('<Return>',self.close_ds_sr_dialog_vs)

        self.sf = Pmw.ScrolledFrame(self.dataset_sr_dialog_vs.interior(),
                labelpos = 'n', label_text = 'Residue vs residue',
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

        have_single = 0
        have_cross = 0

        self.addLabel('',len(lig_list))
        for i in lig_list:
         current_label = 'Residue %i' %(i[0])
         self.addLabel(current_label,len(lig_list))
        for i in prot_list:
         current_label = 'Residue %i' %(i[0])
         self.addLabel(current_label,len(lig_list))
         for j in lig_list:
          self.addButton_red(str(total_val[j[1]][i[1]]),len(lig_list))

        self.dataset_sr_dialog_vs.show()



    def show_table_sr_vs_real(self):

	if len(self.select_outputfile_entry2.get()) == 0:
	 self.screwup("Error","You must provide an output root name")
         return

        my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueStatistics.out"

	if not os.path.isfile(my_filename):
         my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
         my_filename += "_ResidueEnergies.out"
         if not os.path.isfile(my_filename):
          self.screwup("Error","No ISM output found with this root name")
         else:
          self.show_table_sr_vs_real_singlestruct()
#	  self.show_table_sr_selfterms_singlestruct()
          return


	total_lig = {}
        total_prot = {}

	i = 0 
        j = 0
	total_val = []

        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                        if line[1:13] == 'Cross Terms ':
                                entr = line.split()
				if total_lig.get(int(entr[4].strip()),-1) == -1:
				   total_lig[int(entr[4].strip())] = i
                                   i = i + 1

                                if total_prot.get(int(entr[2].strip()),-1) == -1:
                                   total_prot[int(entr[2].strip())] = j
                                   j = j + 1

		lig_list = [x for x in total_lig.iteritems()]
		lig_list.sort(key=lambda x: x[0]) # sort by key

                prot_list = [x for x in total_prot.iteritems()]
                prot_list.sort(key=lambda x: x[0]) 

		for k in range(0,len(lig_list)):
                     row_tmp = []
		     for l in range(0,len(prot_list)):
		        row_tmp.append(0.0)
                     total_val.append(row_tmp)

                for line in list:
                        if line[1:13] == 'Cross Terms ':
                                entr = line.split()
                                i = total_lig[int(entr[4].strip())]
         			j = total_prot[int(entr[2].strip())]
                                total_val[i][j] = total_val[i][j] + float(entr[15])

              finally:
                  filecillo.close()
            except IOError:
               pass


        self.dataset_sr_dialog_vs = Pmw.Dialog(self.parent,title = 'Data Set',command = self.close_ds_sr_dialog_vs)
        self.dataset_sr_dialog_vs.withdraw()

        self.dataset_sr_dialog_vs.geometry('550x280')
        self.dataset_sr_dialog_vs.bind('<Return>',self.close_ds_sr_dialog_vs)

        self.sf = Pmw.ScrolledFrame(self.dataset_sr_dialog_vs.interior(),
                labelpos = 'n', label_text = 'Residue vs residue',
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

        have_single = 0
        have_cross = 0

	self.addLabel('',len(lig_list))
	for i in lig_list:
         current_label = 'Residue %i' %(i[0])
         self.addLabel(current_label,len(lig_list))
	for i in prot_list:
         current_label = 'Residue %i' %(i[0])
         self.addLabel(current_label,len(lig_list))
         for j in lig_list:
          self.addButton_red(str(total_val[j[1]][i[1]]),len(lig_list))


#	for i in lig_list:
#          for j in prot_list:
#        self.addLabel('Coulombic term',2);
#        self.addButton(qq_average,2);
#        self.addButton(qq_std,2);

        self.dataset_sr_dialog_vs.show()

    def pre_save_table_sr_vs(self):
        if len(self.select_outputfile_entry2.get()) == 0:
         self.screwup("Error","You must provide an output root name")
         return

        myres = self.analysis_sr_residues_entry.get()

        if len(myres) == 0:
         self.screwup("Error","You must provide at least a residue number ")
         return

        try:
          testi = int(myres)
        except:
         self.screwup("Error","You must provide at least a residue number ")
         return



        my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueEnergies.out"

        step = []
        Coulombic = []
        vdw = []
        desolvSingle = []
        desolvCross = []
        apolarSingle = []
        apolarCross = []
        hbond = []
        TotalCross = []

        qq_average = 0.0
        qq_std = 0.0

        vdw_average = 0.0
        vdw_std = 0.0

        desolvSingle_average = 0.0
        desolvSingle_std = 0.0

        desolvCross_average = 0.0
        desolvCross_std = 0.0

        apolarSingle_average = 0.0
        apolarSingle_std = 0.0

        hbond_average = 0.0
        hbond_std = 0.0

        TotalCross_average = 0.0
        TotalCross_std = 0.0

        myres = self.analysis_sr_residues_entry.get()
        myres2 = self.analysis_sr_residues_entry2.get()
        try:
         if len(myres2) != 0:
          testj = int(myres2)
        except:
         self.screwup("Error","Second residue is not a number")
         return

        current_step = -1
        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                        if line[1:12] == '// SnapShot':
                                step.append( int(line[14:19]))
                                Coulombic.append(0.0)
                                desolvCross.append(0.0)
                                apolarCross.append(0.0)
                                vdw.append(0.0)
                                hbond.append(0.0)
                                TotalCross.append(0.0)
                                current_step = current_step + 1

                        if line.strip()[0:11] == 'Self Terms ':
                                entr = line.split()
                                if entr[1] == '********':
                                   entr[1] = '9999'
                                if entr[2] == '********':
                                   entr[2] = '9999'

                                if int(entr[2]) == int(myres):
                                     desolvSingle.append( float(entr[4]))
                                     apolarSingle.append( float(entr[5]))

                        if line[1:13] == 'Cross Terms ':
                                if current_step == -1: # amber, not moldynamics
                                    current_step = 0
                                    step.append(1);
                                    Coulombic.append(0.0)
                                    desolvCross.append(0.0)
                                    apolarCross.append(0.0)
                                    vdw.append(0.0)
                                    hbond.append(0.0)
                                    TotalCross.append(0.0)

                                entr = line.split()

                                if entr[1] == '********':
                                   entr[1] = '9999'
                                if entr[2] == '********':
                                   entr[2] = '9999'

                                try:
                                    current_res = int(entr[4])
                                    other_res = int(entr[2])
                                except:
                                    current_res = -1
                                    other_res = -1
                                if  len(myres2) == 0:
                                 if current_res == int(myres) or other_res == int(myres):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])
                                else:
                                 if  ( current_res == int(myres) and other_res == int(myres2)) or (current_res == int(myres2) and other_res == int(myres)):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])


              finally:
                  filecillo.close()
            except IOError:
               pass
        print "Read done"

	n = 0
        try:
         for i in range(0,len(step)): 
              n = n + 1

              delta_qq = Coulombic[i] - qq_average
              qq_average = qq_average + delta_qq/n
              qq_std = qq_std + delta_qq*(Coulombic[i] - qq_average)

              delta_vdw = vdw[i] - vdw_average
              vdw_average = vdw_average + delta_vdw/n
              vdw_std = vdw_std + delta_vdw*(vdw[i] - vdw_average)

              delta_ds = desolvSingle[i] - desolvSingle_average
              desolvSingle_average = desolvSingle_average + delta_ds/n
              desolvSingle_std= desolvSingle_std + delta_ds*(desolvSingle[i] - desolvSingle_average)

              delta_dc = desolvCross[i] - desolvCross_average
              desolvCross_average = desolvCross_average + delta_dc/n
              desolvCross_std= desolvCross_std + delta_dc*(desolvCross[i] - desolvCross_average)

              delta_apolar = apolarSingle[i] - apolarSingle_average
              apolarSingle_average = apolarSingle_average + delta_apolar/n
              apolarSingle_std= apolarSingle_std + delta_apolar*(apolarSingle[i] - apolarSingle_average)

              delta_hbond = hbond[i] - hbond_average
              hbond_average = hbond_average + delta_hbond/n
              hbond_std = hbond_std + delta_hbond * (hbond[i]-hbond_average)

              delta_total = TotalCross[i] - TotalCross_average
              TotalCross_average = TotalCross_average + delta_total/n
              TotalCross_std= TotalCross_std + delta_total*(TotalCross[i] - TotalCross_average)

         qq_std = math.sqrt(qq_std/n)
         vdw_std = math.sqrt(vdw_std/n)
         desolvSingle_std = math.sqrt(desolvSingle_std/n)
         desolvCross_std = math.sqrt(desolvCross_std/n)
         apolarSingle_std = math.sqrt(apolarSingle_std/n)
         hbond_std = math.sqrt(hbond_std/n)
         TotalCross_std = math.sqrt(TotalCross_std/n)
        except:
         self.screwup("Error","No information was found for this residue/pair")
         return

        myres2_text = ""
        if len(myres2) != 0:
         myres2_text = "_vs_%s" %(myres2)
        oroot = self.select_outputfile_entry2.get()
        csv = open("%s_stats_residue_%s%s.csv" %(oroot,myres,myres2_text),"wb")

        try:
         print >>csv,"Term; Average; Std Deviation"
	 print >>csv,"Coulombic;%f;%f" %(qq_average,qq_std)
         print >>csv,"van der Waals;%f;%f" %(vdw_average,vdw_std)
         print >>csv,"Desolvation single;%f;%f" %(desolvSingle_average,desolvSingle_std)
         print >>csv,"Desolvation cross;%f;%f" %(desolvCross_average,desolvCross_std)
         print >>csv,"Apolar;%f;%f" %(apolarSingle_average,apolarSingle_std)
         print >>csv,"Hydrogen bond;%f;%f" %(hbond_average,hbond_std)
         print >>csv,"Total Cross;%f;%f" %(TotalCross_average,TotalCross_std)
        except:
         self.screwup("Error","Cannot write CSV file")
        csv.close()
        self.screwup("Info","Data set was written to %s_stats_residue_%s%s.csv" %(oroot,myres,myres2_text))




    def show_table_sr_vs(self):

        if len(self.select_outputfile_entry2.get()) == 0:
         self.screwup("Error","You must provide an output root name")
         return

        myres = self.analysis_sr_residues_entry.get()

        if len(myres) == 0:
         self.screwup("Error","You must provide at least a residue number ")
         return

        try:
	  testi = int(myres)
        except:
         self.screwup("Error","You must provide at least a residue number ")
         return



        my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueEnergies.out"

        step = []
        Coulombic = []
        vdw = []
        desolvSingle = []                                                                                            
        desolvCross = []
        apolarSingle = []                                                                                            
        apolarCross = []
	hbond = []
        TotalCross = []                                                                                         

        qq_average = 0.0
        qq_std = 0.0

        vdw_average = 0.0
        vdw_std = 0.0

	desolvSingle_average = 0.0
        desolvSingle_std = 0.0

	desolvCross_average = 0.0
        desolvCross_std = 0.0

	apolarSingle_average = 0.0
        apolarSingle_std = 0.0
	
	hbond_average = 0.0
	hbond_std = 0.0

	TotalCross_average = 0.0
	TotalCross_std = 0.0

        myres = self.analysis_sr_residues_entry.get()                                                                
        myres2 = self.analysis_sr_residues_entry2.get()
	try:
         if len(myres2) != 0:
          testj = int(myres2)
	except:
         self.screwup("Error","Second residue is not a number")
	 return

        current_step = -1
        if os.path.isfile(my_filename):
            try:                
              filecillo = open(my_filename,'r')
              try:              
                list = filecillo.readlines()
                for line in list:
                        if line[1:12] == '// SnapShot': 
                                step.append( int(line[14:19]))
                                Coulombic.append(0.0)                                                                                   
                                desolvCross.append(0.0)
                                apolarCross.append(0.0)                                                                                      
                                vdw.append(0.0)
				hbond.append(0.0)
                                TotalCross.append(0.0)                                                                                       
                                current_step = current_step + 1

                        if line.strip()[0:11] == 'Self Terms ':
                                entr = line.split()
                                if entr[1] == '********':
                                   entr[1] = '9999'
                                if entr[2] == '********':
                                   entr[2] = '9999'

                                if int(entr[2]) == int(myres):
                                     desolvSingle.append( float(entr[4]))
                                     apolarSingle.append( float(entr[5]))

                        if line[1:13] == 'Cross Terms ':
                                if current_step == -1: # amber, not moldynamics
                                    current_step = 0
                                    step.append(1);
                                    Coulombic.append(0.0)
                                    desolvCross.append(0.0)
                                    apolarCross.append(0.0)
                                    vdw.append(0.0)
				    hbond.append(0.0)
                                    TotalCross.append(0.0)

                                entr = line.split()

                                if entr[1] == '********':
                                   entr[1] = '9999'
                                if entr[2] == '********':
                                   entr[2] = '9999'

                                try:
                                    current_res = int(entr[4])
				    other_res = int(entr[2])
                                except:
                                    current_res = -1
				    other_res = -1

#                                if current_res == int(myres) or  other_res == int(myres):
#                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])		
#                                    vdw[current_step] = vdw[current_step] + float( entr[6])
#                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
#                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
#                                    hbond[current_step] = hbond[current_step] + float(entr[9])
#                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])
#
                                if  len(myres2) == 0:
                                 if current_res == int(myres) or other_res == int(myres):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])
                                else:
                                 if  ( current_res == int(myres) and other_res == int(myres2)) or (current_res == int(myres2) and other_res == int(myres)):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])


              finally:
                  filecillo.close()
            except IOError:
               pass
        print "Read done"

        n = 0
        try:
         for i in range(0,len(step)):
              n = n + 1

              delta_qq = Coulombic[i] - qq_average
              qq_average = qq_average + delta_qq/n
              qq_std = qq_std + delta_qq*(Coulombic[i] - qq_average)

              delta_vdw = vdw[i] - vdw_average
              vdw_average = vdw_average + delta_vdw/n
              vdw_std = vdw_std + delta_vdw*(vdw[i] - vdw_average)

              delta_ds = desolvSingle[i] - desolvSingle_average
              desolvSingle_average = desolvSingle_average + delta_ds/n
              desolvSingle_std= desolvSingle_std + delta_ds*(desolvSingle[i] - desolvSingle_average)

              delta_dc = desolvCross[i] - desolvCross_average
              desolvCross_average = desolvCross_average + delta_dc/n
              desolvCross_std= desolvCross_std + delta_dc*(desolvCross[i] - desolvCross_average)

              delta_apolar = apolarSingle[i] - apolarSingle_average
              apolarSingle_average = apolarSingle_average + delta_apolar/n
              apolarSingle_std= apolarSingle_std + delta_apolar*(apolarSingle[i] - apolarSingle_average)

	      delta_hbond = hbond[i] - hbond_average
	      hbond_average = hbond_average + delta_hbond/n
              hbond_std = hbond_std + delta_hbond * (hbond[i]-hbond_average)

              delta_total = TotalCross[i] - TotalCross_average
              TotalCross_average = TotalCross_average + delta_total/n
              TotalCross_std= TotalCross_std + delta_total*(TotalCross[i] - TotalCross_average)

         qq_std = math.sqrt(qq_std/n)
	 vdw_std = math.sqrt(vdw_std/n)
	 desolvSingle_std = math.sqrt(desolvSingle_std/n)
	 desolvCross_std = math.sqrt(desolvCross_std/n)
	 apolarSingle_std = math.sqrt(apolarSingle_std/n)
	 hbond_std = math.sqrt(hbond_std/n)
	 TotalCross_std = math.sqrt(TotalCross_std/n)
        except:
         self.screwup("Error","No information was found for this residue/pair")
         return

        self.dataset_sr_dialog_st = Pmw.Dialog(self.parent,title = 'Data Set',command = self.close_ds_sr_dialog_st)
        self.dataset_sr_dialog_st.withdraw()

        self.dataset_sr_dialog_st.geometry('550x380')
        self.dataset_sr_dialog_st.bind('<Return>',self.close_ds_sr_dialog_st)

        self.dataset_sr_dialog_st_save_box = Pmw.ButtonBox(self.dataset_sr_dialog_st.interior(),orient='horizontal', padx=0,pady=0)
        self.dataset_sr_dialog_st_save_box.add('Save',command = self.pre_save_table_sr_vs)
        self.dataset_sr_dialog_st_save_box.pack(expand = 0, padx = 0, pady = 5)


        self.sf = Pmw.ScrolledFrame(self.dataset_sr_dialog_st.interior(),
                labelpos = 'n', label_text = 'Energy terms for residue %s' %(myres) ,
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

        have_single = 0
        have_cross = 0

        self.addLabel('',2)
        self.addLabel('Average',2)
        self.addLabel('Std',2)

        self.addLabel('Coulombic term',2);
        self.addButton(qq_average,2);
        self.addButton(qq_std,2);

        self.addLabel('van der Waals term',2);
        self.addButton(vdw_average,2);
        self.addButton(vdw_std,2);

        self.addLabel('Desolvation single term',2);
        self.addButton(desolvSingle_average,2);
        self.addButton(desolvSingle_std,2);

        self.addLabel('Desolvation cross term',2);
        self.addButton(desolvCross_average,2);
        self.addButton(desolvCross_std,2);

        self.addLabel('Apolar single term',2);
        self.addButton(apolarSingle_average,2);
        self.addButton(apolarSingle_std,2);

        self.addLabel('Hydrogen bond term',2);
        self.addButton(hbond_average,2);
        self.addButton(hbond_std,2);

        self.addLabel('Total',2);
        self.addButton(TotalCross_average,2);
        self.addButton(TotalCross_std,2);

        self.dataset_sr_dialog_st.show()

    def pre_save_dataset_sr_dialog(self):
        if len(self.select_outputfile_entry2.get()) == 0:
         self.screwup("Error","You must provide an output root name")
         return

        myres = self.analysis_sr_residues_entry.get()

        if len(myres) == 0:
         self.screwup("Error","You must provide at least a residue number ")
         return

        my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueEnergies.out"

        try:
          testi = int(myres)
        except:
         self.screwup("Error","You must provide at least a residue number ")
         return


        step = []
        Coulombic = []
        vdw = []
        desolvSingle = []
        desolvCross = []
        apolarSingle = []
        apolarCross = []
        hbond = []
        TotalCross = []
        myres = self.analysis_sr_residues_entry.get()
        myres2 = self.analysis_sr_residues_entry2.get()
        try:
         if len(myres2) != 0:
          testj = int(myres2)
        except:
         self.screwup("Error","Second residue is not a number")
         return

        current_step = -1
        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                        if line[1:12] == '// SnapShot':
                                step.append( int(line[14:19]))
                                Coulombic.append(0.0)
                                desolvCross.append(0.0)
                                apolarCross.append(0.0)
                                vdw.append(0.0)
                                hbond.append(0.0)
                                TotalCross.append(0.0)
                                current_step = current_step + 1

                        if line.strip()[0:12] == 'Self Terms  ':
                                entr = line.split()
                                if entr[1] == '********':
                                   entr[1] = '9999'
                                if entr[2] == '********':
                                   entr[2] = '9999'

                                if int(entr[2]) == int(myres):
                                     desolvSingle.append( float(entr[4]))
                                     apolarSingle.append( float(entr[5]))

                        if line[1:13] == 'Cross Terms ':

                                if current_step == -1: # amber, not moldynamics
                                    current_step = 0
                                    step.append(1);
                                    Coulombic.append(0.0)
                                    desolvCross.append(0.0)
                                    apolarCross.append(0.0)
                                    vdw.append(0.0)
                                    hbond.append(0.0)
                                    TotalCross.append(0.0)

                                entr = line.split()

                                if entr[1] == '********':
                                   entr[1] = '9999'
                                if entr[2] == '********':
                                   entr[2] = '9999'

                                try:
                                    current_res = int(entr[4])
                                    other_res = int(entr[2])
                                except:
                                    current_res = -1
                                    other_res = -1

                                if  len(myres2) == 0:
                                 if current_res == int(myres) or other_res == int(myres):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])
                                else:
                                 if  ( current_res == int(myres) and other_res == int(myres2)) or (current_res == int(myres2) and other_res == int(myres)):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])


              finally:
                  filecillo.close()
            except IOError:
               pass
        print "Read done"
        myres2_text = ""
        if len(myres2) != 0:
         myres2_text = "_vs_%s" %(myres2)
        oroot = self.select_outputfile_entry2.get()
	csv = open("%s_residue_%s%s.csv" %(oroot,myres,myres2_text),"wb")

        try:
         print >>csv,"Snapshot; Total; Coulombic; van der Waals; Desolvation Self; Desolvation Cross; Apolar; Hydrogen Bond"
         for i in range(0,len(step)):
              print >>csv,"%i;%f;%f;%f;%f;%f;%f;%f" %(step[i],TotalCross[i],Coulombic[i],vdw[i],desolvSingle[i],desolvCross[i],apolarCross[i],hbond[i])

        except:
         self.screwup("Error","Cannot write CSV file")
	csv.close()
        self.screwup("Info","Data set was written to %s_residue_%s%s.csv" %(oroot,myres,myres2_text))



    def show_table_sr(self):

        if len(self.select_outputfile_entry2.get()) == 0:
         self.screwup("Error","You must provide an output root name")
         return

        myres = self.analysis_sr_residues_entry.get()

        if len(myres) == 0:
         self.screwup("Error","You must provide at least a residue number ")
         return

	my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry2.get())
        my_filename += "_ResidueEnergies.out"

        try:
          testi = int(myres)
        except:
         self.screwup("Error","You must provide at least a residue number ")
         return


        step = []
        Coulombic = []
        vdw = []
        desolvSingle = []
        desolvCross = []
        apolarSingle = []
	apolarCross = []
	hbond = []
        TotalCross = []
	myres = self.analysis_sr_residues_entry.get()
        myres2 = self.analysis_sr_residues_entry2.get()
        try:
         if len(myres2) != 0:
          testj = int(myres2)
        except:
         self.screwup("Error","Second residue is not a number")
         return


        current_step = -1
        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
			if line[1:12] == '// SnapShot':
				step.append( int(line[14:19]))
				Coulombic.append(0.0)
                                desolvCross.append(0.0)
                                apolarCross.append(0.0)
                                vdw.append(0.0)
				hbond.append(0.0)
                                TotalCross.append(0.0)
				current_step = current_step + 1

                        if line.strip()[0:12] == 'Self Terms  ':
	                        entr = line.split()
	                        if entr[1] == '********':
	                           entr[1] = '9999'
	                        if entr[2] == '********':
	                           entr[2] = '9999'

				if int(entr[2]) == int(myres):
				     desolvSingle.append( float(entr[4]))
				     apolarSingle.append( float(entr[5]))

	                if line[1:13] == 'Cross Terms ':

				if current_step == -1: # amber, not moldynamics
                                    current_step = 0
                                    step.append(1);
                                    Coulombic.append(0.0)
                                    desolvCross.append(0.0)
				    apolarCross.append(0.0)
                                    vdw.append(0.0)
				    hbond.append(0.0)
                                    TotalCross.append(0.0)

	                        entr = line.split()

	                        if entr[1] == '********':
	                           entr[1] = '9999'
	                        if entr[2] == '********':
	                           entr[2] = '9999'

				try:
				    current_res = int(entr[4])
				    other_res = int(entr[2])
				except:
                                    current_res = -1
 				    other_res = -1

#				if current_res == int(myres) or other_res == int(myres):
#				    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
#				    vdw[current_step] = vdw[current_step] + float( entr[6])
#				    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
#                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
#				    hbond[current_step] = hbond[current_step] + float(entr[9])
#                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10]) 

                                if  len(myres2) == 0:
                                 if current_res == int(myres) or other_res == int(myres):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])
                                else:
                                 if  ( current_res == int(myres) and other_res == int(myres2)) or (current_res == int(myres2) and other_res == int(myres)):
                                    Coulombic[current_step] = Coulombic[current_step] + float(entr[5])
                                    vdw[current_step] = vdw[current_step] + float( entr[6])
                                    desolvCross[current_step] = desolvCross[current_step] + float(entr[7])
                                    apolarCross[current_step] = apolarCross[current_step] + float(entr[8])
                                    hbond[current_step] = hbond[current_step] + float(entr[9])
                                    TotalCross[current_step] = TotalCross[current_step] + float(entr[10])


              finally:
                  filecillo.close()
            except IOError:
               pass
        print "Read done"

        self.dataset_sr_dialog = Pmw.Dialog(self.parent,title = 'Data Set',command = self.close_ds_sr_dialog)
        self.dataset_sr_dialog.withdraw()

        self.dataset_sr_dialog.geometry('950x280')
        self.dataset_sr_dialog.bind('<Return>',self.close_ds_sr_dialog)

        self.dataset_sr_dialog_save_box = Pmw.ButtonBox(self.dataset_sr_dialog.interior(),orient='horizontal', padx=0,pady=0)
        self.dataset_sr_dialog_save_box.add('Save',command = self.pre_save_dataset_sr_dialog)
        self.dataset_sr_dialog_save_box.pack(expand = 0, padx = 0, pady = 5)


        self.sf = Pmw.ScrolledFrame(self.dataset_sr_dialog.interior(),
                labelpos = 'n', label_text = 'Energy terms for residue %s' %(myres) ,
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

        have_single = 0
        have_cross = 0

        try:
         self.addLabel('Snap',7)
         self.addLabel('Total',7)
         self.addLabel('Coulombic',7)
         self.addLabel('van der Waals',7)
         self.addLabel('Desolvation Self',7)
         self.addLabel('Desolvation Cross',7)
         self.addLabel('Apolar',7)
         self.addLabel('Hydrogen Bond',7)



 	 for i in range(0,len(step)):
              self.addButton(step[i],7);
              self.addButton(TotalCross[i],7);
              self.addButton(Coulombic[i],7);
              self.addButton(vdw[i],7);
              self.addButton(desolvSingle[i],7);
              self.addButton(desolvCross[i],7);
              self.addButton(apolarCross[i],7);
              self.addButton(hbond[i],7);

        except:
         self.screwup("Error","No information was found for this residue/pair")
	 return
        self.dataset_sr_dialog.show()




    def plot_things(self):
	my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry.get())
	my_filename += "_GlobalEnergies.out"
	step = []
	totalCoulombic = []
	vdwEnergy = []
	desolvEneRec = []
	desolvEneLig = []
	apolarEne = []
        hbCorrection = []
        totalEne = []
        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                for line in list:
                    if line[0]!='!' and line[0]!='#':
                        entr = line.split()
			step.append( int(entr[0]))
			if entr[1] == '********':
			   entr[1] = '9999'
                        if entr[2] == '********':
                           entr[2] = '9999'
                        if entr[3] == '********':
                           entr[3] = '9999'
                        if entr[4] == '********':
                           entr[4] = '9999'
                        if entr[5] == '********':
                           entr[5] = '9999'
                        if entr[6] == '********':
                           entr[6] = '9999'
                        if entr[7] == '********':
                           entr[7] = '9999'

# Bugfix. ISM now prints Coulombic for vacuum, so we have to move along one column
#                        totalCoulombic.append( float(entr[1]))
#                        vdwEnergy.append( float(entr[2]))
#                        desolvEneRec.append( float(entr[3]))
#                        desolvEneLig.append( float(entr[4]))
#                        apolarEne.append( float(entr[5]))
#                        hbCorrection.append( float(entr[6]))
#                        totalEne.append(float(entr[7]))

			totalCoulombic.append( float(entr[1]))
			vdwEnergy.append( float(entr[3]))
			desolvEneRec.append( float(entr[4]))
			desolvEneLig.append( float(entr[5]))
			apolarEne.append( float(entr[6]))
			hbCorrection.append( float(entr[7]))
			totalEne.append(float(entr[8]))


        	img_check = 0
	        img_check_sel = self.plot_image.getcurselection()
	        for th1 in img_check_sel:
	           if th1 == 'Write also the plot as a PNG image':
	            img_check = 1

		oroot = oroot = self.select_outputfile_entry.get()
        	plot_selection = self.plot_types_checkbutton.getcurselection()
	        for thing in plot_selection:
	            if thing == 'Coulombic energy':
                       qq = Gnuplot.Gnuplot(persist=1)
		       qq('set style data linespoints')
                       rg = (max(totalCoulombic)-min(totalCoulombic))/10.0
                       qq('set yrange [%f:%f]' %(min(totalCoulombic)-rg,max(totalCoulombic)+rg))
                       qq_data = Gnuplot.Data(step, totalCoulombic, title='Total Coulombic energy')
	               qq.xlabel("Time step")
       	               qq.ylabel("Energy (kcal/mol)")
                       qq.plot(qq_data)
                       if img_check == 1:
		        qq.hardcopy("%s_coulomb.png" %(oroot), terminal='png')

	            elif thing == 'Van der Waals energy':
	                vdw = Gnuplot.Gnuplot(persist=1)
	                vdw('set style data linespoints')
                        rg = (max(vdwEnergy)-min(vdwEnergy))/10.0
                        vdw('set yrange [%f:%f]' %(min(vdwEnergy)-rg,max(vdwEnergy)+rg))
	                vdw_data = Gnuplot.Data(step, vdwEnergy, title='Total Van der Waals energy')
	                vdw.xlabel("Time step")
	                vdw.ylabel("Energy (kcal/mol)")
	                vdw.plot(vdw_data)
			if img_check == 1:
                         vdw.hardcopy("%s_vdw.png" %(oroot), terminal='png')

	            elif thing == 'Receptor desolvation energy':
	                dsrec = Gnuplot.Gnuplot(persist=1)
	                dsrec('set style data linespoints')
                        rg = (max(desolvEneRec)-min(desolvEneRec))/10.0
                        dsrec('set yrange [%f:%f]' %(min(desolvEneRec)-rg,max(desolvEneRec)+rg))
	                dsrec_data = Gnuplot.Data(step, desolvEneRec, title='Total Desolvation energy for receptor')
	                dsrec.xlabel("Time step")
	                dsrec.ylabel("Energy (kcal/mol)")
	                dsrec.plot(dsrec_data)
                        if img_check == 1:
                         dsrec.hardcopy("%s_receptor_desolvation.png" %(oroot), terminal='png')
                    elif thing == 'Ligand desolvation energy':
			dslig = Gnuplot.Gnuplot(persist=1)
	                dslig('set style data linespoints')
                        rg = (max(desolvEneLig)-min(desolvEneLig))/10.0
                        dslig('set yrange [%f:%f]' %(min(desolvEneLig)-rg,max(desolvEneLig)+rg))
	                dslig_data = Gnuplot.Data(step, desolvEneLig, title='Total Desolvation energy for ligand')
	                dslig.xlabel("Time step")
	                dslig.ylabel("Energy (kcal/mol)")
	                dslig.plot(dslig_data)
                        if img_check == 1:
                         dslig.hardcopy("%s_ligand_desolvation.png" %(oroot), terminal='png')
                    elif thing == 'Apolar energy':
			apolar = Gnuplot.Gnuplot(persist=1)
	                apolar('set style data linespoints')
                        rg = (max(apolarEne)-min(apolarEne))/10.0
                        apolar('set yrange [%f:%f]' %(min(apolarEne)-rg,max(apolarEne)+rg))
	                apolar_data = Gnuplot.Data(step, apolarEne, title='Total Apolar energy')
	                apolar.xlabel("Time step")
	                apolar.ylabel("Energy (kcal/mol)")
	                apolar.plot(apolar_data)
                        if img_check == 1:
                         apolar.hardcopy("%s_apolar.png" %(oroot), terminal='png')
                    elif thing == 'Hydrogen bond energy':
			hb = Gnuplot.Gnuplot(persist=1)
	                hb('set style data linespoints')
			rg = (max(hbCorrection)-min(hbCorrection))/10.0
                        hb('set yrange [%f:%f]' %(min(hbCorrection)-rg,max(hbCorrection)+rg))
	                hb_data = Gnuplot.Data(step, hbCorrection, title='Total Hydrogen bond energy')
	                hb.xlabel("Time step")
	                hb.ylabel("Energy (kcal/mol)")
	                hb.plot(hb_data)
                        if img_check == 1:
                         hb.hardcopy("%s_hydrogenbond.png" %(oroot), terminal='png')
                    elif thing == 'Total energy':
			totale = Gnuplot.Gnuplot(persist=1)
			totale('set style data linespoints')
                        rg = (max(totalEne)-min(totalEne))/10.0
                        totale('set yrange [%f:%f]' %(min(totalEne)-rg,max(totalEne)+rg))
			totale_data = Gnuplot.Data(step, totalEne, title='Total energy')
			totale.xlabel("Time step")
			totale.ylabel("Energy (kcal/mol)")
			totale.plot(totale_data)
                        if img_check == 1:
                         totale.hardcopy("%s_total.png" %(oroot), terminal='png')

              finally:
                  filecillo.close()
            except IOError:
               pass

    def run_ism(self):
 
        input_file_for_ism = os.path.join(self.settings['working_dir'],'output.in');
        text_file = open(input_file_for_ism, "w")
	type = "Input File Type:         %s\n" %(self.input_type)

	prot_res = self.select_prot_residues_entry.get().split(',')

	rfirst = ""
        rlast = ""
        final_res_prot = ""
	for res in prot_res:
            range_res = res.split('-')
            if len(range_res) == 2:
                rfirst = range_res[0].strip()
                rlast = range_res[1].strip()
            else:
                rfirst = range_res[0].strip()
                rlast = range_res[0].strip()
            final_res_prot += "%4i%4i" %(int(rfirst),int(rlast))


        lig_res = self.select_lig_residues_entry.get().split(',')

        rfirst = ""
        rlast = ""
        final_res_lig = ""
        for res in lig_res:
            range_res = res.split('-')
            if len(range_res) == 2:
                rfirst = range_res[0].strip()
                rlast = range_res[1].strip()
            else:
                rfirst = range_res[0].strip()
                rlast = range_res[0].strip()
            final_res_lig += "%4i%4i" %(int(rfirst),int(rlast))


	receptor = "Receptor Residues:       %s\n" %(final_res_prot)
	ligand = "Ligand Residues:         %s\n" %(final_res_lig)
        name_base1 = os.path.split(self.select_inputfile_entry.get())
	name_base2 = os.path.split(self.select_inputfilex_entry.get())

	#my_input = "Complex Name:            %s\n" %(name_base2[0]) # Old version
	my_input = "pdb/top Name:            %s\n" %(name_base1[1])
	my_input2 = "crd/mdcrd Name:          %s\n" %(name_base2[1])
	my_outpt = "output Name:             %s\n" %(self.select_outputroot_entry.get())
        text_file.write(type)
	text_file.write(receptor)
	text_file.write(ligand)
	box_q = "Molecular Dynamic Box:   %s\n" %(self.molecular_box)
        text_file.write(box_q)
        text_file.write(my_input)
        text_file.write(my_input2)
        text_file.write(my_outpt)

#	text_file.write("Snapshot Suggest:        no\n")
#	text_file.write("StdDev CutOff:           2.0\n")
	init_s = "Initial Snapshot:        %s\n" %(self.select_init_snap_entry.get())
	fin_s = "Final Snapshot:          %s\n" %(self.select_final_snap_entry.get())
	step_s = "Snapshot Step:           %s\n" %(self.select_step_snap_entry.get())
	text_file.write(init_s)
	text_file.write(fin_s)
        text_file.write(step_s)

#        resi2 = self.select_single_residues_entry.get()

	if self.byresidue == 'no':
	  	text_file.write("Single Residue Energies: no\n")

#		if self.max < self.max2:
#		   self.max = self.max2
#		if self.min > self.min2:
#                   self.min = self.min2
#		res = (self.max - self.min)+1
#		nres = "NumberResiduesInterest:  %4i\n" %(res)
#		text_file.write(nres)
#		text_file.write("Residues of interest:\n")
#		resi = "%i-%i\n" %(self.min,self.max)
#		text_file.write(resi)
	else:
                text_file.write("Single Residue Energies: yes\n")
                #res = (self.max2 - self.min2)+1
#                nres = "NumberResiduesInterest:  %4i\n" %(self.nbyres)
#                text_file.write(nres)
#                text_file.write("Residues of interest:\n")
#		print resi2
#		resi3 = resi2.replace(';','\n')
#                text_file.write(resi3)

        text_file.close()

	filename2 = self.select_inputfile_entry.get()
	filename3 = os.path.join(self.settings['working_dir'],name_base1[1])
	if not os.path.isfile(filename3):
            shutil.copy2(filename2,self.settings['working_dir'])

	command = "\"%s\" \"%s\"" %(self.settings['ism_executable'],'output.in')
        self.r =Running_ISM(self.settings['working_dir'],command,self.output_page_log_text)
        self.r.start()

    def stop_ism(self):
	self.r.stop()

    def changeResidueType(self, what):
        self.byresidue = what

    def changeInputType(self, what):
        self.input_type = what

    def changeBoxType(self, what):
        self.molecular_box = what
  
    def close_contacts_dialog(self, where):
        self.contacts_dialog.withdraw()

    def close_ds_sr_dialog_vs_selfsingle(self,where):
        self.dataset_sr_dialog_selfsingle.withdraw()

    def close_ds_sr_dialog_vs_selfmd(self,where):
        self.dataset_sr_dialog_selfmd.withdraw()

    def close_ds_sr_dialog_vs(self, where):
        self.dataset_sr_dialog_vs.withdraw()

    def close_ds_sr_dialog_st(self, where):
        self.dataset_sr_dialog_st.withdraw()

    def close_ds_sr_dialog(self, where):
	self.dataset_sr_dialog.withdraw()

    def close_ds_sr_st_dialog(self, where):
	self.dataset_sr_st_dialog.withdraw()

    def close_ds_st_dialog(self, where):
	self.dataset_st_dialog.withdraw()

    def close_ds_dialog(self, where):
	self.dataset_dialog.withdraw()

    def close_main_dialog(self, where):
        self.main_dialog.withdraw()

    def set_inputfilex(self):
        try:
                a = TkMyFileDialog(self.parent)
                outputx = a.askopenfilename()
                self.select_inputfilex_entry.setvalue(outputx)
        except:
                pass

    
    def set_inputfile(self):
        try:
                a = TkMyFileDialog(self.parent)
                output = a.askopenfilename()
                self.select_inputfile_entry.setvalue(output)
        except:
                pass

    def set_outputfile(self):
        try:
                a = TkMyFileDialog(self.parent)
                output = a.askopenfilename()
                b = os.path.split(output)
                c = b[1].split('_')
                self.select_outputfile_entry.setvalue(c[0])
        except:
                pass

    def set_outputfile2(self):
        try:
                a = TkMyFileDialog(self.parent)
                output = a.askopenfilename()
		b = os.path.split(output)
		c = b[1].split('_')
                self.select_outputfile_entry2.setvalue(c[0])
        except:
                pass
        

#    def set_sele_single(self):
#        first = 0
#        last = 0
#        result = ''
#        stored.list=[]
#        cmd.iterate_state(1,"(sele)","stored.list.append((resi,resn))")
#        sele_list=[]
#        all_list =[]
#        for item in stored.list:
#            if item not in sele_list:
#               sele_list.append(item)
#
#        stored.list=[]
#        cmd.iterate("(all)","stored.list.append((resi,resn))")
#        i = 0
#
#        for item in stored.list:
#            if item not in all_list:
#               all_list.append(item)
#
#	self.nbyres = len(sele_list)
#
#        for item in all_list:
#                i = i +1
#                if i > self.max2:
#                   self.max2 = i
#                if i < self.min2:
#                   self.min2 = i
#                if item in sele_list:
#                   if first == 0:
#                      first = i
#
#                   if last == 0 or last == (i - 1):
#                      last = i
#                   else:
#		      if first == last:
#			result += "%i;" %(first)
#		      else:
#                        result += "%i-%i;" %(first, last)
#                      first = i
#                      last = i
#	if first == last:
#	   result += "%i;" %(first)
#	else: 
#           result += "%i-%i;" %(first, last)
#
##        self.select_single_residues_entry.setvalue(result)
#


    def set_sele_protein(self):
     try:
	first = 0
	last = 0
	result = ''
        stored.list=[]
        cmd.iterate_state(1,"(sele)","stored.list.append((resi,resn))")
        sele_list=[]
	all_list =[]
        for item in stored.list:
            if item not in sele_list:
               sele_list.append(item)

        stored.list=[]
        cmd.iterate("(all)","stored.list.append((resi,resn))")
        i = 0

        for item in stored.list:
            if item not in all_list:
               all_list.append(item)

        for item in all_list:
                i = i +1
		if i > self.max:
                   self.max = i
		if i < self.min:
                   self.min = i
                if item in sele_list:
                   if first == 0:
                      first = i

                   if last == 0 or last == (i - 1):
		      last = i
		   else:
                      if len(result) != 0:
                        result += ","
                      result += "%i-%i" %(first, last)
		      first = i 
		      last = i
        if len(result) != 0:
          result += ","
        result += "%i-%i" %(first, last)

	self.select_prot_residues_entry.setvalue(result)
     
     except:
      self.screwup("Error","An error ocurred trying to extract selection \"sele\" from PyMOL")

    def set_sele_lig2(self):
     try:
        first = 0
        last = 0
        result = ''
        stored.list=[]
        cmd.iterate_state(1,"(sele)","stored.list.append((resi,resn))")
        sele_list=[]
        all_list =[]
        for item in stored.list:
            if item not in sele_list:
               sele_list.append(item)

        stored.list=[]
        cmd.iterate("(all)","stored.list.append((resi,resn))")
        i = 0

        for item in stored.list:
            if item not in all_list:
               all_list.append(item)

        for item in all_list:
                i = i +1
                if i > self.max3:
                   self.max3 = i
                if i < self.min3:
                   self.min3 = i
                if item in sele_list:
                   if first == 0:
                      first = i

                   if last == 0 or last == (i - 1):
                      last = i
                   else:
                      first = i
                      last = i
        result = "%i" %(first)

        self.analysis_sr_residues_entry.setvalue(result)

     except:
      self.screwup("Error","An error ocurred trying to extract selection \"sele\" from PyMOL")

    def set_sele_lig3(self):
     try:
        first = 0
        last = 0
        result = ''
        stored.list=[]
        cmd.iterate_state(1,"(sele)","stored.list.append((resi,resn))")
        sele_list=[]
        all_list =[]
        for item in stored.list:
            if item not in sele_list:
               sele_list.append(item)

        stored.list=[]
        cmd.iterate("(all)","stored.list.append((resi,resn))")
        i = 0

        for item in stored.list:
            if item not in all_list:
               all_list.append(item)

        for item in all_list:
                i = i +1
                if i > self.max3: 
                   self.max3 = i
                if i < self.min3:
                   self.min3 = i
                if item in sele_list:
                   if first == 0:
                      first = i

                   if last == 0 or last == (i - 1):
                      last = i
                   else:
                      first = i
                      last = i
        result = "%i" %(first)

        self.analysis_sr_residues_entry2.setvalue(result)

     except:
      self.screwup("Error","An error ocurred trying to extract selection \"sele\" from PyMOL")

    def set_outputfile3(self):
        try:
                a = TkMyFileDialog(self.parent)
                output = a.asksaveasfilename()
                self.select_outputfile_entry3.setvalue(output)
        except TclError:
                pass


    def pre_save_rep(self):
#      try:
        self.pre_save_rep = Pmw.Dialog(self.parent,
                                 title = 'Output file')
        self.pre_save_rep.withdraw()
        Pmw.setbusycursorattributes(self.pre_save_rep.component('hull'))

        self.pre_save_rep.geometry('620x250')

        self.pre_save_rep_mosttop_group = Pmw.Group(self.pre_save_rep.interior(),tag_text='Object')
        self.pre_save_rep_mosttop_group.pack(fill = 'both', expand = 0, padx = 10, pady = 5)

        self.select_rep_entry = Pmw.EntryField(self.pre_save_rep_mosttop_group.interior(), labelpos = 'w',label_text = 'Selection name:')
        self.select_rep_entry.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)

        self.pre_save_rep_top_group = Pmw.Group(self.pre_save_rep.interior(),tag_text='File')
        self.pre_save_rep_top_group.pack(fill = 'both', expand = 0, padx = 10, pady = 5)

#        self.pre_save_rep_bot_group = Pmw.Group(self.pre_save_rep.interior(),tag_text='Terms')
#        self.pre_save_rep_bot_group.pack(fill = 'both', expand = 0, padx = 10, pady = 5)


        self.select_outputfile_entry3 = Pmw.EntryField(self.pre_save_rep_top_group.interior(), labelpos = 'w',label_text = 'Output file:')
        self.select_outputfile_entry3.pack(side=LEFT,fill='x',expand = 1, padx = 0, pady = 0)
        self.select_outputfile_button_box3 = Pmw.ButtonBox(self.pre_save_rep_top_group.interior(),orient='horizontal', padx=0,pady=0)
        self.select_outputfile_button_box3.add('...',command = self.set_outputfile3)
        self.select_outputfile_button_box3.pack(side=LEFT,expand = 0, padx = 0, pady = 5)

#        self.export_types_checkbutton = Pmw.RadioSelect(self.pre_save_rep_bot_group.interior(),
#                buttontype = 'radiobutton',orient = 'vertical',
#                labelpos = 'w',
#                label_text = 'Select elements to export',
#                hull_borderwidth = 2,hull_relief = 'ridge')
#        self.export_types_checkbutton.pack(side = 'top', expand = 1, padx = 10, pady = 10)
#
#        self.export_types_checkbutton.add('Coulombic energy')
#        self.export_types_checkbutton.add('Van der Waals energy')
#        self.export_types_checkbutton.add('Receptor desolvation energy')
#        self.export_types_checkbutton.add('Ligand desolvation energy')
#        self.export_types_checkbutton.add('Apolar energy')
#        self.export_types_checkbutton.add('Hydrogen bond correction')
#        self.export_types_checkbutton.add('Total energy')





        self.pre_save_button_box = Pmw.ButtonBox(self.pre_save_rep.interior(),orient='horizontal', padx=0,pady=0)
        self.pre_save_button_box.add('Save',command = self.save_rep_input_file)
        self.pre_save_button_box.pack(side=RIGHT,expand = 1, padx = 10, pady = 5)
        self.pre_save_rep.show()
#      except:
#        self.screwup("Fatal","Dirty error\nCan display dialog")
#        return

#        self.box_for_contacts.add('Show Contacts',command = self.do_contacts)
#        self.box_for_contacts.add('Hide protein',command = self.do_hide_protein)
#        self.box_for_contacts.add('Hydrophobic',command = self.do_show_hydrophobic)
#        self.box_for_contacts.add('Hydrophylic',command = self.do_show_hydrophylic)
#        self.box_for_contacts.add('Mixed contacts',command = self.do_show_mixed)
#        self.box_for_contacts.add('Hydrogen bonds',command = self.do_show_hbonds)


    def do_hide_protein(self):
	try:
	 cmd.hide("everything","ISM_rest")
        except:
         print "No ISM protein loaded"

    def do_show_hydrophobic(self):
        cmd.hide("everything","all")

        try:
         cmd.show("sticks","hydrophobic_lig")
        except:
         print "No hydrophobic ligands"

        try:
         cmd.color('green',"hydrophobic_protein")
         cmd.show("surface","hydrophobic_protein")
        except:
         print "No hydrophobic protein"


    def do_show_hydrophylic(self):
        cmd.hide("everything","all")

        try:
         cmd.show("sticks","hydrophilic_lig")
        except:
         print "No hydrophilic ligands"

        try:
         cmd.color('cyan',"hydrophilic_protein")
         cmd.show("surface","hydrophilic_protein")
        except:
         print "No hydrophilic protein"


    def do_show_mixed(self):
        cmd.hide("all")
        try:
         cmd.show("sticks","mixed_interaction_lig")
        except:
         print "No mixed ligands"

        try:
         cmd.color('yellow',"mixed_interaction_protein")
         cmd.show("surface","mixed_interaction_protein")
        except:
         print "No mixed protein"

    def do_show_hbonds(self):
        cmd.hide("all")
        try:
         cmd.show("sticks","hb_interaction_lig")
        except:
         print "No mixed ligands"

        try:
         cmd.color('red',"hb_interaction_protein")
         cmd.show("surface","hb_interaction_protein")
        except:
         print "No mixed protein"

    def do_contacts(self):

	rootName = os.path.join(self.settings['working_dir'],self.select_outputfile_entry.get())

	contactsName = rootName+'_Contacts.out'
	try:
	 cfile = file( contactsName, 'r')
        except:
	 self.screwup("Oops","There is no Contacts file. This is due to an error in the programa execution or the analysis results come from a Molecular dynamics simulations and contacts cannot be traced during the simulation.\nOnly individual structures can be analyzed for contacts.\n");
	 return


	contactFields    = list()
	contact_id       = list()
#BugFix. 20/04/2012 arrays sux for small volumes of data, list rules
#	hydrophobic      = array.array('f', [0.0]*2000)
#	hydrophilic      = array.array('f', [0.0]*2000)
#	total            = array.array('f', [0.0]*2000)
#	hydrophobic_rate = array.array('f', [0.0]*2000)
#	hydrophilic_rate = array.array('f', [0.0]*2000)
	hydrophobic      = []
	hydrophilic      = []
	total            = []
	hydrophobic_rate = []
	hydrophilic_rate = []
	count            = 0
	cont_count       = 1

#Bugfix. Why are we starting at 1? We need to add this one when count == 1
        hydrophobic.append(0.0)
        hydrophilic.append(0.0)
        total.append(0.0)
        hydrophobic_rate.append(0.0)
        hydrophilic_rate.append(0.0)


	for l in cfile.readlines():
	        if (count > 1):
                        hydrophobic.append(0.0)
			hydrophilic.append(0.0)
			total.append(0.0)
			hydrophobic_rate.append(0.0)
			hydrophilic_rate.append(0.0)

	                contactFields = l.strip('\n').split()
	                contact_id.append( contactFields[1]+'-'+contactFields[2]+'-'+contactFields[3]+'-'+contactFields[4])
	                hydrophobic[cont_count] = float(contactFields[10]) + float(contactFields[11]) + float(contactFields[14]) + float(contactFields[15]) + float(contactFields[17])
	                hydrophilic[cont_count] = float(contactFields[ 8]) + float(contactFields[ 9]) + float(contactFields[12]) + float(contactFields[13]) + float(contactFields[16])
	                total[cont_count]       = float(contactFields[10]) + float(contactFields[11]) + float(contactFields[14]) + float(contactFields[15]) + float(contactFields[17]) + float(contactFields[ 8]) + float(contactFields[ 9]) + float(contactFields[12]) + float(contactFields[13]) + float(contactFields[16])
	                hydrophobic_rate[cont_count]  = hydrophobic[cont_count]/ total[cont_count]
	                hydrophilic_rate[cont_count]  = hydrophilic[cont_count]/ total[cont_count]
	                #print "%-2d %15s %8.3f %8.3f" % (cont_count, contact_id[cont_count-1], hydrophobic_rate[cont_count], hydrophilic_rate[cont_count])
	                cont_count = cont_count + 1
	        count = count + 1

	cfile.close()

	hbondName = rootName+'_Hbonds.out'
	cfile = file( hbondName, 'r')
	contactFields = list()
	hb_id = list()
	count = 0
	hb_count = 0
	for l in cfile.readlines():
	        if (count > 1):
	                contactFields = l.strip('\n').split()
	                hb_id.append( contactFields[3]+'-'+contactFields[4]+'-'+contactFields[6]+'-'+contactFields[7])
	                #print "%-2d %15s" % (hb_count, hb_id[hb_count])
	                hb_count = hb_count + 1
	        count = count + 1
	
	cfile.close()

	ishb = 0
	cont_count = 1
	global_sel = []
        hydrophobic_sel = []
        hydrophilic_sel = []
        amphipathic_sel = []
        hbonds_sel = []
	prot_sel = []
	ligand_sel = []

	hb_table = []
	ho_table = []
	hi_table = []
        mi_table = []

	for k in contact_id:
                y = k.split("-")
	        ishb = 0
		sel_text = "((resname %s and resi %s) or (resname %s and resi %s))" %(y[0],y[1],y[2],y[3])
		sel_prot = "(resname %s and resi %s)" %(y[0],y[1])
		sel_lig = "(resname %s and resi %s)" %(y[2],y[3])
		global_sel.append(sel_text)
		prot_sel.append(sel_prot)
		ligand_sel.append(sel_lig)

# Federico's choice!
#                cmd.select(k,sel_text)
#                cmd.show('sticks',k)
#		cmd.label(sel_text+"and name ca",'resn+resi')
#
#  Now we do like this:
#   - Save all the different pairs according their nature
#   - Create new objects with the selections
#   - Color them 
#   - Show surface for the receptor and stick for the ligand
#   - Show a table with the list of the contacts

	        for h in hb_id:
	                if(k == h):
	                        ishb = 1
	                        break

	        if (ishb == 1):
			hbonds_sel.append(sel_text)
			hb_table.append("%s-%s | %s-%s" %(y[0],y[1],y[2],y[3]))
	        else:
	                if(hydrophobic_rate[cont_count] >= 0.6):
				hydrophobic_sel.append(sel_text)
	                        ho_table.append("%s-%s | %s-%s" %(y[0],y[1],y[2],y[3]))

	                if(hydrophilic_rate[cont_count] >= 0.6):
				hydrophilic_sel.append(sel_text)
                        	hi_table.append("%s-%s | %s-%s" %(y[0],y[1],y[2],y[3]))
	                else:
				amphipathic_sel.append(sel_text)
	                        mi_table.append("%s-%s | %s-%s" %(y[0],y[1],y[2],y[3]))

	        cont_count = cont_count + 1

	cmd.hide('lines','polymer')

        nt = 0
        sel_text = ""
        for i in hbonds_sel:
               if nt != len(hbonds_sel)-1:
                sel_text = sel_text + i + " or "
               else:
                sel_text = sel_text + i
               nt = nt + 1

        if len(sel_text) > 0:

         cmd.select("hb_interaction",sel_text)
         cmd.create("ISM_HB","hb_interaction",zoom=0)
         util.cbam("ISM_HB")
         cmd.delete("hb_interaction")

        nt = 0
        sel_text = ""
        for i in amphipathic_sel:
               if nt != len(amphipathic_sel)-1:
                sel_text = sel_text + i + " or "
               else:
                sel_text = sel_text + i
               nt = nt + 1

        if len(sel_text) > 0:

         cmd.select("mixed_interaction",sel_text)
         cmd.create("ISM_mixed","mixed_interaction",zoom=0)
   	 util.cbay("ISM_mixed")
	 cmd.delete("mixed_interaction")

        nt = 0
        sel_text = ""
        for i in hydrophobic_sel:
               if nt != len(hydrophobic_sel)-1:
                sel_text = sel_text + i + " or "
               else:
                sel_text = sel_text + i
               nt = nt + 1

        if len(sel_text) > 0:
         cmd.select("hydrophobic",sel_text)
         cmd.create("ISM_hydrophobic","hydrophobic",zoom=0)
         util.cbag("ISM_hydrophobic")

        nt = 0
        sel_text = ""
        for i in hydrophilic_sel:
               if nt != len(hydrophilic_sel)-1:
                sel_text = sel_text + i + " or "
               else:
                sel_text = sel_text + i
               nt = nt + 1

	if len(sel_text) > 0:
         cmd.select("hydrophilic",sel_text)
         cmd.create("ISM_hydrophilic","hydrophilic",zoom=0)
         util.cbac("ISM_hydrophilic")

        nt = 0
        sel_text = ""
        for i in prot_sel:
               if nt != len(prot_sel)-1:
                sel_text = sel_text + i + " or "
               else:
                sel_text = sel_text + i
               nt = nt + 1
        cmd.select("protein",sel_text)

        nt = 0
        sel_text = ""
        for i in ligand_sel:
               if nt != len(ligand_sel)-1:
                sel_text = sel_text + i + " or "
               else:
                sel_text = sel_text + i
               nt = nt + 1
        cmd.select("ligand",sel_text)


        cmd.create("ISM_rest","polymer and !ligand and !protein",zoom=0)
        cmd.show("surface","ISM_rest")
        cmd.color("grey90","ISM_rest")

        try:
         cmd.create("hb_interaction_lig","ISM_HB and ligand")
         cmd.show("sticks","hb_interaction_lig")
        except:
         print "No hb ligands"

        try:
         cmd.create("hb_interaction_protein","ISM_HB and protein")
         cmd.color('yellow',"hb_interaction_protein")
         cmd.show("surface","hb_interaction_protein")
        except:
         print "No hb protein"


	try: 
         cmd.create("mixed_interaction_lig","ISM_mixed and ligand")
         cmd.show("sticks","mixed_interaction_lig")
	except:
	 print "No mixed ligands"

	try:
         cmd.create("mixed_interaction_protein","ISM_mixed and protein")
         cmd.color('yellow',"mixed_interaction_protein")
         cmd.show("surface","mixed_interaction_protein")
	except:
	 print "No mixed protein"

 	try:
         cmd.create("hydrophobic_lig","ISM_hydrophobic and ligand")
         cmd.show("sticks","hydrophobic_lig")
	except:
	 print "No hydrophobic ligand"

	try:
         cmd.create("hydrophobic_protein","ISM_hydrophobic and protein")
         cmd.color('green',"hydrophobic_protein")
         cmd.show("surface","hydrophobic_protein")
	except:
         print "No hydrophobic protein"


	try:
         cmd.create("hydrophilic_lig","ISM_hydrophilic and ligand")
         cmd.show("sticks","hydrophilic_lig")
	except:
         print "No hydrophylic ligand"

	try:
         cmd.create("hydrophilic_protein","ISM_hydrophilic and protein")
         cmd.color('cyan',"hydrophilic_protein")
         cmd.show("surface","hydrophilic_protein")
	except:
         print "No hydrophylic protein"


        nt = 0
        sel_text = ""
        for i in global_sel:
               if nt != len(global_sel)-1:
		sel_text = sel_text + i + " or "
               else:
                sel_text = sel_text + i 
               nt = nt + 1

# Ligands
#        cmd.select("ligands","interface and !polymer")
#        util.cbas("ligands")
#	cmd.zoom("interface")
	cmd.orient("ligand",animate=-1)
	cmd.delete("hydrophilic")
	cmd.delete("hydrophobic")
	cmd.delete("hb_interaction")
	cmd.delete("protein")
        cmd.delete("ligand")
	cmd.set("transparency",0.3)


        self.contacts_dialog = Pmw.Dialog(self.parent,title = 'Contacs',command = self.close_contacts_dialog)
        self.contacts_dialog.withdraw()

        self.contacts_dialog.geometry('550x280')
        self.contacts_dialog.bind('<Return>',self.close_contacts_dialog)

        self.sf = Pmw.ScrolledFrame(self.contacts_dialog.interior(),
                labelpos = 'n', label_text = 'Contacts list',
                usehullsize = 1,
                hull_width = 400,
                hull_height = 220,
        )

        self.sf.pack(padx = 5, pady = 3, fill = 'both', expand = 1)

        self.frame = self.sf.interior()

        self.row = 0
        self.col = 0

        have_single = 0
        have_cross = 0

        self.addLabel('Residue protein',2)
        self.addLabel('Residue ligand',2)
        self.addLabel('Type',2)

        for i in hb_table:
	      op = i.split("|")
              self.addButton(op[0],2);
              self.addButton(op[1],2);
              self.addButton("Hydrogen bond",2);

        for i in ho_table:
              op = i.split("|")
              self.addButton(op[0],2);
              self.addButton(op[1],2);
              self.addButton("Hydrophobic",2);

        for i in hi_table:
              op = i.split("|")
              self.addButton(op[0],2);
              self.addButton(op[1],2);
              self.addButton("Hydrophilic",2);

        for i in mi_table:
              op = i.split("|")
              self.addButton(op[0],2);
              self.addButton(op[1],2);
              self.addButton("Mixed",2);



        self.contacts_dialog.show()



    def screwup(self, title, message):
          warn = Pmw.MessageDialog(self.parent,
            title = title,
            defaultbutton = 0,
            message_text = "%s" %(message))
          warn.iconname('Warning')
          warn.withdraw()
          warn.show()



    def save_rep_input_file(self):
     try:
        my_filename = os.path.join(self.settings['working_dir'],self.select_outputfile_entry.get())
        my_filename += "_ResidueEnergies.out"

        desolvSingle = []

        if os.path.isfile(my_filename):
            try:
              filecillo = open(my_filename,'r')
              try:
                list = filecillo.readlines()
                current_step = -1; 
                for line in list:
                        if line[1:12] == '// SnapShot':
                                current_step = current_step + 1

                        if line.strip()[0:12] == 'Self Terms  ':
                                entr = line.split()
                                if entr[1] == '********':
                                   entr[1] = '9999'
                                if entr[2] == '********':
                                   entr[2] = '9999'
                                if current_step < 0:
                                  current_step = 0
                                res_info = [ current_step, int(entr[2]), float(entr[4]), float(entr[5])]
				print res_info
                                desolvSingle.append( res_info )
              finally:
                  filecillo.close()
            except IOError:
               pass
        print "Read done"

        dsav = {}
	for el in desolvSingle:
          if dsav.get(str(el[1]), -1) == -1:
              dsav[ str(el[1]) ] = el[2]
          else:
              dsav[ str(el[1]) ] = dsav.get(str(el[1])) + el[2]

       
        max = 0

	dsav2 = []
	for key, value in dsav.iteritems():
	  n = int(key)
          if n  > max:
             max = n

#    		temp = [key,value]
#    		dictlist.append(temp)


	max = max + 1
	for x in range(max):
	    dsav2.append(0.0)

        for key, value in dsav.iteritems():
               dsav2[ int(key) ] = value / float(current_step+1.0)

#	for el in dsav:
#         print int(el[0])
#         dsav2[ int(el[0]) ] =  dsav.get(el[0]) / float(current_step+1.0)

        selection_rep = self.select_rep_entry.get()
        working_rep = self.select_outputfile_entry3.get()

        if len(selection_rep) == 0 or len(working_rep) == 0:
          self.screwup("Oops","You have to provide a file and chose a selection group")
          return

#        try:
        if 1==1:
         if len(selection_rep) != 0 and len(working_rep) != 0:
                stored.xyz = []
                cmd.iterate_state(1,selection_rep,"stored.xyz.append((name,resi,resn,[x,y,z],chain))")
                a = ''
#                print stored.xyz
                i = 0
                for item in stored.xyz:
                        i = i + 1
			bfactor = 0
#                        for jk in dsav2:
#                         if int(jk) == int(item[1]):
#                           bfactor = dsav2.get(jk)
			bfactor = dsav2[ int(item[1])]

                        a += 'ATOM  %5i %4s%4s%2s%4i    %8.3f%8.3f%8.3f%6.2f%6.2f\n' %(i,item[0].ljust(4),item[2],item[4], int(item[1]), float(item[3][0]), float(item[3][1]), float(item[3][2]), 1.0,bfactor)

                filename3 = working_rep
                fp3 = open(filename3,"w")
                print >>fp3,a
                fp3.close()
#        except:
#         self.screwup("Fatal","Cant extract information from PyMOL")
#         return

     except:
      self.screwup("Fatal","Cant extract information from PyMOL or ISM output does not exist")
      return

    def set_sele_lig(self):
     try:
        first = 0
        last = 0
        result = ''
        stored.list=[]
        cmd.iterate_state(1,"(sele)","stored.list.append((resi,resn))")
        sele_list=[]
        all_list =[]
        for item in stored.list:
            if item not in sele_list:
               sele_list.append(item)

        stored.list=[]
        cmd.iterate("(all)","stored.list.append((resi,resn))")
        i = 0

        for item in stored.list:
            if item not in all_list:
               all_list.append(item)

        for item in all_list:
                i = i +1
                if i > self.max3:
                   self.max3 = i
                if i < self.min3:
                   self.min3 = i
                if item in sele_list:
                   if first == 0:
                      first = i

                   if last == 0 or last == (i - 1):
                      last = i
                   else:
                      if len(result) != 0:
                        result += ","
                      result += "%i-%i" %(first, last)
                      first = i
                      last = i
        if len(result) != 0:
           result += ","

        result += "%i-%i" %(first, last)

        self.select_lig_residues_entry.setvalue(result)
     except:
      self.screwup("Fatal","Cant extract information from PyMOL or ISM output does not exist")
      return



    def set_ism_exe_file(self):
	try:
		a = TkMyFileDialog(self.parent)
	        output = a.askopenfilename()
		self.select_exe_entry.setvalue(output)
	except:
		pass

    def set_workdir(self):
        try:
                a = TkMyFileDialog(self.parent)
                output = a.askdirectory()
                self.select_workdir_entry.setvalue(output)
        except:
                pass

	
    def sortDictByVal(thedict):
       theitems = thedict.items()
       theitems.sort()
       return [value for key, value in theitems]


    def read_config(self):
        filename = os.path.join(ism_working_dir,"ism_config.in")
        self.settings = {}
        self.settings['ism_executable'] = ''
        self.settings['working_dir'] = ''
	self.settings['working_inpwd'] = '0'
        if os.path.isfile(filename):
	    try:
              filecillo = open(filename,'r')
	      try:
                list = filecillo.readlines()
                for line in list:
                    if line[0]!='!' and line[0]!='#':
                        entr = line.split(':')
                        self.settings[entr[0].strip()] = entr[1].strip()
              finally:
	          filecillo.close()
            except IOError:
               pass

        if self.working_inpwd == '0':
           self.settings['working_dir'] = ''

        self.select_exe_entry.setvalue(self.settings['ism_executable'])
        self.select_workdir_entry.setvalue(self.settings['working_dir'])
        return self.settings
   
    def write_config(self):
        self.settings['working_dir'] = self.select_workdir_entry.get()
	self.settings['ism_executable'] = self.select_exe_entry.get()

        filename = os.path.join(ism_working_dir,"ism_config.in")
	try:
	        fp = open(filename,'w')
		try:
		        for key, val in self.settings.items():
		            print >>fp, key, ':', val
		finally:
		        fp.close()	
        except IOError:
	      pass

class TkMyFileDialog(Tkinter.Frame):

  def __init__(self, root):

    Tkinter.Frame.__init__(self, root)
    button_opt = {'fill': Tkconstants.BOTH, 'padx': 5, 'pady': 5}
    Tkinter.Button(self, text='askopenfile', command=self.askopenfile).pack(**button_opt)
    Tkinter.Button(self, text='askopenfilename', command=self.askopenfilename).pack(**button_opt)
    Tkinter.Button(self, text='asksaveasfile', command=self.asksaveasfile).pack(**button_opt)
    Tkinter.Button(self, text='asksaveasfilename', command=self.asksaveasfilename).pack(**button_opt)
    Tkinter.Button(self, text='askdirectory', command=self.askdirectory).pack(**button_opt)

    self.file_opt = options = {}
    options['defaultextension'] = '' # couldn't figure out how this works
    options['filetypes'] = [('all files', '.*'), ('exe files', '.exe'), ('pdb files', '.pdb'), ('crd files', '.crd') ]
    options['initialdir'] = os.getcwd()
    options['initialfile'] = ''
    options['parent'] = root
    options['title'] = 'Please select a file'

    self.dir_opt = options = {}
    options['initialdir'] = os.getcwd()
    options['mustexist'] = True
    options['parent'] = root
    options['title'] = 'Please select a directory'

  def askopenfile(self):
    return tkFileDialog.askopenfile(mode='r', **self.file_opt)

  def askopenfilename(self):
    filename = tkFileDialog.askopenfilename(**self.file_opt)
    return filename

  def asksaveasfile(self):
    return tkFileDialog.asksaveasfile(mode='w', **self.file_opt)

  def asksaveasfilename(self):
    filename = tkFileDialog.asksaveasfilename(**self.file_opt)
    return filename

  def askdirectory(self):
    return tkFileDialog.askdirectory(**self.dir_opt)
