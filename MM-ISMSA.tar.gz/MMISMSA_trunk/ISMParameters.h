c general parameters
      integer NUM_RES_COMPLEX_TYPE

      integer MAX_ATOMS_REC
      integer MAX_ATOMS_BOX
      integer MAX_ATOMS_LIG
      integer MAX_RES_COMPLEX
      real SCALE_RADIUS
      real PROBE
      real G_PARAM_PLUS
      real HYDROGEN_BOND_DISTANCE
      real NON_HYDROGEN_BOND_DISTANCE
      integer MAX_OVERLAPS
      real MIN_PSURFACE
      real APOLAR_PARAM_A
      real APOLAR_PARAM_B
c parameters for operations
      real ALPHA
      real EPSILON
      real EPSILON_PLUS_1
      real CONSTANT_DIELECTRIC_SCREENING
      real LAMBDA
	  	real LAMBDA1
	  	real LAMBDA2
      real PI
      real UNIT_ADJUST
c atom types parameters
      integer ATOMIC_NUMBER_H
      integer ATOMIC_NUMBER_C
      integer ATOMIC_NUMBER_N
      integer ATOMIC_NUMBER_O
      integer ATOMIC_NUMBER_F
      integer ATOMIC_NUMBER_P
      integer ATOMIC_NUMBER_S
      integer ATOMIC_NUMBER_CL
      integer ATOMIC_NUMBER_CA
      integer ATOMIC_NUMBER_BR
      integer ATOMIC_NUMBER_ZN
      integer ATOMIC_NUMBER_I
      integer ATOMIC_NUMBER_MG
   
      integer ATOMIC_NUMBER_UNK
c parameters for main program
      integer MAX_LINES
      integer NUM_AMINOACIDS
      integer FILE_COMPLEX_FILE_NAME
      integer FILE_RESIDUE_DESOLV
      real MIN_BOX 
c parameters for HB
      real MAX_HB_ALFA
      real MIN_HB_ALFA
      real MAX_HB_ALFA_SP2_ACC
      real MIN_HB_ALFA_SP2_ACC
c correction parameters
      real CORR_PARAM_a
      real CORR_PARAM_b
      real CORR_PARAM_c
      real CORR_PARAM_d
      real CORR_PARAM_e 
c NEW PARAMETERS FOR HB
      integer MAX_BONDS
      integer*1 HB_NONE
      integer*1 HB_ACCEPTOR
      integer*1 HB_DONOR
      integer*1 HB_BOTH
      integer NUM_CHARGED_BOX
      integer NUM_ACCEPTORS_BOX
      integer NUM_DONORS_BOX    
c NewParametersHB 
      real HB_MAX_DIST_IDEAL
      real HB_MIN_DIST_IDEAL
      real HB_MAX_DIST_LIMIT
      real HB_MIN_DIST_LIMIT
      real HB_MAX_ALFA_IDEAL
      real HB_MIN_ALFA_IDEAL
      real HB_MAX_ALFA_LIMIT
      real HB_MIN_ALFA_LIMIT
      real HB_MAX_BETA_IDEAL
      real HB_MIN_BETA_IDEAL
      real HB_MAX_BETA_LIMIT
      real HB_MIN_BETA_LIMIT
      real HBSP2_MAX_DIST_IDEAL
      real HBSP2_MIN_DIST_IDEAL
      real HBSP2_MAX_DIST_LIMIT
      real HBSP2_MIN_DIST_LIMIT
      real HBSP2_MAX_ALFA_IDEAL
      real HBSP2_MIN_ALFA_IDEAL
      real HBSP2_MAX_ALFA_LIMIT
      real HBSP2_MIN_ALFA_LIMIT
      real HBSP2_MAX_BETA_IDEAL
      real HBSP2_MIN_BETA_IDEAL
      real HBSP2_MAX_BETA_LIMIT
      real HBSP2_MIN_BETA_LIMIT     
      integer MAX_HB
      integer HBCC
      integer HBCN
      integer HBNN      
      real energyHBCC
      real energyHBCN
      real energyHBNN 
	    real MIN_HBSCORE

      real CONTACT_DIST

c Contacts parameters

	    integer MAX_CONTACTS
    
c general parameters

      parameter (NUM_RES_COMPLEX_TYPE = 5)

c While compiling 64 bits and calculating very big molecules

cccc Big Memory Consum
      parameter (MAX_ATOMS_REC = 22000)
      parameter (MAX_ATOMS_BOX = 22000)
      parameter (MAX_ATOMS_LIG = 22000)
      parameter (MAX_RES_COMPLEX = 1500)
      parameter (MAX_HB = 200)
      parameter (MAX_OVERLAPS = 2000)
      parameter (MAX_CONTACTS = 3000)
	  
cccc Medium Memory Consum
c       parameter (MAX_ATOMS_REC = 12000)
c       parameter (MAX_ATOMS_BOX = 12000)
c       parameter (MAX_ATOMS_LIG = 12000)
c       parameter (MAX_RES_COMPLEX = 800)
c       parameter (MAX_HB = 200)
c       parameter (MAX_OVERLAPS = 300)
c       parameter (MAX_CONTACTS = 10000)

	   
cccc Small Memory Consum
c      parameter (MAX_ATOMS_REC = 4000)
c      parameter (MAX_ATOMS_BOX = 4000)
c      parameter (MAX_ATOMS_LIG = 4000)
c      parameter (MAX_RES_COMPLEX = 800)
c      parameter (MAX_HB = 50)
c      parameter (MAX_OVERLAPS = 100)
c      parameter (MAX_CONTACTS = 5000)

      parameter (SCALE_RADIUS = 0.60)
      parameter (PROBE = 1.40)
      parameter (G_PARAM_PLUS = 0.5)
      parameter (HYDROGEN_BOND_DISTANCE = 1.34)
      parameter (NON_HYDROGEN_BOND_DISTANCE = 2.05)
      parameter (MIN_PSURFACE = 0.01)
      parameter (APOLAR_PARAM_A = 0.092)
      parameter (APOLAR_PARAM_B = 0.00542)
	  
c parameters for operations
      parameter (ALPHA = 1.0367)
      parameter (EPSILON = 78.39)
      parameter (EPSILON_PLUS_1 = EPSILON + 1.0)
      parameter (CONSTANT_DIELECTRIC_SCREENING = (EPSILON - 1.0) / 2.0)
      parameter (LAMBDA = ALPHA / EPSILON_PLUS_1)

      parameter (LAMBDA1 = 0.013)
      parameter (LAMBDA2 = 0.007)

      parameter (PI = 3.1416)
      parameter (UNIT_ADJUST = 166.0)
c atom types parameters
      parameter (ATOMIC_NUMBER_H = 1)
      parameter (ATOMIC_NUMBER_C = 6)
      parameter (ATOMIC_NUMBER_N = 7)
      parameter (ATOMIC_NUMBER_O = 8)
      parameter (ATOMIC_NUMBER_F = 9)
      parameter (ATOMIC_NUMBER_P = 15)
      parameter (ATOMIC_NUMBER_S = 16)
      parameter (ATOMIC_NUMBER_CL = 17)

      parameter (ATOMIC_NUMBER_CA = 18)
      parameter (ATOMIC_NUMBER_BR = 19)
      parameter (ATOMIC_NUMBER_ZN = 20)
      parameter (ATOMIC_NUMBER_I = 21)
      parameter (ATOMIC_NUMBER_MG = 22)

      parameter (ATOMIC_NUMBER_UNK = 0)
c parameters for main program
      parameter (MAX_LINES = 20000)
      parameter (NUM_AMINOACIDS = 35)
      parameter (FILE_COMPLEX_FILE_NAME = 10)
      parameter (FILE_RESIDUE_DESOLV = 11)
      parameter (MIN_BOX = (1.9 + PROBE) * 2)
!		parametros mas parecidos a HBP

c correction parameters      

      parameter (CORR_PARAM_a = -0.29)
      parameter (CORR_PARAM_b = 1.02)
      parameter (CORR_PARAM_c = -0.25)
      parameter (CORR_PARAM_d = 0.02)

c      parameter (CORR_PARAM_a = 0.0)
c      parameter (CORR_PARAM_b = 0.0)
c      parameter (CORR_PARAM_c = 0.0)
c      parameter (CORR_PARAM_d = 0.0)

c      parameter (CORR_PARAM_e = 10.0)
      parameter (CORR_PARAM_e = 4)

c NEW PARAMETERS FOR HB
      parameter (MAX_BONDS = 8)
      parameter (HB_NONE = 0)
      parameter (HB_ACCEPTOR = 1)
      parameter (HB_DONOR = 2)
      parameter (HB_BOTH = 3)
      parameter (NUM_CHARGED_BOX = 20)
      parameter (NUM_ACCEPTORS_BOX = 14)
      parameter (NUM_DONORS_BOX = 15)

cccccccccccccccccccccccccccccccccccccccccccc      
c     HB NEW PARAMETERES (2010)
c     SP3
c       Distance
c      parameter (HB_MAX_DIST_IDEAL= 2.4 ) !
c      parameter (HB_MIN_DIST_IDEAL= 1.8 ) !
c      parameter (HB_MAX_DIST_LIMIT= 2.7) !
c      parameter (HB_MIN_DIST_LIMIT= 1.5) !
c	ALFA angle
c      parameter (HB_MAX_ALFA_IDEAL= 2.6180)  !  !SP3   150
c      parameter (HB_MIN_ALFA_IDEAL= 2.1817)  !         125
c      parameter (HB_MAX_ALFA_LIMIT= 3.1416)  !         180
c      parameter (HB_MIN_ALFA_LIMIT= 1.7453)  !         100
c	BETA angle
c      parameter (HB_MAX_BETA_IDEAL= 2.3562)  !  !SP3   135
c      parameter (HB_MIN_BETA_IDEAL= 2.0071)  !         115
c      parameter (HB_MAX_BETA_LIMIT= 2.7053)  !         155
c      parameter (HB_MAX_BETA_LIMIT= 3.1416)  !         180
c      parameter (HB_MIN_BETA_LIMIT= 1.5708)  !         90
c	SP2   (estadistica igual a los datos grales) diferencias solo con sp3-sp3 puro.
c      parameter (HBSP2_MAX_DIST_IDEAL= 2.4 )   !
c      parameter (HBSP2_MIN_DIST_IDEAL= 1.8)    !
c      parameter (HBSP2_MAX_DIST_LIMIT= 2.7)    !
c      parameter (HBSP2_MIN_DIST_LIMIT= 1.5)    !
c	ALFA angle
c      parameter (HBSP2_MAX_ALFA_IDEAL= 2.8798 )   !  GRAL 165 
c      parameter (HBSP2_MIN_ALFA_IDEAL= 2.2689 )   !       130 
c      parameter (HBSP2_MAX_ALFA_LIMIT= 3.1416 )   !       180 
c      parameter (HBSP2_MIN_ALFA_LIMIT= 1.7453 )   !       100 
c	BETA angle
c      parameter (HBSP2_MAX_BETA_IDEAL= 2.5307)  !   GRAL 145
c      parameter (HBSP2_MIN_BETA_IDEAL= 2.0071)  !        115 
c      parameter (HBSP2_MAX_BETA_LIMIT= 3.1416)  !        180 
c      parameter (HBSP2_MIN_BETA_LIMIT= 1.5708)  !         90
cccccccccccccccccccccccccccccccccccccccccccccccc
	  
cc     HB NEW PARAMETERES (2012_v1)
cc     SP3
cc     Distance
c      parameter (HB_MAX_DIST_IDEAL= 2.7 ) !
c      parameter (HB_MIN_DIST_IDEAL= 0   ) !
c      parameter (HB_MAX_DIST_LIMIT= 3   ) !
c      parameter (HB_MIN_DIST_LIMIT= 0   ) !
cc	ALFA angle
c      parameter (HB_MAX_ALFA_IDEAL= 3.1416)  !  !SP3   180
c      parameter (HB_MIN_ALFA_IDEAL= 2.1817)  !         125
c      parameter (HB_MAX_ALFA_LIMIT= 3.1416)  !         180
c      parameter (HB_MIN_ALFA_LIMIT= 1.7453)  !         100
cc	BETA angle
c      parameter (HB_MAX_BETA_IDEAL= 2.62  )  !  !SP3   150
c      parameter (HB_MIN_BETA_IDEAL= 2.0071)  !         115
c      parameter (HB_MAX_BETA_LIMIT= 3.1416)  !         180
c      parameter (HB_MIN_BETA_LIMIT= 1.0472)  !         60
cc	SP2   (estadistica igual a los datos grales) diferencias solo con sp3-sp3 puro.
c      parameter (HBSP2_MAX_DIST_IDEAL= 2.7  )   !
c      parameter (HBSP2_MIN_DIST_IDEAL= 0    )    !
c      parameter (HBSP2_MAX_DIST_LIMIT= 3    )    !
c      parameter (HBSP2_MIN_DIST_LIMIT= 0    )    !
cc	ALFA angle
c      parameter (HBSP2_MAX_ALFA_IDEAL= 3.1416)  !  !GRAL  180
c      parameter (HBSP2_MIN_ALFA_IDEAL= 2.1817)  !         125
c      parameter (HBSP2_MAX_ALFA_LIMIT= 3.1416)  !         180
c      parameter (HBSP2_MIN_ALFA_LIMIT= 1.7453)  !         100
cc	BETA angle
c      parameter (HBSP2_MAX_BETA_IDEAL= 3.1416)  !        180
c      parameter (HBSP2_MIN_BETA_IDEAL= 2.0071)  !        115 
c      parameter (HBSP2_MAX_BETA_LIMIT= 3.1416)  !        180 
c      parameter (HBSP2_MIN_BETA_LIMIT= 1.0472)  !        60 
cc      parameter (MAX_HB = 15)


c     HB NEW PARAMETERES (2012_v2)
c	  HB def. Paper ISM 
c     SP3
c     Distance
      parameter ( HB_MAX_DIST_IDEAL = 2.4 )        !
      parameter ( HB_MIN_DIST_IDEAL = 0   )      !
      parameter ( HB_MAX_DIST_LIMIT = 2.7 )        !
      parameter ( HB_MIN_DIST_LIMIT = 0   )        !
c	ALFA angle                      
      parameter ( HB_MAX_ALFA_IDEAL = 3.1416 )     !  !SP3   180
      parameter ( HB_MIN_ALFA_IDEAL = 2.2689 )     !         130
      parameter ( HB_MAX_ALFA_LIMIT = 3.1416 )     !         180
      parameter ( HB_MIN_ALFA_LIMIT = 1.5708 )     !          90
c	BETA angle                      
      parameter ( HB_MAX_BETA_IDEAL = 3.1416 )     !  !SP3   180
      parameter ( HB_MIN_BETA_IDEAL = 2.0071 )     !         115
      parameter ( HB_MAX_BETA_LIMIT = 3.1416 )     !         180
      parameter ( HB_MIN_BETA_LIMIT = 1.5708 )     !          90
c	SP2   (estadi stica igual a los datos grales) diferencias solo con sp3-sp3 puro.
      parameter ( HBSP2_MAX_DIST_IDEAL = 2.4 )     !
      parameter ( HBSP2_MIN_DIST_IDEAL = 0   )     !
      parameter ( HBSP2_MAX_DIST_LIMIT = 2.7 )     !
      parameter ( HBSP2_MIN_DIST_LIMIT = 0   )     !
cc	ALFA angle                         
      parameter ( HBSP2_MAX_ALFA_IDEAL = 3.1416 )  !  !GRAL  180
      parameter ( HBSP2_MIN_ALFA_IDEAL = 2.2689 )  !         130
      parameter ( HBSP2_MAX_ALFA_LIMIT = 3.1416 )  !         180
      parameter ( HBSP2_MIN_ALFA_LIMIT = 1.5708 )  !          90
c	BETA angle                         
      parameter ( HBSP2_MAX_BETA_IDEAL = 3.1416 )  !  !GRAL  180
      parameter ( HBSP2_MIN_BETA_IDEAL = 2.0071 )  !         115 
      parameter ( HBSP2_MAX_BETA_LIMIT = 3.1416 )  !         180 
      parameter ( HBSP2_MIN_BETA_LIMIT = 1.5708 )  !          90

      parameter (HBCC = 1)
      parameter (HBCN = 2)
      parameter (HBNN = 3)
	  parameter (MIN_HBSCORE = 0) ! Equivalent to the min energy

! energies for each type of hb    

      parameter (energyHBCC = -3) 
      parameter (energyHBCN = -2)
      parameter (energyHBNN = -1)


      parameter (CONTACT_DIST = 3.5)
