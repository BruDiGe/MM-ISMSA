Manual writen with "docbook". All files needed for building mm-ismsa.pdf are included.
